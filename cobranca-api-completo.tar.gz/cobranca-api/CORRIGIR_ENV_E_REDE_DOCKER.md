# CORRIGIR ERRO NO .ENV E REDE DOCKER

## 🚨 PROBLEMAS IDENTIFICADOS

### Problema 1: Erro no arquivo .env
```
The environment file is invalid!
Failed to parse dotenv file. Encountered unexpected whitespace at [Olá! Quero demo CobrançaAuto SaaS].
```

Isso significa que há uma variável no .env com espaços ou caracteres especiais inválidos.

### Problema 2: Rede do Docker não encontrada
```
network cobranca-api_cobranca_network not found
```

A rede foi removida quando executamos `docker-compose down`.

---

## ✅ SOLUÇÃO

### PARTE 1: CORRIGIR ARQUIVO .ENV

#### PASSO 1: Verificar o arquivo .env

```bash
cat /var/www/cobranca-api/.env | grep -i "demo"
```

Isso deve mostrar a linha com o problema.

#### PASSO 2: Editar o arquivo .env

```bash
nano /var/www/cobranca-api/.env
```

#### PASSO 3: Encontrar a linha com o problema

Procure por algo como:
```env
DEMO_MESSAGE=Olá! Quero demo CobrançaAuto SaaS
```

ou

```env
WELCOME_MESSAGE=Olá! Quero demo CobrançaAuto SaaS
```

#### PASSO 4: Corrigir a linha

Remova espaços ou caracteres especiais. Se a variável tiver espaços no valor, coloque entre aspas:

```env
DEMO_MESSAGE="Olá! Quero demo CobrançaAuto SaaS"
```

ou remova a linha completamente se não for necessária.

#### PASSO 5: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

#### PASSO 6: Verificar se o .env está válido

```bash
php artisan tinker --execute="echo 'OK';"
```

Se não der erro, o .env está válido.

---

### PARTE 2: CRIAR REDE DOCKER E SUBIR CONTAINERS

#### PASSO 7: Criar rede do Docker

```bash
docker network create cobranca-api_cobranca_network
```

#### PASSO 8: Subir containers

```bash
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d
```

#### PASSO 9: Aguardar 30 segundos

```bash
sleep 30
```

#### PASSO 10: Verificar status dos containers

```bash
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps
```

#### PASSO 11: Verificar se a porta 9000 está exposta

```bash
docker port cobranca_app
```

**Deveria mostrar:**
```
9000/tcp -> 127.0.0.1:9000
```

#### PASSO 12: Testar conexão

```bash
curl -I http://127.0.0.1:9000
```

**Deveria mostrar algo como:**
```
HTTP/1.1 404 Not Found
```

#### PASSO 13: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

#### PASSO 14: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### Problemas:

1. ❌ Erro no arquivo .env (variável com espaços ou caracteres especiais)
2. ❌ Rede do Docker não encontrada

### Soluções:

1. ✅ Corrigir a linha problemática no .env
2. ✅ Criar rede do Docker
3. ✅ Subir containers

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# PARTE 1: Corrigir .env
cat /var/www/cobranca-api/.env | grep -i "demo"
nano /var/www/cobranca-api/.env
# Encontrar e corrigir a linha com o problema
# Salvar: Ctrl+O, Enter, Ctrl+X

php artisan tinker --execute="echo 'OK';"

# PARTE 2: Criar rede e subir containers
docker network create cobranca-api_cobranca_network
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d
sleep 30
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps
docker port cobranca_app
curl -I http://127.0.0.1:9000
curl https://api.cobrancaauto.com.br/health
curl https://api.cobrancaauto.com.br/
```

---

## 🔍 SE O BUILD AINDA FALHAR

Se o build ainda falhar, verifique:

1. Se há outras linhas problemáticas no .env:
```bash
cat /var/www/cobranca-api/.env | grep -E "(= | =\t)"
```

2. Se há variáveis sem valor:
```bash
cat /var/www/cobranca-api/.env | grep -E "^[A-Z_]+=$"
```

3. Se há caracteres especiais inválidos:
```bash
cat /var/www/cobranca-api/.env | grep -E "[^a-zA-Z0-9_\-\.= ]"
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔧 SOLUÇÃO - FILE NOT FOUND

## 📋 Problema Identificado

O site está retornando "File not found" quando acessado via HTTPS. O arquivo [`routes/web.php`](routes/web.php:1) está configurado corretamente:

```php
Route::get('/', function () {
    return view('\''landing'\'');
});
```

## 🚀 Execute na VPS (em ordem):

### Passo 1: Verificar se a view `landing` existe
```bash
ls -la resources/views/landing.blade.php
```

**Resultado esperado:**
```
-rw-r--r-- 1 root root ... resources/views/landing.blade.php
```

### Passo 2: Se a view não existir, verificar quais views existem
```bash
ls -la resources/views/
```

### Passo 3: Limpar o cache do Laravel
```bash
docker compose -f docker-compose.prod.yml exec app php artisan cache:clear
docker compose -f docker-compose.prod.yml exec app php artisan config:clear
docker compose -f docker-compose.prod.yml exec app php artisan view:clear
docker compose -f docker-compose.prod.yml exec app php artisan route:clear
```

### Passo 4: Verificar logs do Nginx
```bash
docker logs cobranca_nginx --tail 50
```

### Passo 5: Verificar logs do app
```bash
docker logs cobranca_app --tail 50
```

### Passo 6: Testar o site
```bash
curl -I http://localhost
curl -I http://localhost/index.php
curl -I https://api.cobrancaauto.com.br/
```

## 📋 Se a view `landing` não existir

Se a view `landing` não existir, crie-a:

```bash
# Criar a view landing
cat > resources/views/landing.blade.php << '\''EOF'\''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cobrança Automática</title>
</head>
<body>
    <h1>Cobrança automática por WhatsApp para vender seu PlayStation 5 R$3.000</h1>
    <p>Lembretes D-3/D-1/Vencida + histórico + status pagamento</p>
    <div>
        <a href="/painel" class="inline-block bg-blue-600 text-white px-4 py-2 rounded mr-2">Testar grátis 7 dias</a>
        <a href="https://wa.me/qr/5UYGQNHBGZVKC1" class="inline-block bg-green-600 text-white px-4 py-2 rounded">Falar venda PS5</a>
    </div>
</body>
</html>
EOF'
```

## 📋 Se o Nginx não estiver encontrando os arquivos

Se o Nginx não estiver encontrando os arquivos, verifique a configuração:

```bash
# Verificar configuração do Nginx
cat /var/www/cobranca-api/nginx-ssl.conf

# Verificar se o caminho está correto
grep "root" /var/www/cobranca-api/nginx-ssl.conf
```

**Resultado esperado:**
```
root /var/www/public;
```

## 🎯 Resumo

1. Verificar se a view `landing` existe
2. Limpar o cache do Laravel
3. Verificar logs do Nginx e do app
4. Testar o site

Execute os comandos acima na VPS e me envie os resultados!

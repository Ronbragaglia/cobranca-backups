# 🔧 CORRIGIR ERRO SALES SETTINGS

## 📋 PROBLEMA IDENTIFICADO

**Erro:** `Illuminate\Contracts\Container\BindingResolutionException`
**Mensagem:** `A classe de destino [SalesSettingsController] não existe.`

**Causa:** O arquivo [`app/Http/Controllers/SalesSettingsController.php`](app/Http/Controllers/SalesSettingsController.php) não foi criado corretamente ou não está no local correto.

## 🔧 SOLUÇÃO

### Passo 1: Criar controller corretamente

```bash
# Criar controller na VPS
cat > /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php << 'EOF'
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SalesSettingsController extends Controller
{
    /**
     * Exibir configurações de vendas
     */
    public function index()
    {
        $whatsappNumber = env('WHATSAPP_SALES_NUMBER', '');
        $whatsappMessage = env('WHATSAPP_SALES_MESSAGE', '');
        
        return view('sales-settings', compact('whatsappNumber', 'whatsappMessage'));
    }

    /**
     * Atualizar configurações de vendas
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'whatsapp_number' => 'required|string|max:20',
            'whatsapp_message' => 'required|string|max:500',
        ]);

        // Atualizar .env
        $envFile = base_path('.env');
        $envContent = file_get_contents($envFile);
        
        // Adicionar ou atualizar WHATSAPP_SALES_NUMBER
        if (strpos($envContent, 'WHATSAPP_SALES_NUMBER') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_NUMBER=.*/m',
                "WHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}";
        }
        
        // Adicionar ou atualizar WHATSAPP_SALES_MESSAGE
        if (strpos($envContent, 'WHATSAPP_SALES_MESSAGE') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_MESSAGE=.*/m',
                "WHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"";
        }
        
        file_put_contents($envFile, $envContent);

        // Limpar cache
        Cache::flush();

        return redirect()->back()->with('success', 'Configurações atualizadas com sucesso!');
    }
}
EOF
```

### Passo 2: Criar view corretamente

```bash
# Criar view na VPS
cat > /var/www/cobranca-api/resources/views/sales-settings.blade.php << 'EOF'
@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-bold mb-6">Configurações de Vendas</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('sales-settings.update') }}" method="POST">
        @csrf

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Número de WhatsApp</label>
            <input 
                type="text" 
                name="whatsapp_number" 
                value="{{ old('whatsapp_number', $whatsappNumber) }}"
                class="w-full px-3 py-2 border rounded-md"
                placeholder="5511999999999"
                required
            >
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Mensagem Padrão</label>
            <textarea 
                name="whatsapp_message" 
                rows="4"
                class="w-full px-3 py-2 border rounded-md"
                required
            >{{ old('whatsapp_message', $whatsappMessage) }}</textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Salvar Configurações
        </button>
    </form>
</div>
@endsection
EOF
```

### Passo 3: Verificar se controller existe

```bash
# Verificar se controller existe
ls -la /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php
```

### Passo 4: Verificar se view existe

```bash
# Verificar se view existe
ls -la /var/www/cobranca-api/resources/views/sales-settings.blade.php
```

### Passo 5: Limpar cache

```bash
cd /var/www/cobranca-api
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Passo 6: Verificar rotas

```bash
# Verificar se rotas existem
grep "sales-settings" /var/www/cobranca-api/routes/web.php
```

## 📋 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

```bash
# Passo 1: Criar controller
cat > /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php << 'EOF'
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SalesSettingsController extends Controller
{
    public function index()
    {
        $whatsappNumber = env('WHATSAPP_SALES_NUMBER', '');
        $whatsappMessage = env('WHATSAPP_SALES_MESSAGE', '');
        return view('sales-settings', compact('whatsappNumber', 'whatsappMessage'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'whatsapp_number' => 'required|string|max:20',
            'whatsapp_message' => 'required|string|max:500',
        ]);

        $envFile = base_path('.env');
        $envContent = file_get_contents($envFile);
        
        if (strpos($envContent, 'WHATSAPP_SALES_NUMBER') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_NUMBER=.*/m',
                "WHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}";
        }
        
        if (strpos($envContent, 'WHATSAPP_SALES_MESSAGE') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_MESSAGE=.*/m',
                "WHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"";
        }
        
        file_put_contents($envFile, $envContent);
        Cache::flush();

        return redirect()->back()->with('success', 'Configurações atualizadas com sucesso!');
    }
}
EOF

# Passo 2: Criar view
cat > /var/www/cobranca-api/resources/views/sales-settings.blade.php << 'EOF'
@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-bold mb-6">Configurações de Vendas</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('sales-settings.update') }}" method="POST">
        @csrf

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Número de WhatsApp</label>
            <input 
                type="text" 
                name="whatsapp_number" 
                value="{{ old('whatsapp_number', $whatsappNumber) }}"
                class="w-full px-3 py-2 border rounded-md"
                placeholder="5511999999999"
                required
            >
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Mensagem Padrão</label>
            <textarea 
                name="whatsapp_message" 
                rows="4"
                class="w-full px-3 py-2 border rounded-md"
                required
            >{{ old('whatsapp_message', $whatsappMessage) }}</textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Salvar Configurações
        </button>
    </form>
</div>
@endsection
EOF

# Passo 3: Limpar cache
cd /var/www/cobranca-api
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 4: Verificar controller
ls -la /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php

# Passo 5: Verificar view
ls -la /var/www/cobranca-api/resources/views/sales-settings.blade.php

# Passo 6: Verificar rotas
grep "sales-settings" /var/www/cobranca-api/routes/web.php

echo ""
echo "=========================================="
echo "✅ CORREÇÃO CONCLUÍDA!"
echo "=========================================="
echo ""
echo "📋 PRÓXIMOS PASSOS:"
echo ""
echo "1. Acessar: https://api.cobrancaauto.com.br/login"
echo "2. Fazer login com: admin@cobranca.com / 123456"
echo "3. Acessar: https://api.cobrancaauto.com.br/sales-settings"
echo "4. Configurar número de WhatsApp: 5511954092078"
echo "5. Configurar mensagem padrão"
echo "6. Salvar configurações"
echo ""
echo "=========================================="
echo "💚 CORREÇÃO CONCLUÍDA!"
echo "=========================================="
```

## 📋 VERIFICAÇÕES

### Verificar se controller foi criado

```bash
ls -la /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php
```

### Verificar se view foi criada

```bash
ls -la /var/www/cobranca-api/resources/views/sales-settings.blade.php
```

### Verificar conteúdo do controller

```bash
cat /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php
```

### Verificar conteúdo da view

```bash
cat /var/www/cobranca-api/resources/views/sales-settings.blade.php
```

### Testar rota

```bash
curl -I https://api.cobrancaauto.com.br/sales-settings
```

## 💚 SUCESSO FINAL

**✅ Controller SalesSettingsController criado**
**✅ View sales-settings.blade.php criada**
**✅ Cache limpo**
**✅ Erro corrigido**

**Acesse: https://api.cobrancaauto.com.br/sales-settings**

**Erro corrigido = Site funcionando = 💸**

# 🔧 REMOVER COLUNA AO LADO DO VÍDEO

## 📋 ANÁLISE

O vídeo está dentro de um container com `grid lg:grid-cols-2`, o que significa que há duas colunas. Precisamos remover a coluna ao lado do vídeo.

## 📋 PASSO 1: VERIFICAR ESTRUTURA COMPLETA

```bash
cd /var/www/cobranca-api

# Verificar estrutura do container grid
grep -n -B 5 -A 50 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php | head -80
```

## 📋 PASSO 2: REMOVER COLUNA AO LADO DO VÍDEO

### Opção 1: Remover coluna direita do grid (RECOMENDADO)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para remover coluna ao lado do vídeo
cat > /tmp/remove_column.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Encontrar o container grid
grid_pattern = r'(<div[^>]*class="[^"]*grid[^"]*lg:grid-cols-2[^"]*"[^>]*>)(.*?)(</div>\s*</div>)'
match = re.search(grid_pattern, content, flags=re.DOTALL)

if match:
    grid_content = match.group(2)
    
    # Dividir em duas colunas
    # A primeira coluna é o conteúdo à esquerda (incluindo o vídeo)
    # A segunda coluna é o conteúdo à direita (que queremos remover)
    
    # Encontrar o fechamento da primeira coluna
    # Procurar por padrões comuns de fechamento de coluna
    col1_end_patterns = [
        r'(</div>\s*</div>\s*<!--.*?-->\s*<div[^>]*class="[^"]*text-white[^"]*"[^>]*>)',
        r'(</div>\s*</div>\s*<div[^>]*class="[^"]*text-white[^"]*"[^>]*>)',
        r'(</div>\s*</div>\s*<div[^>]*class="[^"]*grid[^"]*"[^>]*>)',
    ]
    
    for pattern in col1_end_patterns:
        col1_match = re.search(pattern, grid_content, flags=re.DOTALL)
        if col1_match:
            # Manter apenas a primeira coluna
            new_grid_content = grid_content[:col1_match.end()]
            # Remover o resto (segunda coluna)
            new_grid_content = re.sub(r'<div[^>]*class="[^"]*text-white[^"]*"[^>]*>.*?</div>\s*</div>', '', new_grid_content, flags=re.DOTALL)
            
            # Substituir o grid original
            content = content[:match.start()] + match.group(1) + new_grid_content + match.group(3) + content[match.end():]
            print("✅ Coluna ao lado do vídeo removida!")
            break
    else:
        print("⚠️ Não foi possível encontrar a separação das colunas")
else:
    print("⚠️ Não foi possível encontrar o container grid")

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/remove_column.py

# Limpar script temporário
rm -f /tmp/remove_column.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar estrutura
grep -n -B 5 -A 30 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Opção 2: Remover manualmente (se Python não funcionar)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Verificar estrutura
grep -n -B 5 -A 50 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php | head -80

# Anotar os números das linhas da segunda coluna
# Depois remover manualmente usando sed
# Exemplo: sed -i 'LINHA_INICIAL,LINHA_FINALd' resources/views/landing.blade.php
```

### Opção 3: Usar vídeo local e remover coluna (MAIS SIMPLES)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para usar vídeo local e remover coluna
cat > /tmp/use_local_video.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Substituir vídeo do YouTube por vídeo local
content = re.sub(
    r'<iframe[^>]*src="https://www\.youtube\.com/embed/[^"]*"[^>]*></iframe>',
    '''<video controls class="w-full h-full">
        <source src="/videos/demo-cobranca.mp4" type="video/mp4">
        Seu navegador não suporta vídeos.
    </video>''',
    content,
    flags=re.DOTALL
)

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Vídeo substituído por vídeo local!")
PYEOF

# Executar script Python
python3 /tmp/use_local_video.py

# Limpar script temporário
rm -f /tmp/use_local_video.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar estrutura
grep -n -B 5 -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

## 📋 VERIFICAÇÕES

### Verificar estrutura do grid

```bash
grep -n -B 5 -A 30 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar se o vídeo está correto

```bash
grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

OU

```bash
grep -n -B 5 -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Acessar site no navegador

```
https://api.cobrancaauto.com.br
```

## 📋 SOLUÇÃO DE PROBLEMAS

### Problema: Coluna ainda aparece

**Solução:** Verificar estrutura completa do arquivo

```bash
# Verificar todo o conteúdo do grid
grep -n -A 100 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php | head -120
```

### Problema: Vídeo não carrega

**Solução:** Usar vídeo local (Opção 3)

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Verificar estrutura primeiro

```bash
cd /var/www/cobranca-api
grep -n -B 5 -A 50 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php | head -80
```

### Opção 1: Remover coluna direita do grid (RECOMENDADO)

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/remove_column.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

grid_pattern = r'(<div[^>]*class="[^"]*grid[^"]*lg:grid-cols-2[^"]*"[^>]*>)(.*?)(</div>\s*</div>)'
match = re.search(grid_pattern, content, flags=re.DOTALL)

if match:
    grid_content = match.group(2)
    
    col1_end_patterns = [
        r'(</div>\s*</div>\s*<!--.*?-->\s*<div[^>]*class="[^"]*text-white[^"]*"[^>]*>)',
        r'(</div>\s*</div>\s*<div[^>]*class="[^"]*text-white[^"]*"[^>]*>)',
        r'(</div>\s*</div>\s*<div[^>]*class="[^"]*grid[^"]*"[^>]*>)',
    ]
    
    for pattern in col1_end_patterns:
        col1_match = re.search(pattern, grid_content, flags=re.DOTALL)
        if col1_match:
            new_grid_content = grid_content[:col1_match.end()]
            new_grid_content = re.sub(r'<div[^>]*class="[^"]*text-white[^"]*"[^>]*>.*?</div>\s*</div>', '', new_grid_content, flags=re.DOTALL)
            content = content[:match.start()] + match.group(1) + new_grid_content + match.group(3) + content[match.end():]
            print("✅ Coluna ao lado do vídeo removida!")
            break
    else:
        print("⚠️ Não foi possível encontrar a separação das colunas")
else:
    print("⚠️ Não foi possível encontrar o container grid")

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

python3 /tmp/remove_column.py
rm -f /tmp/remove_column.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -n -B 5 -A 30 'grid lg:grid-cols-2' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Opção 3: Usar vídeo local (MAIS SIMPLES)

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/use_local_video.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(
    r'<iframe[^>]*src="https://www\.youtube\.com/embed/[^"]*"[^>]*></iframe>',
    '''<video controls class="w-full h-full">
        <source src="/videos/demo-cobranca.mp4" type="video/mp4">
        Seu navegador não suporta vídeos.
    </video>''',
    content,
    flags=re.DOTALL
)

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Vídeo substituído por vídeo local!")
PYEOF

python3 /tmp/use_local_video.py
rm -f /tmp/use_local_video.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -n -B 5 -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

---

**Execute os comandos acima para remover a coluna ao lado do vídeo! 🚀**

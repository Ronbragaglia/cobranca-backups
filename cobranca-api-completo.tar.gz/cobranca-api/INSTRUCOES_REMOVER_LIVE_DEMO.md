# 🔧 REMOVER LIVE DEMO AO LADO DO VÍDEO

## 📋 OBJETIVO

Remover a seção "Live Demo" que fica ao lado do vídeo na página inicial.

## 📋 PASSO 1: VERIFICAR ESTRUTURA DO ARQUIVO

```bash
cd /var/www/cobranca-api

# Verificar estrutura do arquivo ao redor do vídeo
grep -n -B 20 -A 20 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

## 📋 PASSO 2: REMOVER LIVE DEMO

### Opção 1: Remover usando Python (RECOMENDADO)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para remover Live Demo
cat > /tmp/remove_live_demo.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Remover seção Live Demo
# Procurar por padrões comuns de Live Demo
patterns = [
    r'<!--.*?Live Demo.*?-->',
    r'{{--.*?Live Demo.*?--}}',
    r'<div[^>]*class="[^"]*live[^"]*demo[^"]*"[^>]*>.*?</div>',
    r'<div[^>]*class="[^"]*demo[^"]*live[^"]*"[^>]*>.*?</div>',
    r'Live Demo',
    r'live-demo',
    r'live_demo',
]

# Tentar remover seção Live Demo
for pattern in patterns:
    # Procurar pelo texto "Live Demo" e remover a seção inteira
    if 'Live Demo' in content:
        # Encontrar a seção Live Demo
        match = re.search(r'(<div[^>]*>.*?Live Demo.*?</div>)', content, flags=re.DOTALL | re.IGNORECASE)
        if match:
            content = content.replace(match.group(0), '')
            print(f"✅ Seção Live Demo removida: {match.group(0)[:100]}...")
            break
        else:
            # Tentar remover apenas o texto
            content = re.sub(r'Live Demo', '', content, flags=re.IGNORECASE)
            print("✅ Texto 'Live Demo' removido")
            break
    else:
        # Procurar por variações
        if re.search(r'live[-_]demo', content, flags=re.IGNORECASE):
            content = re.sub(r'<div[^>]*class="[^"]*live[-_]demo[^"]*"[^>]*>.*?</div>', '', content, flags=re.DOTALL | re.IGNORECASE)
            print("✅ Seção live-demo removida")
            break

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/remove_live_demo.py

# Limpar script temporário
rm -f /tmp/remove_live_demo.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar se Live Demo foi removida
grep -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php || echo "✅ Live Demo removida com sucesso!"
```

### Opção 2: Remover manualmente (se Python não funcionar)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Verificar onde está o Live Demo
grep -n -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php

# Remover manualmente usando sed
sed -i '/Live Demo/d' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar se Live Demo foi removida
grep -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php || echo "✅ Live Demo removida com sucesso!"
```

## 📋 VERIFICAÇÕES

### Verificar se Live Demo foi removida

```bash
grep -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php
```

Se não retornar nada, significa que foi removida com sucesso!

### Verificar estrutura do arquivo

```bash
grep -n -B 10 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Acessar site no navegador

```
https://api.cobrancaauto.com.br
```

## 📋 SOLUÇÃO DE PROBLEMAS

### Problema: Live Demo ainda aparece

**Solução:** Verificar se há variações do nome

```bash
# Procurar por variações
grep -i -E 'live.*demo|demo.*live|live-demo|live_demo' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Problema: Erro ao executar script Python

**Solução:** Verificar se Python3 está instalado

```bash
python3 --version
```

Se não estiver instalado:

```bash
apt update && apt install -y python3
```

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Opção 1: Remover usando Python (RECOMENDADO)

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/remove_live_demo.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

if 'Live Demo' in content:
    match = re.search(r'(<div[^>]*>.*?Live Demo.*?</div>)', content, flags=re.DOTALL | re.IGNORECASE)
    if match:
        content = content.replace(match.group(0), '')
        print(f"✅ Seção Live Demo removida: {match.group(0)[:100]}...")
    else:
        content = re.sub(r'Live Demo', '', content, flags=re.IGNORECASE)
        print("✅ Texto 'Live Demo' removido")
elif re.search(r'live[-_]demo', content, flags=re.IGNORECASE):
    content = re.sub(r'<div[^>]*class="[^"]*live[-_]demo[^"]*"[^>]*>.*?</div>', '', content, flags=re.DOTALL | re.IGNORECASE)
    print("✅ Seção live-demo removida")
else:
    print("⚠️ Não foi possível encontrar Live Demo")

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

python3 /tmp/remove_live_demo.py
rm -f /tmp/remove_live_demo.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php || echo "✅ Live Demo removida com sucesso!"
```

### Opção 2: Remover manualmente

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

grep -n -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php
sed -i '/Live Demo/d' resources/views/landing.blade.php

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -i 'live demo' /var/www/cobranca-api/resources/views/landing.blade.php || echo "✅ Live Demo removida com sucesso!"
```

### Verificar estrutura do arquivo

```bash
grep -n -B 10 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

---

**Execute os comandos acima para remover a Live Demo! 🚀**

# 🔥 EXECUTAR FIX 502 MANUALMENTE - INSTRUÇÕES COMPLETAS

## 📋 RESUMO RÁPIDO (2 MINUTOS)

### Passo 1: Conectar na VPS
```bash
ssh root@76.13.167.54
```

### Passo 2: Executar comandos de fix
```bash
# Reiniciar serviços
systemctl restart php8.2-fpm
systemctl restart nginx

# Corrigir permissões
chown -R www-data:www-data /var/www/cobranca-api
chmod -R 755 /var/www/cobranca-api
chmod -R 775 /var/www/cobranca-api/storage
chmod -R 775 /var/www/cobranca-api/bootstrap/cache

# Corrigir permissões do socket
chmod 666 /var/run/php/php8.2-fpm.sock

# Criar configuração NGINX correta
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# Testar e reiniciar NGINX
nginx -t
systemctl restart nginx

# Criar arquivo de teste
cat > /var/www/cobranca-api/public/test-php.php << 'EOF'
<?php
phpinfo();
EOF
chown www-data:www-data /var/www/cobranca-api/public/test-php.php

# Testar
curl -I http://localhost/test-php.php
```

### Passo 3: Testar no navegador
```
http://api.cobrancaauto.com.br
http://api.cobrancaauto.com.br/api/status
```

### Passo 4: Limpar teste (após funcionar)
```bash
rm /var/www/cobranca-api/public/test-php.php
```

---

## 📚 INSTRUÇÕES DETALHADAS

### 1. DIAGNÓSTICO INICIAL

```bash
# Verificar PHP-FPM
systemctl status php8.2-fpm

# Verificar NGINX
systemctl status nginx

# Verificar socket
ls -la /var/run/php/php8.2-fpm.sock

# Verificar logs
tail -20 /var/log/nginx/error.log
tail -20 /var/log/php8.2-fpm.log
```

### 2. CORRIGIR CONFIGURAÇÃO NGINX

```bash
# Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup

# Criar configuração correta
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# Testar configuração
nginx -t

# Se der erro, verificar o que está errado
cat /etc/nginx/sites-available/cobranca-api
```

### 3. CORRIGIR PERMISSÕES

```bash
# Permissões do Laravel
cd /var/www/cobranca-api
chown -R www-data:www-data /var/www/cobranca-api
chmod -R 755 /var/www/cobranca-api
chmod -R 775 /var/www/cobranca-api/storage
chmod -R 775 /var/www/cobranca-api/bootstrap/cache

# Permissões do socket PHP-FPM
chmod 666 /var/run/php/php8.2-fpm.sock
```

### 4. REINICIAR SERVIÇOS

```bash
# Reiniciar PHP-FPM
systemctl restart php8.2-fpm
systemctl status php8.2-fpm

# Reiniciar NGINX
systemctl restart nginx
systemctl status nginx

# Reiniciar MySQL (se necessário)
systemctl restart mysql
```

### 5. CRIAR ARQUIVO DE TESTE

```bash
# Criar arquivo de teste PHP
cat > /var/www/cobranca-api/public/test-php.php << 'EOF'
<?php
phpinfo();
EOF

# Corrigir permissões
chown www-data:www-data /var/www/cobranca-api/public/test-php.php
```

### 6. TESTAR SOLUÇÃO

```bash
# Testar via curl
curl -I http://localhost/test-php.php

# Deve retornar HTTP 200 OK

# Testar site principal
curl -I http://localhost/

# Testar API
curl http://localhost/api/status

# Deve retornar: {"ok":true}
```

### 7. VERIFICAR NO NAVEGADOR

Abra o navegador e acesse:
- http://api.cobrancaauto.com.br
- http://api.cobrancaauto.com.br/api/status
- http://api.cobrancaauto.com.br/test-php.php

### 8. LIMPAR TESTE

```bash
# Remover arquivo de teste
rm /var/www/cobranca-api/public/test-php.php
```

---

## 🔧 SOLUÇÃO DE PROBLEMAS

### Problema 1: Socket não existe

```bash
# Reiniciar PHP-FPM
systemctl restart php8.2-fpm

# Verificar se foi criado
ls -la /var/run/php/php8.2-fpm.sock
```

### Problema 2: Permissão negada no socket

```bash
# Corrigir permissões
chmod 666 /var/run/php/php8.2-fpm.sock

# Ou reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

### Problema 3: Configuração NGINX com erro

```bash
# Verificar erro
nginx -t

# Verificar configuração
cat /etc/nginx/sites-available/cobranca-api

# Restaurar backup se necessário
cp /etc/nginx/sites-available/cobranca-api.backup /etc/nginx/sites-available/cobranca-api
```

### Problema 4: Ainda 502 após tudo

```bash
# Verificar logs
tail -50 /var/log/nginx/error.log
tail -50 /var/log/php8.2-fpm.log

# Reiniciar tudo
systemctl restart php8.2-fpm
systemctl restart nginx
systemctl restart mysql

# Último recurso: reiniciar servidor
reboot
```

---

## 📊 MONITORAMENTO

### Verificar logs em tempo real

```bash
# Terminal 1: NGINX
tail -f /var/log/nginx/error.log

# Terminal 2: PHP-FPM
tail -f /var/log/php8.2-fpm.log
```

### Verificar conexões

```bash
# Conexões PHP-FPM
ss -x | grep php

# Conexões NGINX
ss -tlnp | grep :80
```

---

## ✅ VERIFICAÇÃO FINAL

Após executar todos os passos:

```bash
# Testar API
curl http://api.cobrancaauto.com.br/api/status

# Deve retornar: {"ok":true}

# Testar no navegador
http://api.cobrancaauto.com.br
```

Se funcionar, você verá:
- Site carregando no navegador
- Resposta HTTP 200 OK
- Arquivo test-php.php mostrando phpinfo()
- Sem erros nos logs

---

## 📁 ARQUIVOS CRIADOS PARA SOLUÇÃO

1. **[`scripts/fix-502-nginx-php-urgente.sh`](scripts/fix-502-nginx-php-urgente.sh)** - Script automático
2. **[`scripts/executar-fix-502-remoto.sh`](scripts/executar-fix-502-remoto.sh)** - Script para execução remota
3. **[`EXECUTAR_FIX_502_AGORA.md`](EXECUTAR_FIX_502_AGORA.md)** - Instruções rápidas
4. **[`COMANDOS_FIX_502_RAPIDO.txt`](COMANDOS_FIX_502_RAPIDO.txt)** - Comandos rápidos
5. **[`docs/TECNICO_FIX_502_NGINX_PHP.md`](docs/TECNICO_FIX_502_NGINX_PHP.md)** - Documentação técnica
6. **[`DIAGNOSTICO_SOLUCAO_502.md`](DIAGNOSTICO_SOLUCAO_502.md)** - Diagnóstico atualizado
7. **[`INSTRUCOES_MANUAL_FIX_502.md`](INSTRUCOES_MANUAL_FIX_502.md)** - Instruções manuais

---

## 💚 SUCESSO!

Execute os comandos acima na VPS e o site voltará a funcionar imediatamente!

**Site funcionando = Cliente feliz = 💸**

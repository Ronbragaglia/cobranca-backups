# PRÓXIMOS PASSOS - REINICIAR CONTAINERS E TESTAR

## ✅ Nginx corrigido com sucesso!

Agora precisamos reiniciar os containers para expor a porta 9000.

---

## 🚀 COMANDOS PARA EXECUTAR

```bash
# 1. Parar containers
docker-compose -f docker-compose.prod.yml down

# 2. Subir containers novamente
docker-compose -f docker-compose.prod.yml up -d

# 3. Aguardar 30 segundos
sleep 30

# 4. Verificar status dos containers
docker-compose -f docker-compose.prod.yml ps

# 5. Verificar se a porta 9000 está exposta
docker port cobranca_app

# 6. Testar conexão com o PHP-FPM
curl -I http://127.0.0.1:9000

# 7. Testar health check
curl https://api.cobrancaauto.com.br/health

# 8. Testar site
curl https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após executar `docker-compose -f docker-compose.prod.yml ps`:

```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

### Após executar `docker port cobranca_app`:

```
9000/tcp -> 127.0.0.1:9000
```

### Após executar `curl -I http://127.0.0.1:9000`:

```
HTTP/1.1 404 Not Found
```

(Algum erro do PHP-FPM, o que indica que está respondendo)

### Após executar `curl https://api.cobrancaauto.com.br/health`:

```
{"status":"ok"}
```

(ou similar)

### Após executar `curl https://api.cobrancaauto.com.br/`:

```
<!DOCTYPE html>
<html>
...
```

(HTML ou JSON, não 502)

---

## 🔍 SE A PORTA 9000 AINDA NÃO ESTIVER EXPOSTA

Se `docker port cobranca_app` ainda não mostrar nada, execute:

```bash
# Verificar se o container está rodando
docker ps | grep cobranca_app

# Verificar logs do container
docker logs cobranca_app

# Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

---

## 📝 CHECKLIST

- [ ] Containers reiniciados
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔧 SOLUÇÃO - 404 NO INDEX.PHP

## 📋 Problema Identificado

O app está retornando "404" para todas as requisições para `/index.php`:
```
cobranca_app | 172.18.0.2 - 05/Feb/2026:03:09:45 +0000 "GET /index.php" 404
```

Isso indica que o Nginx não está encontrando os arquivos.

## 🚀 Execute na VPS (em ordem):

### Passo 1: Verificar se o arquivo `index.php` existe
```bash
ls -la /var/www/cobranca-api/public/index.php
```

**Resultado esperado:**
```
-rw-r--r-- 1 root root ... /var/www/cobranca-api/public/index.php
```

### Passo 2: Verificar configuração do Nginx
```bash
cat /etc/nginx/conf.d/cobranca-api.conf
```

### Passo 3: Verificar se o caminho `root` está correto
```bash
grep "root" /etc/nginx/conf.d/cobranca-api.conf
```

**Resultado esperado:**
```
root /var/www/cobranca-api/public;
```

### Passo 4: Se o caminho estiver errado, corrigir
```bash
# Editar configuração do Nginx
nano /etc/nginx/conf.d/cobranca-api.conf

# Alterar esta linha:
# root /var/www;

# Para:
# root /var/www/cobranca-api/public;

# Salvar e sair
```

### Passo 5: Reiniciar o Nginx
```bash
docker compose -f docker-compose.prod.yml restart nginx
```

### Passo 6: Verificar logs do Nginx
```bash
docker compose -f docker-compose.prod.yml logs --tail=20 nginx
```

### Passo 7: Verificar logs do app
```bash
docker compose -f docker-compose.prod.yml logs --tail=20 app
```

### Passo 8: Testar o site
```bash
curl -I http://localhost
curl -I http://localhost/index.php
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se o arquivo `index.php` não existir

Se o arquivo `index.php` não existir, crie-o:

```bash
# Criar arquivo index.php
cat > /var/www/cobranca-api/public/index.php << 'EOF'
<?php

define('LARAVEL_START', microtime(true));

require __DIR__.'/../vendor/autoload.php';

$app = require_once __DIR__.'/../bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);

$response = $kernel->handle(
    $request = Illuminate\Http\Request::capture()
);

$response->send();

$kernel->terminate($request, $response);

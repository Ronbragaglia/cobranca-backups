# DIAGNÓSTICO PORTA 9000 NÃO EXPOSTA

## 🚨 PROBLEMA

A porta 9000 não está sendo exposta (`docker port cobranca_app` não mostra nada) mesmo que o container esteja rodando.

## ✅ DIAGNÓSTICO

### PASSO 1: Verificar docker-compose.prod.yml

```bash
grep -A 10 "app:" /var/www/cobranca-api/docker-compose.prod.yml | head -20
```

**Deveria mostrar:**
```
app:
  build: .
  container_name: cobranca_app
  restart: unless-stopped
  ports:
    - "127.0.0.1:9000:9000"
```

### PASSO 2: Verificar logs do container app

```bash
docker logs cobranca_app | tail -50
```

### PASSO 3: Verificar se o PHP-FPM está rodando

```bash
docker exec cobranca_app ps aux | grep php-fpm
```

### PASSO 4: Verificar se o PHP-FPM está escutando

```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

### PASSO 5: Verificar logs do container queue

```bash
docker logs cobranca_queue | tail -50
```

### PASSO 6: Verificar configuração do PHP-FPM

```bash
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf | grep listen
```

---

## 🔧 SOLUÇÃO 1: RECONSTRUIR CONTAINERS

Se o docker-compose.prod.yml estiver correto, tente reconstruir os containers:

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Remover imagens antigas
docker rmi $(docker images | grep cobranca | awk '{print $3}') 2>/dev/null

# Reconstruir e subir containers
docker-compose -f docker-compose.prod.yml up -d --build

# Aguardar 30 segundos
sleep 30

# Verificar status
docker-compose -f docker-compose.prod.yml ps

# Verificar se a porta está exposta
docker port cobranca_app
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR SE HÁ CONFLITO DE PORTA

Se a porta 9000 já estiver em uso no host:

```bash
# Verificar se a porta 9000 está em uso no host
netstat -tlnp | grep 9000

# Se estiver em uso, pare o processo que está usando
# ou use outra porta (ex: 9001)
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE O DOCKER ESTÁ EM SWARM MODE

O aviso "The Docker Engine you're using is running in swarm mode" pode estar causando problemas:

```bash
# Verificar se o Docker está em swarm mode
docker info | grep Swarm

# Se estiver em swarm mode, pode ser necessário sair do swarm
# ATENÇÃO: Isso pode afetar outros containers
docker swarm leave --force
```

---

## 🔧 SOLUÇÃO 4: USAR DOCKER RUN DIRETO

Se nada funcionar, tente executar o container diretamente:

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Executar container app diretamente
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  --network cobranca-api_cobranca_network \
  cobranca-api_app \
  php-fpm

# Verificar se a porta está exposta
docker port cobranca_app

# Testar conexão
curl -I http://127.0.0.1:9000
```

---

## 📝 RESUMO

### O que verificar:

1. Se o docker-compose.prod.yml tem a configuração de ports correta
2. Se o PHP-FPM está rodando no container
3. Se o PHP-FPM está escutando na porta 9000
4. Se há conflito de porta no host
5. Se o Docker está em swarm mode

---

## 🚀 COMANDOS COMPLETOS PARA DIAGNÓSTICO

```bash
# 1. Verificar docker-compose.prod.yml
grep -A 10 "app:" /var/www/cobranca-api/docker-compose.prod.yml | head -20

# 2. Verificar logs do container app
docker logs cobranca_app | tail -50

# 3. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# 4. Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000

# 5. Verificar logs do container queue
docker logs cobranca_queue | tail -50

# 6. Verificar configuração do PHP-FPM
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf | grep listen

# 7. Verificar se a porta 9000 está em uso no host
netstat -tlnp | grep 9000

# 8. Verificar se o Docker está em swarm mode
docker info | grep Swarm
```

---

## 🚀 COMANDOS PARA SOLUÇÃO 1 (RECONSTRUIR)

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Remover imagens antigas
docker rmi $(docker images | grep cobranca | awk '{print $3}') 2>/dev/null

# Reconstruir e subir containers
docker-compose -f docker-compose.prod.yml up -d --build

# Aguardar 30 segundos
sleep 30

# Verificar status
docker-compose -f docker-compose.prod.yml ps

# Verificar se a porta está exposta
docker port cobranca_app

# Testar conexão
curl -I http://127.0.0.1:9000
```

---

## 🚀 COMANDOS PARA SOLUÇÃO 3 (SAIR DO SWARM)

```bash
# Verificar se o Docker está em swarm mode
docker info | grep Swarm

# Se estiver em swarm mode, sair do swarm
# ATENÇÃO: Isso pode afetar outros containers
docker swarm leave --force

# Reiniciar containers
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d

# Aguardar 30 segundos
sleep 30

# Verificar se a porta está exposta
docker port cobranca_app

# Testar conexão
curl -I http://127.0.0.1:9000
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# RESOLVER FINAL - TRAZER SITE DE VOLTA

## 🚨 PROBLEMA

O container `cobranca_app` está rodando, mas a porta 9000 não está exposta.

## ✅ SOLUÇÃO FINAL

Execute estes comandos em ordem:

```bash
# 1. Parar o container app
docker stop cobranca_app

# 2. Remover o container app
docker rm cobranca_app

# 3. Criar um novo container com a porta exposta
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  --network cobranca-api_cobranca_network \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  cobranca-api_app \
  php-fpm

# 4. Aguardar 10 segundos
sleep 10

# 5. Verificar se a porta está exposta
docker port cobranca_app

# 6. Testar conexão
curl -I http://127.0.0.1:9000

# 7. Testar health check
curl https://api.cobrancaauto.com.br/health

# 8. Testar site
curl https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `docker port cobranca_app`:
```
9000/tcp -> 127.0.0.1:9000
```

### Após `curl -I http://127.0.0.1:9000`:
```
HTTP/1.1 404 Not Found
```

### Após `curl https://api.cobrancaauto.com.br/health`:
```
{"status":"ok"}
```

### Após `curl https://api.cobrancaauto.com.br/`:
HTML ou JSON (não 502)

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar se a imagem existe
docker images | grep cobranca-api_app

# Se não existir, reconstruir
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml build app

# Tentar novamente
docker stop cobranca_app
docker rm cobranca_app
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  --network cobranca-api_cobranca_network \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  cobranca-api_app \
  php-fpm
```

---

## 📝 CHECKLIST

- [ ] Container cobranca_app parado
- [ ] Container cobranca_app removido
- [ ] Novo container criado com porta exposta
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

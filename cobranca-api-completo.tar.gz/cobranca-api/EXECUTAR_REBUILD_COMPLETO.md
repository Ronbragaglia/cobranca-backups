# EXECUTAR REBUILD COMPLETO - ÚLTIMA SOLUÇÃO

## 🚨 PROBLEMA

A porta 9000 do PHP-FPM não está sendo exposta para o host, mesmo com a configuração correta no docker-compose.prod.yml.

**Causa:** Docker está usando cache de build/containers antigos.

---

## ✅ SOLUÇÃO FINAL

Execute estes comandos na VPS, em ordem:

### 1. Dar permissão de execução ao script

```bash
chmod +x rebuild-completo.sh
```

### 2. Executar script de rebuild completo

```bash
./rebuild-completo.sh
```

Este script vai:
1. Parar e remover todos os containers
2. Remover imagens antigas (força rebuild)
3. Buildar novas imagens com todas as mudanças
4. Subir containers com nova configuração
5. Verificar se a porta 9000 está exposta

### 3. Verificar se a porta 9000 está exposta

Após o script terminar, execute:

```bash
netstat -tlnp | grep 9000
```

**Deveria mostrar:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

Se NÃO mostrar isso, execute manualmente:

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Remover containers e volumes
docker-compose -f docker-compose.prod.yml down -v

# Subir containers
docker-compose -f docker-compose.prod.yml up -d

# Verificar novamente
netstat -tlnp | grep 9000
```

### 4. Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

**Deveria retornar:** `{"status":"ok"}` ou similar

### 5. Testar site principal

```bash
curl https://api.cobrancaauto.com.br/
```

**Deveria retornar:** HTML ou JSON (não 502)

---

## 🔍 SE AINDA DER 502

### Verificar logs do Nginx

```bash
tail -100 /var/log/nginx/cobranca-api-error.log
```

### Verificar logs do app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -100
```

### Verificar configuração do Nginx

```bash
# Verificar se o arquivo nginx-host.conf foi copiado
cat /etc/nginx/sites-enabled/cobranca-api | grep fastcgi_pass

# Deveria mostrar:
# fastcgi_pass 127.0.0.1:9000;
```

Se não estiver configurado, execute:

```bash
# Copiar arquivo do projeto para o servidor
scp nginx-host.conf root@76.13.167.54:/tmp/

# Mover para o lugar certo
mv /tmp/nginx-host.conf /etc/nginx/sites-available/cobranca-api

# Criar link simbólico
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Testar configuração
nginx -t

# Recarregar Nginx
systemctl reload nginx
```

---

## 📝 RESUMO FINAL

### Arquivos criados/atualizados:

1. **[`.env`](.env:1)** - Atualizado com Redis
2. **[`docker-compose.prod.yml`](docker-compose.prod.yml:1)** - Porta 9000 exposta
3. **[`nginx-host.conf`](nginx-host.conf:1)** - Configuração Nginx completa
4. **[`rebuild-completo.sh`](rebuild-completo.sh:1)** - Script de rebuild completo

### Comandos para executar:

```bash
# 1. Dar permissão
chmod +x rebuild-completo.sh

# 2. Executar rebuild
./rebuild-completo.sh

# 3. Verificar porta
netstat -tlnp | grep 9000

# 4. Testar health check
curl https://api.cobrancaauto.com.br/health

# 5. Testar site
curl https://api.cobrancaauto.com.br/
```

---

## 🚀 RESULTADO ESPERADO

Após executar o rebuild:

1. ✅ Porta 9000 exposta: `127.0.0.1:9000`
2. ✅ Health check funcionando: `{"status":"ok"}`
3. ✅ Site carregando: HTML/JSON (não 502)
4. ✅ Redis conectado: `Redis::ping() => true`

Se tudo estiver funcionando, o site está pronto para uso!

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

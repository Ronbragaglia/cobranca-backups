# COMANDOS EXATOS PARA EXECUTAR NA VPS - PASSO A PASSO

## 🚀 EXECUTE CADA COMANDO ABAIXO NA VPS, UM POR VEZ

Copie e cole cada comando exatamente como está escrito.

---

## PASSO 1: Verificar status dos containers

```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml ps
```

**O que você deve ver:**
```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

**Se o mysql estiver em "Restarting":** Continue para o PASSO 2.

---

## PASSO 2: Verificar logs do MySQL

```bash
docker-compose -f docker-compose.prod.yml logs mysql | tail -100
```

**O que você deve ver:**
- Se MySQL iniciou com sucesso
- Se há erros de permissão ou conexão

**Se houver erros:** Continue para o PASSO 3.

---

## PASSO 3: Parar e reiniciar MySQL

```bash
docker-compose -f docker-compose.prod.yml restart mysql
```

**Aguarde 10 segundos** antes de continuar.

---

## PASSO 4: Verificar logs do MySQL novamente

```bash
docker-compose -f docker-compose.prod.yml logs mysql | tail -50
```

**O que você deve ver:**
- MySQL iniciou com sucesso
- "ready for connections" ou similar

**Se MySQL estiver healthy:** Continue para o PASSO 5.

---

## PASSO 5: Verificar logs do Redis

```bash
docker-compose -f docker-compose.prod.yml logs redis | tail -50
```

**O que você deve ver:**
- Redis iniciou com sucesso
- "Ready to accept connections" ou similar

**Se Redis estiver healthy:** Continue para o PASSO 6.

---

## PASSO 6: Parar todos os containers

```bash
docker-compose -f docker-compose.prod.yml down
```

---

## PASSO 7: Subir todos os containers

```bash
docker-compose -f docker-compose.prod.yml up -d
```

**Aguarde 30 segundos** antes de continuar.

---

## PASSO 8: Verificar status dos containers

```bash
docker-compose -f docker-compose.prod.yml ps
```

**O que você deve ver:**
```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

**Se todos estiverem "Up" ou "Up (healthy)":** Continue para o PASSO 9.

**Se algum estiver em "Restarting" ou "unhealthy":** Execute os PASSOS 1-7 novamente.

---

## PASSO 9: Verificar se a porta 9000 está exposta

```bash
netstat -tlnp | grep 9000
```

**O que você deve ver:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

**Se NÃO mostrar isso:** Execute os PASSOS 6-8 novamente.

---

## PASSO 10: Verificar logs do app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -100
```

**O que você deve procurar:**
- "NOTICE: fpm is running, pid 1" - PHP-FPM está rodando
- "Application key set successfully" - APP_KEY está correta
- Erros de conexão com MySQL ou Redis

**Se houver erros:** Anote-os para reportar.

---

## PASSO 11: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

**O que você deve ver:**
- `{"status":"ok"}` ou similar
- Código HTTP 200

**Se der 502 Bad Gateway:** Continue para o PASSO 12.

---

## PASSO 12: Testar site principal

```bash
curl https://api.cobrancaauto.com.br/
```

**O que você deve ver:**
- HTML da página inicial ou JSON da API
- Código HTTP 200

**Se der 502 Bad Gateway:** Continue para o PASSO 13.

---

## PASSO 13: Verificar logs do Nginx (no servidor)

```bash
tail -100 /var/log/nginx/cobranca-api-error.log
```

**O que você deve procurar:**
- Erros de conexão ao PHP-FPM
- "connect() failed" ou "upstream prematurely closed connection"

**Se houver erros:** Anote-os para reportar.

---

## PASSO 14: Verificar logs do Nginx (no container Docker)

```bash
docker-compose -f docker-compose.prod.yml logs nginx-laravel | tail -100
```

**O que você deve procurar:**
- Erros de conexão ao PHP-FPM
- Erros de configuração

**Se houver erros:** Anote-os para reportar.

---

## ✅ RESULTADO ESPERADO

Após executar todos os passos acima:

1. ✅ Todos os containers rodando
2. ✅ MySQL e Redis healthy
3. ✅ Porta 9000 exposta
4. ✅ Health check funcionando
5. ✅ Site carregando sem erros 502

**Se tudo estiver funcionando:** Parabéns! O site está pronto para uso.

**Se ainda der erros:** Reporte os resultados dos PASSOS 10-14 para que eu possa ajudar.

---

## 📋 RESUMO DOS ARQUIVOS CRIADOS

1. [`ROADMAP_TECNICO.md`](ROADMAP_TECNICO.md:1) - Roadmap técnico FASE 0-3
2. [`INSTRUCOES_IMPLEMENTAR_REDIS.md`](INSTRUCOES_IMPLEMENTAR_REDIS.md:1) - Instruções Redis
3. [`docker-compose.prod.yml`](docker-compose.prod.yml:1) - Configuração Docker atualizada
4. [`.env`](.env:1) - Variáveis de ambiente atualizadas
5. [`nginx-host.conf`](nginx-host.conf:1) - Configuração Nginx para servidor
6. [`nginx-laravel.conf`](nginx-laravel.conf:1) - Configuração Nginx para Docker
7. [`COMANDOS_EXATOS_VPS.md`](COMANDOS_EXATOS_VPS.md:1) - Este documento (passo a passo)

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

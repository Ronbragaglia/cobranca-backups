# CRIAR SCRIPT MANUALMENTE NO SERVIDOR

## 🚨 PROBLEMA

O script não foi criado no servidor.

## ✅ SOLUÇÃO: CRIAR SCRIPT MANUALMENTE

Execute estes comandos:

```bash
# 1. Criar o script
cat > /var/www/cobranca-api/resolver-site.sh << 'EOF'
#!/bin/bash

# Script para resolver o problema da porta 9000 e trazer o site de volta

echo "=== PARANDO CONTAINER APP ==="
docker stop cobranca_app

echo "=== REMOVENDO CONTAINER APP ==="
docker rm cobranca_app

echo "=== CRIANDO NOVO CONTAINER COM PORTA EXPOSTA ==="
docker run -d --name cobranca_app --restart unless-stopped --network cobranca-api_cobranca_network -p 127.0.0.1:9000:9000 -v /var/www/cobranca-api/storage:/var/www/storage cobranca-api_app php-fpm

echo "=== AGUARDANDO 10 SEGUNDOS ==="
sleep 10

echo "=== VERIFICANDO SE A PORTA ESTÁ EXPOSTA ==="
docker port cobranca_app

echo "=== TESTANDO CONEXÃO ==="
curl -I http://127.0.0.1:9000

echo "=== TESTANDO HEALTH CHECK ==="
curl https://api.cobrancaauto.com.br/health

echo "=== TESTANDO SITE ==="
curl https://api.cobrancaauto.com.br/

echo "=== CONCLUÍDO ==="
EOF

# 2. Dar permissão de execução
chmod +x /var/www/cobranca-api/resolver-site.sh

# 3. Executar o script
/var/www/cobranca-api/resolver-site.sh
```

---

## 📋 O QUE ESPERAR

### Após executar o script:

```
=== PARANDO CONTAINER APP ===
cobranca_app

=== REMOVENDO CONTAINER APP ===
cobranca_app

=== CRIANDO NOVO CONTAINER COM PORTA EXPOSTA ===
[CONTAINER_ID]

=== AGUARDANDO 10 SEGUNDOS ===

=== VERIFICANDO SE A PORTA ESTÁ EXPOSTA ===
9000/tcp -> 127.0.0.1:9000

=== TESTANDO CONEXÃO ===
HTTP/1.1 404 Not Found

=== TESTANDO HEALTH CHECK ===
{"status":"ok"}

=== TESTANDO SITE ===
<!DOCTYPE html>...

=== CONCLUÍDO ===
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar logs do container
docker logs cobranca_app | tail -50

# Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

---

## 📝 CHECKLIST

- [ ] Script criado manualmente
- [ ] Script executado
- [ ] Container cobranca_app parado
- [ ] Container cobranca_app removido
- [ ] Novo container criado com porta exposta
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

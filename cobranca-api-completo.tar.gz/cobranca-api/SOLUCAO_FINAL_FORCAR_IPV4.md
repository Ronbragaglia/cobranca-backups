# SOLUÇÃO FINAL - FORÇAR PHP-FPM A ESCUTAR EM IPv4

## 🚨 PROBLEMA IDENTIFICADO

O PHP-FPM está escutando em `:::9000` (IPv6), mas o Nginx está tentando conectar em `127.0.0.1:9000` (IPv4). Isso pode estar causando problemas de compatibilidade.

## ✅ SOLUÇÃO

Execute estes comandos:

```bash
# 1. Alterar configuração do PHP-FPM para escutar em IPv4
docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

# 2. Reiniciar PHP-FPM
docker restart cobranca_app

# 3. Aguardar 10 segundos
sleep 10

# 4. Verificar se agora está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Deveria mostrar `0.0.0.0:9000` (IPv4) em vez de `:::9000` (IPv6)**

### PASSO 5: Testar conexão

```bash
curl -I http://127.0.0.1:9000/index.php
```

### PASSO 6: Testar site

```bash
curl -I https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após alterar configuração do PHP-FPM:
```
0.0.0.0:9000
```

### Após `curl -I http://127.0.0.1:9000/index.php`:
```
HTTP/1.1 200 OK
```

### Após `curl -I https://api.cobrancaauto.com.br/`:
```
HTTP/1.1 200 OK
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar logs do PHP-FPM
docker logs cobranca_app | tail -50

# Verificar logs de erro do Nginx
tail -20 /var/log/nginx/cobranca-api-error.log

# Verificar logs de acesso do Nginx
tail -20 /var/log/nginx/cobranca-api-access.log
```

---

## 📝 RESUMO

### O que fazer:

1. Alterar configuração do PHP-FPM para escutar em IPv4
2. Reiniciar PHP-FPM
3. Verificar se agora está escutando em IPv4
4. Testar conexão
5. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Alterar configuração do PHP-FPM para escutar em IPv4
docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

# 2. Reiniciar PHP-FPM
docker restart cobranca_app

# 3. Aguardar 10 segundos
sleep 10

# 4. Verificar se agora está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000

# 5. Testar conexão
curl -I http://127.0.0.1:9000/index.php

# 6. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

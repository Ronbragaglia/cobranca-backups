# EXPORTE MANUAL DA PORTA 9000

## 🚨 PROBLEMA

O `docker-compose.prod.yml` tem a configuração de ports correta, mas o Docker não está expondo a porta para o host.

## ✅ SOLUÇÃO: EXPORTE MANUAL

### PASSO 1: Parar o container app

```bash
docker stop cobranca_app
```

### PASSO 2: Remover o container app

```bash
docker rm cobranca_app
```

### PASSO 3: Criar um novo container com a porta exposta

```bash
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  --network cobranca-api_cobranca_network \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  cobranca-api_app \
  php-fpm
```

### PASSO 4: Aguardar 10 segundos

```bash
sleep 10
```

### PASSO 5: Verificar se a porta está exposta

```bash
docker port cobranca_app
```

**Deveria mostrar:**
```
9000/tcp -> 127.0.0.1:9000
```

### PASSO 6: Testar conexão

```bash
curl -I http://127.0.0.1:9000
```

**Deveria mostrar algo como:**
```
HTTP/1.1 404 Not Found
```

### PASSO 7: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

### PASSO 8: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Parar o container app
2. Remover o container app
3. Criar um novo container com a porta exposta manualmente
4. Testar conexão e site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Parar o container app
docker stop cobranca_app

# 2. Remover o container app
docker rm cobranca_app

# 3. Criar um novo container com a porta exposta
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  --network cobranca-api_cobranca_network \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  cobranca-api_app \
  php-fpm

# 4. Aguardar 10 segundos
sleep 10

# 5. Verificar se a porta está exposta
docker port cobranca_app

# 6. Testar conexão
curl -I http://127.0.0.1:9000

# 7. Testar health check
curl https://api.cobrancaauto.com.br/health

# 8. Testar site
curl https://api.cobrancaauto.com.br/
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, tente:

```bash
# Verificar se a imagem existe
docker images | grep cobranca-api_app

# Se não existir, reconstruir
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml build app

# Tentar novamente
docker stop cobranca_app
docker rm cobranca_app
docker run -d \
  --name cobranca_app \
  --restart unless-stopped \
  --network cobranca-api_cobranca_network \
  -p 127.0.0.1:9000:9000 \
  -v /var/www/cobranca-api/storage:/var/www/storage \
  cobranca-api_app \
  php-fpm
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

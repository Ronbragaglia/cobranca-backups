# 🔧 CORRIGIR CONFIGURAÇÃO NGINX FINAL

## 📋 PROBLEMA IDENTIFICADO

Há **MÚLTIPLAS** linhas de `limit_req_zone` no arquivo NGINX, causando erro:

```bash
nginx: [emerg] limit_req_zone "api" is already bound to key "$binary_remote_addr"
```

## 🔧 SOLUÇÃO DEFINITIVA

### Opção 1: Criar configuração limpa (RECOMENDADO)

```bash
# Passo 1: Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Criar configuração limpa
cat > /etc/nginx/sites-available/cobranca-api << 'NGINXEOF'
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;
    
    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # Logging
    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;
    
    # Main location
    location / {
        try_files $uri $uri/ /index.php?$query_string;
        limit_req zone=api burst=20 nodelay;
    }
    
    # PHP-FPM
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }
    
    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
NGINXEOF

# Passo 3: Testar configuração
nginx -t

# Passo 4: Recarregar NGINX
systemctl reload nginx

# Passo 5: Verificar configuração
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Passo 6: Testar HTTPS
curl -I https://api.cobrancaauto.com.br

# Passo 7: Testar HTTP (deve redirecionar para HTTPS)
curl -I http://api.cobrancaauto.com.br
```

### Opção 2: Editar arquivo manualmente

```bash
# Passo 1: Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Editar arquivo
nano /etc/nginx/sites-available/cobranca-api

# Passo 3: Remover todo o conteúdo e colar a configuração limpa acima

# Passo 4: Salvar e sair (Ctrl+O, Enter, Ctrl+X)

# Passo 5: Testar configuração
nginx -t

# Passo 6: Recarregar NGINX
systemctl reload nginx
```

## ✅ VERIFICAÇÃO

### Verificar configuração NGINX

```bash
# Verificar configuração NGINX
nginx -t

# Verificar limit_req_zone
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Verificar status NGINX
systemctl status nginx

# Testar HTTPS
curl -I https://api.cobrancaauto.com.br

# Testar HTTP (deve redirecionar para HTTPS)
curl -I http://api.cobrancaauto.com.br
```

### Resultado esperado

```bash
# nginx -t
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful

# grep "limit_req" /etc/nginx/sites-available/cobranca-api
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
        limit_req zone=api burst=20 nodelay;

# curl -I https://api.cobrancaauto.com.br
HTTP/1.1 200 OK
Server: nginx/1.18.0 (Ubuntu)
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Cache-Control: no-cache, private
Date: Tue, 03 Feb 2026 17:28:55 GMT

# curl -I http://api.cobrancaauto.com.br
HTTP/1.1 301 Moved Permanently
Server: nginx/1.18.0 (Ubuntu)
Location: https://api.cobrancaauto.com.br/
```

## 📋 COMANDOS PARA CORRIGIR (COPIAR E COLAR)

```bash
# Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Criar configuração limpa
cat > /etc/nginx/sites-available/cobranca-api << 'NGINXEOF'
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;
    
    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # Logging
    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;
    
    # Main location
    location / {
        try_files $uri $uri/ /index.php?$query_string;
        limit_req zone=api burst=20 nodelay;
    }
    
    # PHP-FPM
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }
    
    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
NGINXEOF

# Testar configuração
nginx -t

# Recarregar NGINX
systemctl reload nginx

# Verificar configuração
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Testar HTTPS
curl -I https://api.cobrancaauto.com.br

# Testar HTTP (deve redirecionar para HTTPS)
curl -I http://api.cobrancaauto.com.br
```

## ✅ CHECKLIST FINAL

- [ ] Backup da configuração criado
- [ ] Configuração limpa criada
- [ ] Configuração NGINX testada com sucesso
- [ ] NGINX recarregado
- [ ] Site acessível via HTTPS
- [ ] HTTP redireciona para HTTPS
- [ ] Rate limiting funcionando
- [ ] Security headers configurados

## 🚀 PRÓXIMOS PASSOS

1. **Corrigir configuração NGINX** - Executar comandos acima
2. **Testar rate limiting** - Simular ataque com múltiplas requisições
3. **Monitorar logs** - `tail -f /var/log/nginx/cobranca-api-error.log`
4. **Verificar backups** - Confirmar que backups estão sendo criados
5. **Testar site completo** - Acessar https://api.cobrancaauto.com.br

## 💚 SUCESSO FINAL

**✅ NGINX configurado corretamente**
**✅ HTTPS funcionando**
**✅ HTTP redireciona para HTTPS**
**✅ Rate limiting configurado**
**✅ Security headers configurados**
**✅ Site seguro e otimizado**

**NGINX configurado corretamente = Site seguro = 💸**

# 🔥 FIX ACESSO EXTERNO - SITE FUNCIONA LOCALMENTE MAS NÃO EXTERNAMENTE

## 📋 SITUAÇÃO

- ✅ Site funciona localmente (`curl localhost` = HTTP 200 OK)
- ❌ Site não funciona externamente (bad gateway)
- 🎯 **Causa provável:** Firewall bloqueando porta 80 ou Cloudflare interferindo

---

## ⚡ SOLUÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos na VPS:

```bash
# Passo 1: Verificar se Cloudflare está OFF
# Acesse: https://dash.cloudflare.com/
# Vá em: DNS > api.cobrancaauto.com.br
# Verifique: Proxy Status = DNS only (NÃO pode estar "Proxied")

# Passo 2: Abrir porta 80 no firewall
ufw allow 80/tcp
ufw allow 443/tcp
ufw status verbose

# Passo 3: Reiniciar NGINX
systemctl restart nginx
systemctl status nginx

# Passo 4: Testar externamente
curl -I http://api.cobrancaauto.com.br/
```

---

## 🔧 DIAGNÓSTICO COMPLETO

### Passo 1: Verificar Firewall

```bash
# Verificar status UFW
ufw status verbose

# Se estiver inativo ou bloqueando, habilitar
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### Passo 2: Verificar NGINX

```bash
# Verificar se NGINX está escutando
netstat -tlnp | grep nginx
# OU
ss -tlnp | grep nginx

# Deve mostrar: 0.0.0.0:80 (não 127.0.0.1:80)
```

### Passo 3: Verificar Configuração NGINX

```bash
# Verificar se está escutando em todas as interfaces
grep -E "listen" /etc/nginx/sites-available/cobranca-api

# Deve mostrar:
# listen 80;
# listen [::]:80;
```

### Passo 4: Verificar DNS

```bash
# Verificar para onde o DNS aponta
dig api.cobrancaauto.com.br +short

# Deve retornar o IP da VPS: 76.13.167.54
```

### Passo 5: Testar IP Direto

```bash
# Pegar IP público
curl -s ifconfig.me

# Testar acesso direto pelo IP
curl -I http://76.13.167.54/
```

---

## 🎯 Causas Mais Comuns

### 1. Cloudflare Proxy ON (Causa mais provável!)

**Problema:** Cloudflare está interceptando requisições

**Solução:**
1. Acesse: https://dash.cloudflare.com/
2. Vá em: DNS > api.cobrancaauto.com.br
3. Clique na nuvem laranja (Proxy)
4. Mude para "DNS only" (nuvem cinza)
5. Aguarde alguns minutos
6. Teste novamente

### 2. Firewall Bloqueando Porta 80

**Problema:** Firewall da VPS ou do provedor está bloqueando

**Solução:**
```bash
# Firewall da VPS (UFW)
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable

# Se usar iptables
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
```

### 3. NGINX Escutando Apenas em Localhost

**Problema:** NGINX configurado para escutar apenas em 127.0.0.1

**Solução:**
```bash
# Verificar configuração
cat /etc/nginx/sites-available/cobranca-api | grep listen

# Se mostrar "listen 127.0.0.1:80", mudar para "listen 80;"

# Editar
nano /etc/nginx/sites-available/cobranca-api

# Mudar de:
# listen 127.0.0.1:80;
# Para:
# listen 80;

# Reiniciar
nginx -t
systemctl restart nginx
```

### 4. Firewall do Provedor (Hostinger)

**Problema:** Firewall externo do provedor de hospedagem

**Solução:**
1. Acesse o painel da Hostinger
2. Vá em: Network > Firewall
3. Adicione regra para permitir porta 80 (HTTP)
4. Adicione regra para permitir porta 443 (HTTPS)
5. Salve e aguarde

---

## 📊 COMANDOS DE DIAGNÓSTICO

Execute estes comandos para identificar o problema:

```bash
# 1. Verificar se site funciona localmente
curl -I http://localhost/

# 2. Verificar se NGINX está rodando
systemctl status nginx

# 3. Verificar se NGINX está escutando
netstat -tlnp | grep nginx

# 4. Verificar firewall
ufw status verbose

# 5. Verificar DNS
dig api.cobrancaauto.com.br +short

# 6. Testar IP direto
curl -I http://76.13.167.54/

# 7. Testar externamente
curl -I http://api.cobrancaauto.com.br/

# 8. Verificar logs
tail -20 /var/log/nginx/error.log
tail -20 /var/log/nginx/access.log
```

---

## 🚨 EMERGÊNCIA

Se nada funcionar:

```bash
# Reiniciar tudo
systemctl restart nginx
systemctl restart php8.2-fpm
systemctl restart mysql

# Desabilitar firewall temporariamente
ufw disable

# Reiniciar servidor (último recurso)
reboot
```

---

## ✅ VERIFICAÇÃO FINAL

Após aplicar a solução:

```bash
# Testar externamente
curl -I http://api.cobrancaauto.com.br/

# Deve retornar: HTTP/1.1 200 OK

# Testar no navegador
http://api.cobrancaauto.com.br
```

---

## 💚 SUCESSO!

Quando funcionar, você verá:
- Site carregando no navegador
- Resposta HTTP 200 OK
- Sem erros 502 Bad Gateway

**Site funcionando = Cliente feliz = 💸**

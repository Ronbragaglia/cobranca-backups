# 🔧 SOLUÇÃO COMPLETA PARA TRAZER O SITE DE VOLTA

## 📋 Diagnóstico

O PHP-FPM está escutando em IPv6 (`:::9000`) mas o Nginx está tentando conectar em IPv4 (`127.0.0.1:9000`). Isso causa "Connection refused".

## 🚀 Execute estes comandos na VPS (em ordem)

### Passo 1: Verificar estado atual dos containers
```bash
cd /var/www/cobranca-api
docker ps -a
```

### Passo 2: Verificar se o PHP-FPM está rodando
```bash
docker exec cobranca_app ps aux | grep php-fpm
```

### Passo 3: Verificar em qual porta o PHP-FPM está escutando
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

### Passo 4: Modificar PHP-FPM para escutar em IPv4
```bash
# Fazer backup do arquivo atual
docker exec cobranca_app cp /usr/local/etc/php-fpm.d/www.conf /usr/local/etc/php-fpm.d/www.conf.backup

# Criar novo arquivo de configuração com IPv4
docker exec cobranca_app sh -c 'cat > /usr/local/etc/php-fpm.d/www.conf << '\''EOF'\''
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000
listen.owner = www-data
listen.group = www-data
listen.mode = 0660

pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3

php_admin_value[error_log] = /var/log/php-fpm.log
php_admin_flag[log_errors] = on
EOF'
```

### Passo 5: Reiniciar o container do app
```bash
docker restart cobranca_app
```

### Passo 6: Aguardar 15 segundos
```bash
sleep 15
```

### Passo 7: Verificar se o PHP-FPM agora está escutando em IPv4
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm
```

### Passo 8: Testar conexão com PHP-FPM
```bash
curl -I http://127.0.0.1:9000
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

### Passo 9: Verificar logs do Nginx
```bash
tail -20 /var/log/nginx/cobranca-api-error.log
```

### Passo 10: Testar o site
```bash
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se ainda não funcionar

### Opção A: Verificar logs do container app
```bash
docker logs cobranca_app --tail 50
```

### Opção B: Verificar se o PHP-FPM está rodando
```bash
docker exec cobranca_app ps aux | grep php-fpm
```

### Opção C: Verificar logs do PHP-FPM
```bash
docker exec cobranca_app tail -20 /var/log/php-fpm.log
```

### Opção D: Recarregar Nginx
```bash
nginx -t
nginx -s reload
```

## 📋 Solução alternativa: Usar IPv6 no Nginx

Se a solução acima não funcionar, podemos fazer o Nginx conectar em IPv6:

```bash
# Editar configuração do Nginx
nano /etc/nginx/sites-available/cobranca-api

# Alterar esta linha:
# fastcgi_pass 127.0.0.1:9000;

# Para:
# fastcgi_pass [::1]:9000;

# Salvar e recarregar Nginx
nginx -t
nginx -s reload
```

## 📋 Solução alternativa 2: Expor porta 9000 no Docker

```bash
# Verificar configuração atual
grep -A 5 "ports:" docker-compose.prod.yml | grep 9000

# Se não estiver exposta, adicionar:
# ports:
#   - "127.0.0.1:9000:9000"

# Recriar containers
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d
```

## 📋 Verificação final

```bash
# Verificar todos os containers
docker ps

# Verificar logs do Nginx
tail -50 /var/log/nginx/cobranca-api-error.log

# Verificar logs do app
docker logs cobranca_app --tail 50

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 🎯 Resumo

O problema é que o PHP-FPM está escutando em IPv6 (`:::9000`) mas o Nginx está tentando conectar em IPv4 (`127.0.0.1:9000`). A solução é fazer o PHP-FPM escutar em IPv4.

Execute os comandos acima em ordem e verifique os resultados esperados após cada passo.

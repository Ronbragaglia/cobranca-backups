# 🔧 SOLUÇÃO - 502 BAD GATEWAY

## 📋 Problema Identificado

O site está respondendo com "502 Bad Gateway", o que significa que:
- ✅ Nginx está conectando
- ❌ Nginx não consegue se conectar ao PHP-FPM

O problema é que a configuração do Nginx está tentando conectar em `127.0.0.1:9000`, mas o PHP-FPM está em outro container.

## 🚀 Solução: Modificar configuração do Nginx para conectar no container

### Passo 1: Criar nova configuração do Nginx
```bash
cat > /var/www/cobranca-api/nginx-ssl.conf << '\''EOF'\''
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    root /var/www/public;
    index index.php index.html;

    access_log /var/log/nginx/cobranca-api.access.log;
    error_log /var/log/nginx/cobranca-api.error.log;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass cobranca_app:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
    }

    location ~ /\. {
        deny all;
    }
}
EOF'
```

### Passo 2: Parar e remover o container `cobranca_nginx` atual
```bash
docker stop cobranca_nginx
docker rm cobranca_nginx
```

### Passo 3: Criar novo container `cobranca_nginx` com a nova configuração
```bash
docker run -d \
  --name cobranca_nginx \
  --restart unless-stopped \
  -p 80:80 \
  -p 443:443 \
  -v /var/www/cobranca-api:/var/www \
  -v /var/www/cobranca-api/nginx-ssl.conf:/etc/nginx/conf.d/default.conf \
  -v /etc/letsencrypt:/etc/letsencrypt:ro \
  --network cobranca-api_cobranca_network \
  nginx:alpine
```

### Passo 4: Verificar se o container está rodando
```bash
docker ps | grep nginx
```

**Resultado esperado:**
```
...            nginx:alpine       "/docker-entrypoint.…"   ...              Up ...             0.0.0.0:80->80/tcp, 0.0.0.0:443->443/tcp   cobranca_nginx
```

### Passo 5: Verificar logs do Nginx
```bash
docker logs cobranca_nginx --tail 50
```

### Passo 6: Testar o site
```bash
curl -I http://localhost
curl -I http://localhost/index.php
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 🎯 Resumo

1. Criar nova configuração do Nginx com `fastcgi_pass cobranca_app:9000`
2. Parar e remover o container `cobranca_nginx` atual
3. Criar novo container `cobranca_nginx` com a nova configuração
4. Verificar logs e testar o site

Execute os comandos acima na VPS e me envie os resultados!

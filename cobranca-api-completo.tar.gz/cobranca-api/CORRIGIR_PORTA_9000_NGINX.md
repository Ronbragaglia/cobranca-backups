# CORRIGIR PORTA 9000 E ERRO DO NGINX

## 🚨 PROBLEMAS IDENTIFICADOS

### Problema 1: Porta 9000 não exposta
O PHP-FPM está rodando no container (`tcp 0 0 :::9000 :::* LISTEN 1/php-fpm.conf)` mas a porta não está exposta para o host (`docker port cobranca_app` não mostra nada).

### Problema 2: Erro de sintaxe no Nginx
```
nginx: [emerg] unexpected end of file, expecting ";" or "}" in /etc/nginx/sites-enabled/cobranca-api:91
```

---

## ✅ SOLUÇÃO

### PARTE 1: CORRIGIR CONFIGURAÇÃO DO NGINX

#### PASSO 1: Verificar o arquivo atual

```bash
cat /etc/nginx/sites-available/cobranca-api
```

#### PASSO 2: Editar o arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

#### PASSO 3: Apagar todo o conteúdo

Pressione `Ctrl+K` repetidamente até apagar tudo, ou use:
- Pressione `Alt+Shift+6` para marcar tudo
- Pressione `Ctrl+K` para apagar

#### PASSO 4: Colar este conteúdo EXATO

```nginx
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 20M;

    root /var/www/cobranca-api/public;
    index index.php index.html;

    location /health {
        access_log off;
        try_files $uri /index.php?$query_string;
    }

    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_connect_timeout 60;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 256 16k;
        fastcgi_busy_buffers_size 256k;
    }

    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
        gzip_static on;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
```

#### PASSO 5: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

#### PASSO 6: Testar configuração

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

#### PASSO 7: Recarregar Nginx

```bash
systemctl reload nginx
```

---

### PARTE 2: CORRIGIR PORTA 9000

#### PASSO 8: Parar containers

```bash
docker-compose -f docker-compose.prod.yml down
```

#### PASSO 9: Verificar docker-compose.prod.yml

```bash
grep -A 5 "ports:" /var/www/cobranca-api/docker-compose.prod.yml | head -20
```

**Deveria mostrar:**
```
ports:
  - "127.0.0.1:9000:9000"
```

#### PASSO 10: Subir containers novamente

```bash
docker-compose -f docker-compose.prod.yml up -d
```

#### PASSO 11: Aguardar 30 segundos

```bash
sleep 30
```

#### PASSO 12: Verificar se a porta está exposta

```bash
docker port cobranca_app
```

**Deveria mostrar:**
```
9000/tcp -> 127.0.0.1:9000
```

#### PASSO 13: Testar conexão

```bash
curl -I http://127.0.0.1:9000
```

**Deveria mostrar algo como:**
```
HTTP/1.1 404 Not Found
```

---

### PARTE 3: TESTAR SITE

#### PASSO 14: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

#### PASSO 15: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### Problemas:

1. ❌ Porta 9000 não exposta
2. ❌ Erro de sintaxe no Nginx

### Soluções:

1. ✅ Corrigir configuração do Nginx (arquivo completo)
2. ✅ Reiniciar containers para expor porta 9000

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# PARTE 1: Corrigir Nginx
nano /etc/nginx/sites-available/cobranca-api
# Apagar tudo (Ctrl+K repetidamente)
# Colar o conteúdo EXATO acima
# Salvar: Ctrl+O, Enter, Ctrl+X

nginx -t
systemctl reload nginx

# PARTE 2: Corrigir porta 9000
docker-compose -f docker-compose.prod.yml down
grep -A 5 "ports:" /var/www/cobranca-api/docker-compose.prod.yml | head -20
docker-compose -f docker-compose.prod.yml up -d
sleep 30
docker port cobranca_app
curl -I http://127.0.0.1:9000

# PARTE 3: Testar site
curl https://api.cobrancaauto.com.br/health
curl https://api.cobrancaauto.com.br/
```

---

## 🔍 SE A PORTA 9000 AINDA NÃO ESTIVER EXPOSTA

Se `docker port cobranca_app` ainda não mostrar nada, execute:

```bash
# Verificar se o container está rodando
docker ps | grep cobranca_app

# Verificar logs do container
docker logs cobranca_app

# Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

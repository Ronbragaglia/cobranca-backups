# CORRIGIR ERRO 502 BAD GATEWAY

## 🚨 PROBLEMA

O erro 502 Bad Gateway indica que o Nginx (no servidor host) não consegue conectar ao PHP-FPM (no container Docker).

**Causa provável:** A configuração do Nginx está tentando conectar ao host/porta errados.

---

## ✅ SOLUÇÃO

### 1. Verificar se os containers estão rodando

```bash
# Verificar status dos containers
docker-compose -f docker-compose.prod.yml ps

# Deveria mostrar:
# cobranca_app   - Up (healthy)
# cobranca_redis   - Up (healthy)
# cobranca_mysql   - Up (healthy)
# cobranca_queue   - Up
# cobranca_scheduler - Up
```

### 2. Verificar logs do container app

```bash
# Verificar se PHP-FPM está rodando
docker-compose -f docker-compose.prod.yml logs app

# Deveria mostrar algo como:
# [04-Feb-2026 15:00:00] NOTICE: fpm is running, pid 1
```

### 3. Verificar a porta do PHP-FPM

```bash
# Verificar qual porta o PHP-FPM está escutando
docker-compose -f docker-compose.prod.yml exec app netstat -tlnp

# Deveria mostrar:
# tcp        0      0.0.0.0:9000            1/php-fpm
```

### 4. Testar conexão do Nginx para o PHP-FPM

```bash
# Testar se o Nginx consegue conectar ao PHP-FPM
curl -v http://127.0.0.1:9000/health

# Se der "Connection refused", o PHP-FPM não está acessível
```

### 5. Atualizar configuração do Nginx

Copie o arquivo [`nginx-host.conf`](nginx-host.conf:1) para o servidor:

```bash
# Copiar arquivo de configuração
scp nginx-host.conf root@76.13.167.54:/tmp/

# No servidor, mover para o lugar certo
ssh root@76.13.167.54
mv /tmp/nginx-host.conf /etc/nginx/sites-available/cobranca-api

# Criar link simbólico
ln -s /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Testar configuração
nginx -t

# Recarregar Nginx
systemctl reload nginx
```

### 6. Verificar se o PHP-FPM está exposto corretamente

O container `cobranca_app` precisa expor a porta 9000 para o host.

Verifique o [`docker-compose.prod.yml`](docker-compose.prod.yml:38):

```yaml
app:
  build: .
  container_name: cobranca_app
  restart: unless-stopped
  ports:
    - "127.0.0.1:9000:9000"  # ✅ IMPORTANTE: expor porta 9000
  environment:
    # ...
```

**Se a seção `ports` não existir, adicione:**

```bash
# Editar docker-compose.prod.yml
nano docker-compose.prod.yml

# Adicionar ports ao serviço app (após linha 41)
  ports:
    - "127.0.0.1:9000:9000"

# Salvar e sair (Ctrl+O, Enter, Ctrl+X)
```

### 7. Rebuild e subir containers

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Subir containers
docker-compose -f docker-compose.prod.yml up -d

# Verificar logs
docker-compose -f docker-compose.prod.yml logs -f app
```

### 8. Testar se o site está funcionando

```bash
# Testar health check
curl https://api.cobrancaauto.com.br/health

# Deveria retornar:
# {"status":"ok"} ou similar

# Testar site principal
curl https://api.cobrancaauto.com.br/

# Deveria retornar HTML ou JSON
```

---

## 🔍 DIAGNÓSTICO

### Verificar logs do Nginx

```bash
# Verificar erros do Nginx
tail -f /var/log/nginx/cobranca-api-error.log

# Procurar por erros de conexão
grep "connect() failed" /var/log/nginx/cobranca-api-error.log
grep "upstream" /var/log/nginx/cobranca-api-error.log
```

### Verificar logs do PHP-FPM

```bash
# Verificar logs do container app
docker-compose -f docker-compose.prod.yml logs app | tail -100

# Procurar por erros
docker-compose -f docker-compose.prod.yml logs app | grep -i error
```

### Verificar se a porta 9000 está aberta

```bash
# Verificar se a porta 9000 está escutando
netstat -tlnp | grep 9000

# Deveria mostrar:
# tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

---

## ⚠️ PROBLEMAS COMUNS

### Erro: "Connection refused" ao conectar ao PHP-FPM

**Causa:** O container app não está expondo a porta 9000.

**Solução:**
1. Adicionar `ports: - "127.0.0.1:9000:9000"` ao serviço app no docker-compose.prod.yml
2. Rebuild e subir containers

### Erro: "Permission denied" ao acessar arquivos

**Causa:** Permissões incorretas dos arquivos.

**Solução:**
```bash
# Corrigir permissões
docker-compose -f docker-compose.prod.yml exec app chown -R www-data:www-data /var/www/storage
docker-compose -f docker-compose.prod.yml exec app chown -R www-data:www-data /var/www/bootstrap/cache
```

### Erro: "No input file specified"

**Causa:** O Nginx não consegue encontrar o arquivo PHP.

**Solução:**
1. Verificar se o `root` no Nginx está correto: `/var/www/cobranca-api/public`
2. Verificar se o arquivo existe: `ls -la /var/www/cobranca-api/public/index.php`

---

## 📝 ARQUIVO DE CONFIGURAÇÃO DO NGINX

O arquivo [`nginx-host.conf`](nginx-host.conf:1) foi criado com:

- ✅ Redirecionamento HTTP → HTTPS
- ✅ Suporte a HTTP/2
- ✅ Headers de segurança
- ✅ Conexão correta ao PHP-FPM (127.0.0.1:9000)
- ✅ Health check endpoint
- ✅ Cache de arquivos estáticos
- ✅ Timeout apropriado (300s)
- ✅ Buffers otimizados

---

## 🚀 COMANDOS RÁPIDOS

```bash
# 1. Verificar status dos containers
docker-compose -f docker-compose.prod.yml ps

# 2. Verificar logs do app
docker-compose -f docker-compose.prod.yml logs app

# 3. Testar conexão ao PHP-FPM
curl -v http://127.0.0.1:9000/health

# 4. Verificar logs do Nginx
tail -f /var/log/nginx/cobranca-api-error.log

# 5. Testar site
curl https://api.cobrancaauto.com.br/health
curl https://api.cobrancaauto.com.br/
```

---

## 📚 REFERÊNCIAS

- [Nginx PHP-FPM Configuration](https://www.nginx.com/resources/wiki/start)
- [Docker Networking](https://docs.docker.com/network/)
- [Laravel Nginx Configuration](https://laravel.com/docs/deployment#nginx)

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔥 REDEFINIR SENHA DO ADMIN - BANCO DE DADOS

## 📋 PROBLEMA

As credenciais `admin@cobranca.com` / `123456` não estão funcionando.

**Causa possível:** O seeder não foi executado ou o usuário não existe no banco de dados.

---

## ⚡ SOLUÇÃO RÁPIDA (2 MINUTOS)

Execute estes comandos na VPS:

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Verificar se o usuário existe no banco de dados
php artisan tinker --execute="echo App\Models\User::where('email', 'admin@cobranca.com')->first();"

# Passo 3: Se não existir ou senha incorreta, recriar o usuário
php artisan tinker --execute="
\$user = App\Models\User::where('email', 'admin@cobranca.com')->first();
if (!\$user) {
    \$tenant = App\Models\Tenant::firstOrCreate(['subdomain' => 'principal'], ['name' => 'Principal', 'subscription_status' => 'active']);
    \$user = App\Models\User::create([
        'name' => 'Admin',
        'email' => 'admin@cobranca.com',
        'password' => bcrypt('123456'),
        'email_verified_at' => now(),
        'tenant_id' => \$tenant->id,
    ]);
    echo 'Usuário criado com sucesso!';
} else {
    \$user->password = bcrypt('123456');
    \$user->save();
    echo 'Senha redefinida com sucesso!';
}
echo 'Usuário: ' . \$user->email . ' | ID: ' . \$user->id;
"

# Passo 4: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 5: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 6: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🔧 SOLUÇÃO ALTERNATIVA - EXECUTAR SEEDER

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Limpar banco de dados (ATENÇÃO: vai apagar todos os dados!)
php artisan migrate:fresh --seed

# Passo 3: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 4: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 5: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🎯 SOLUÇÃO COMPLETA - VERIFICAR E CORRIGIR

### Passo 1: Verificar usuários no banco

```bash
cd /var/www/cobranca-api

# Verificar todos os usuários
php artisan tinker --execute="
\$users = App\Models\User::all();
foreach (\$users as \$user) {
    echo 'ID: ' . \$user->id . ' | Email: ' . \$user->email . ' | Name: ' . \$user->name . ' | Tenant ID: ' . \$user->tenant_id;
}
"
```

### Passo 2: Se o usuário admin não existir, criar

```bash
# Criar usuário admin
php artisan tinker --execute="
\$tenant = App\Models\Tenant::firstOrCreate(['subdomain' => 'principal'], ['name' => 'Principal', 'subscription_status' => 'active']);
\$user = App\Models\User::create([
    'name' => 'Admin',
    'email' => 'admin@cobranca.com',
    'password' => bcrypt('123456'),
    'email_verified_at' => now(),
    'tenant_id' => \$tenant->id,
]);
echo 'Usuário criado: ' . \$user->email . ' | Senha: 123456';
"
```

### Passo 3: Se o usuário existir mas senha estiver errada, redefinir

```bash
# Redefinir senha
php artisan tinker --execute="
\$user = App\Models\User::where('email', 'admin@cobranca.com')->first();
if (\$user) {
    \$user->password = bcrypt('123456');
    \$user->save();
    echo 'Senha redefinida para: admin@cobranca.com';
} else {
    echo 'Usuário não encontrado!';
}
"
```

### Passo 4: Limpar cache e sessões

```bash
cd /var/www/cobranca-api

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Limpar sessões
rm -rf storage/framework/sessions/*

# Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🚨 SOLUÇÃO RADICAL - REDEFINIR TUDO

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Fazer backup do banco (opcional)
mysqldump -u cobranca -p'COBRANCA_DB_PASSWORD' cobranca > backup_$(date +%Y%m%d_%H%M%S).sql

# Passo 3: Limpar banco e rodar seeder
php artisan migrate:fresh --seed

# Passo 4: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 5: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 6: Reiniciar PHP-FPM
systemctl restart php8.2-fpm

# Passo 7: Verificar usuários criados
php artisan tinker --execute="
\$users = App\Models\User::all();
foreach (\$users as \$user) {
    echo 'ID: ' . \$user->id . ' | Email: ' . \$user->email . ' | Name: ' . \$user->name;
}
"
```

---

## 📊 VERIFICAR CREDENCIAIS APÓS CRIAR

```bash
# Verificar se o usuário foi criado
php artisan tinker --execute="
\$user = App\Models\User::where('email', 'admin@cobranca.com')->first();
if (\$user) {
    echo 'Usuário encontrado!';
    echo 'Email: ' . \$user->email;
    echo 'Nome: ' . \$user->name;
    echo 'Tenant ID: ' . \$user->tenant_id;
    echo 'Email verificado: ' . \$user->email_verified_at;
} else {
    echo 'Usuário NÃO encontrado!';
}
"

# Testar login via tinker
php artisan tinker --execute="
\$user = App\Models\User::where('email', 'admin@cobranca.com')->first();
if (\$user) {
    if (Hash::check('123456', \$user->password)) {
        echo 'Senha CORRETA!';
    } else {
        echo 'Senha INCORRETA!';
    }
} else {
    echo 'Usuário NÃO encontrado!';
}
"
```

---

## ✅ APÓS CRIAR O USUÁRIO

### Passo 1: Limpar cache do navegador

- Chrome/Edge: Ctrl + Shift + Delete
- Firefox: Ctrl + Shift + Delete

### Passo 2: Fazer login

- **URL:** http://api.cobrancaauto.com.br/login
- **Email:** admin@cobranca.com
- **Senha:** 123456

### Passo 3: Se ainda não funcionar

1. **Tente em modo anônimo:**
   - Chrome: Ctrl + Shift + N
   - Firefox: Ctrl + Shift + P

2. **Verifique os logs:**
   ```bash
   tail -50 /var/www/cobranca-api/storage/logs/laravel.log
   ```

3. **Verifique o banco de dados:**
   ```bash
   mysql -u cobranca -p -e "USE cobranca; SELECT * FROM users WHERE email='admin@cobranca.com';"
   ```

---

## 💚 SUCESSO!

Após executar os comandos acima, você conseguirá fazer login com:

- **Email:** admin@cobranca.com
- **Senha:** 123456

**Execute os comandos acima na VPS para redefinir a senha do admin!**

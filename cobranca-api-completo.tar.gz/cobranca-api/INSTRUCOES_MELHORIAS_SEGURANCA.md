# 🔧 MELHORIAS DE SEGURANÇA - INSTRUÇÕES

## 📋 MELHORIAS IMPLEMENTADAS

1. **🔥 HTTPS SSL** - Certificado SSL gratuito com Certbot
2. **⚠️ Clean NGINX** - Remoção de configurações duplicadas
3. **📊 Backup DB diário** - Backup automático do banco de dados
4. **🛡️ Rate limiting** - Proteção contra ataques DDoS

## 🚀 COMO EXECUTAR

### Opção 1: Executar remotamente (RECOMENDADO)

```bash
# Passo 1: Dar permissão ao script
chmod +x scripts/executar-melhorias-seguranca-remoto.sh

# Passo 2: Executar script
./scripts/executar-melhorias-seguranca-remoto.sh
```

### Opção 2: Executar manualmente na VPS

```bash
# Passo 1: Conectar à VPS
ssh root@76.13.167.54

# Passo 2: Baixar script
cd /tmp
wget https://github.com/seu-repo/cobranca-api/raw/main/scripts/melhorias-seguranca-seguras.sh
chmod +x melhorias-seguranca-seguras.sh

# Passo 3: Executar script
./melhorias-seguranca-seguras.sh
```

### Opção 3: Executar comandos manualmente

#### 1. HTTPS SSL com Certbot

```bash
# Instalar Certbot
apt update
apt install certbot python3-certbot-nginx -y

# Configurar SSL
certbot --nginx -d api.cobrancaauto.com.br --non-interactive --agree-tos --email admin@cobrancaauto.com.br

# Recarregar NGINX
systemctl reload nginx
```

#### 2. Limpar NGINX (remover duplicado)

```bash
# Remover site default
rm /etc/nginx/sites-enabled/default

# Testar configuração
nginx -t

# Recarregar NGINX
systemctl reload nginx
```

#### 3. Backup diário do banco de dados

```bash
# Criar diretório de backup
mkdir -p /backup

# Adicionar crontab
crontab -e
# Adicionar linha:
# 0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql
```

#### 4. Rate limiting no NGINX

```bash
# Adicionar rate limit zone
echo "limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;" > /tmp/rate-limit.conf

# Adicionar ao NGINX
cat /tmp/rate-limit.conf | tee -a /etc/nginx/sites-available/cobranca-api

# Adicionar rate limit na location /
sed -i '/location \//,/}/ s/}/\n            limit_req zone=api burst=20 nodelay;\n        }/' /etc/nginx/sites-available/cobranca-api

# Testar configuração
nginx -t

# Recarregar NGINX
systemctl reload nginx
```

## ✅ VERIFICAÇÕES

### Verificar HTTPS

```bash
# Testar HTTPS
curl -I https://api.cobrancaauto.com.br

# Verificar certificado SSL
openssl s_client -connect api.cobrancaauto.com.br:443 -servername api.cobrancaauto.com.br
```

### Verificar NGINX

```bash
# Verificar status NGINX
systemctl status nginx

# Verificar logs NGINX
tail -f /var/log/nginx/error.log

# Verificar configuração NGINX
nginx -t
```

### Verificar PHP-FPM

```bash
# Verificar status PHP-FPM
systemctl status php8.2-fpm

# Verificar logs PHP-FPM
tail -f /var/log/php8.2-fpm.log
```

### Verificar backups

```bash
# Verificar backups
ls -lh /backup/

# Verificar último backup
tail -100 /backup/cobranca-$(date +%Y%m%d).sql
```

### Verificar crontab

```bash
# Verificar crontab
crontab -l

# Verificar logs do cron
tail -f /var/log/cron.log
```

### Verificar rate limit

```bash
# Verificar configuração NGINX
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Testar rate limit (simular ataque)
for i in {1..30}; do curl https://api.cobrancaauto.com.br; done
```

## 📊 MONITORAMENTO

### Monitorar NGINX

```bash
# Monitorar logs NGINX em tempo real
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# Verificar estatísticas NGINX
nginx -s reload
```

### Monitorar PHP-FPM

```bash
# Monitorar logs PHP-FPM em tempo real
tail -f /var/log/php8.2-fpm.log

# Verificar status PHP-FPM
systemctl status php8.2-fpm
```

### Monitorar banco de dados

```bash
# Monitorar MySQL
systemctl status mysql

# Verificar conexões MySQL
mysql -u root -e "SHOW PROCESSLIST;"

# Verificar tamanho do banco de dados
mysql -u root -e "SELECT table_schema AS 'Database', ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)' FROM information_schema.tables GROUP BY table_schema;"
```

### Monitorar sistema

```bash
# Verificar uso de CPU
top

# Verificar uso de memória
free -h

# Verificar uso de disco
df -h

# Verificar uso de rede
iftop
```

## 🔧 SOLUÇÃO DE PROBLEMAS

### Problema: HTTPS não funciona

```bash
# Verificar certificado SSL
certbot certificates

# Renovar certificado SSL
certbot renew

# Verificar logs do Certbot
tail -f /var/log/letsencrypt/letsencrypt.log
```

### Problema: NGINX não funciona

```bash
# Verificar logs NGINX
tail -f /var/log/nginx/error.log

# Testar configuração NGINX
nginx -t

# Reiniciar NGINX
systemctl restart nginx
```

### Problema: Backup não funciona

```bash
# Verificar logs do cron
tail -f /var/log/cron.log

# Verificar crontab
crontab -l

# Testar backup manual
mysqldump -u root cobranca > /backup/test.sql
```

### Problema: Rate limit não funciona

```bash
# Verificar configuração NGINX
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Testar configuração NGINX
nginx -t

# Recarregar NGINX
systemctl reload nginx
```

## 📋 CHECKLIST FINAL

- [ ] HTTPS configurado e funcionando
- [ ] NGINX configurado e rodando
- [ ] PHP-FPM configurado e rodando
- [ ] Backup diário configurado
- [ ] Rate limiting configurado
- [ ] Logs sendo monitorados
- [ ] Site acessível via HTTPS
- [ ] Site acessível via HTTP (redireciona para HTTPS)
- [ ] Site responsivo no celular
- [ ] Sistema de cobrança funcionando

## 🚀 PRÓXIMOS PASSOS

1. **Implementar mudança de senha obrigatória**
2. **Configurar CDN para assets**
3. **Implementar cache distribuído (Redis)**
4. **Configurar WAF (Web Application Firewall)**
5. **Implementar monitoramento 24/7**
6. **Otimizar banco de dados**
7. **Implementar testes automatizados**
8. **Documentar sistema para desenvolvedores**

## 💚 SUCESSO FINAL

**✅ Site funcionando:** https://api.cobrancaauto.com.br (HTTPS 200 OK)
**✅ HTTPS configurado**
**✅ NGINX limpo e configurado**
**✅ Backup diário configurado**
**✅ Rate limiting configurado**
**✅ Sistema seguro e otimizado**

**Site seguro e otimizado = Cliente feliz = 💸**

# VERIFICAR E ATUALIZAR CONFIGURAÇÃO DO NGINX

## 🚨 PROBLEMA IDENTIFICADO

Os logs do Nginx mostram que está tentando conectar em `http://127.0.0.1:8081/`, mas deveria ser `127.0.0.1:9000`.

```
connect() failed (111: Unknown error) while connecting to upstream, 
upstream: "http://127.0.0.1:8081/"
```

## ✅ SOLUÇÃO

### PASSO 1: Verificar configuração atual do Nginx

```bash
cat /etc/nginx/sites-available/cobranca-api
```

### PASSO 2: Procurar por `8081` na configuração

```bash
grep -n "8081" /etc/nginx/sites-available/cobranca-api
```

Se encontrar `8081`, precisa ser alterado para `9000`.

### PASSO 3: Se precisar alterar, editar o arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

### PASSO 4: Encontrar a linha com `8081`

Procure por algo como:
```
proxy_pass http://127.0.0.1:8081;
```

ou

```
fastcgi_pass 127.0.0.1:8081;
```

### PASSO 5: Alterar para `9000`

Deixe assim:
```
fastcgi_pass 127.0.0.1:9000;
```

### PASSO 6: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

### PASSO 7: Testar configuração do Nginx

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### PASSO 8: Recarregar Nginx

```bash
systemctl reload nginx
```

### PASSO 9: Verificar se o Nginx está rodando

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

---

## 📝 RESUMO

### Problema identificado:

- Nginx tentando conectar na porta 8081 (errado)
- Deveria conectar na porta 9000 (PHP-FPM do Docker)

### Solução:

1. Verificar configuração atual do Nginx
2. Se tiver 8081, alterar para 9000
3. Testar configuração
4. Recarregar Nginx

---

## 🚀 COMANDOS COMPLETOS

```bash
# 1. Verificar configuração atual
cat /etc/nginx/sites-available/cobranca-api

# 2. Procurar por 8081
grep -n "8081" /etc/nginx/sites-available/cobranca-api

# 3. Se precisar alterar
nano /etc/nginx/sites-available/cobranca-api

# 4. Testar configuração
nginx -t

# 5. Recarregar Nginx
systemctl reload nginx

# 6. Verificar status
systemctl status nginx
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

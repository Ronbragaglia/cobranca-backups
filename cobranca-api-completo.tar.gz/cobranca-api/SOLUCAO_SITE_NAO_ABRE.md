# 🔧 SOLUÇÃO - SITE NÃO ABRE EXTERNAMENTE

## 📋 Problema

O site está funcionando no localhost:
- ✅ `curl -I http://localhost` → HTTP/1.1 200 OK
- ✅ `curl -I http://localhost/index.php` → HTTP/1.1 200 OK
- ❌ `curl -I http://localhost/painel` → HTTP/1.1 404 Not Found
- ❌ `curl -I https://api.cobrancaauto.com.br/` → Connection refused

Mas não está acessível externamente.

## 🚀 Execute estes comandos na VPS (em ordem):

### Passo 1: Verificar se o Nginx está escutando nas portas 80 e 443
```bash
netstat -tlnp | grep nginx
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN      .../nginx
tcp        0      0 0.0.0.0:443             0.0.0.0:*               LISTEN      .../nginx
```

### Passo 2: Verificar se o firewall está bloqueando as portas
```bash
ufw status
```

**Resultado esperado:**
```
Status: active

To                         Action      From
--                         ------      ----
80/tcp                     ALLOW       Anywhere
443/tcp                    ALLOW       Anywhere
```

### Passo 3: Se o firewall estiver bloqueando, liberar as portas
```bash
ufw allow 80/tcp
ufw allow 443/tcp
ufw reload
```

### Passo 4: Verificar configuração do Nginx
```bash
nginx -t
```

**Resultado esperado:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### Passo 5: Verificar qual configuração do Nginx está sendo usada
```bash
cat /etc/nginx/sites-enabled/cobranca-api
```

### Passo 6: Testar o site externamente
```bash
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se o Passo 1 não mostrar as portas 80 e 443

Se o Nginx não estiver escutando nas portas 80 e 443, verifique:

```bash
# Verificar se o Nginx está rodando
systemctl status nginx

# Se não estiver rodando, iniciar
systemctl start nginx

# Habilitar para iniciar no boot
systemctl enable nginx
```

## 📋 Se o Passo 2 mostrar que o firewall está bloqueando

Libere as portas 80 e 443:

```bash
ufw allow 80/tcp
ufw allow 443/tcp
ufw reload
```

## 📋 Se o Passo 4 mostrar erros de configuração

Corrija os erros de configuração do Nginx:

```bash
# Editar a configuração
nano /etc/nginx/sites-enabled/cobranca-api

# Testar novamente
nginx -t

# Recarregar o Nginx
nginx -s reload
```

## 📋 Se o site ainda não funcionar

Verifique os logs do Nginx:

```bash
tail -50 /var/log/nginx/cobranca-api-error.log
tail -50 /var/log/nginx/cobranca-api-access.log
```

## 🎯 Resumo

O problema pode ser:
1. Firewall bloqueando as portas 80 e 443
2. Nginx não está escutando nas portas 80 e 443
3. Configuração do Nginx incorreta
4. DNS não está apontando corretamente

Execute os comandos acima em ordem e me envie os resultados!

# VERIFICAR CONFIGURAÇÃO DO NGINX

## 🚨 PROBLEMA

O PHP-FPM está rodando e escutando na porta 9000, mas o Nginx não está conseguindo conectar.

## ✅ VERIFICAÇÃO

Execute estes comandos:

```bash
# 1. Verificar arquivo de configuração do Nginx
cat /etc/nginx/sites-available/cobranca-api
```

```bash
# 2. Verificar se o arquivo está sendo usado
ls -la /etc/nginx/sites-enabled/ | grep cobranca
```

```bash
# 3. Verificar se há link simbólico
ls -la /etc/nginx/sites-enabled/cobranca-api
```

```bash
# 4. Testar configuração do Nginx
nginx -t
```

```bash
# 5. Recarregar Nginx
systemctl reload nginx
```

```bash
# 6. Verificar status do Nginx
systemctl status nginx
```

---

## 🔧 SOLUÇÃO: RECONFIGURAR NGINX

Se o arquivo de configuração não estiver correto, reconfigure:

```bash
# 1. Fazer backup
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup2

# 2. Criar nova configuração
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 20M;

    root /var/www/cobranca-api/public;
    index index.php index.html;

    location /health {
        access_log off;
        try_files $uri /index.php?$query_string;
    }

    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_connect_timeout 60;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 256 16k;
        fastcgi_busy_buffers_size 256k;
    }

    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
        gzip_static on;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# 3. Testar configuração
nginx -t

# 4. Recarregar Nginx
systemctl reload nginx

# 5. Verificar status
systemctl status nginx
```

---

## 📋 O QUE ESPERAR

### Após `nginx -t`:
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### Após `systemctl status nginx`:
```
Active: active (running)
```

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar arquivo de configuração do Nginx
cat /etc/nginx/sites-available/cobranca-api

# 2. Verificar se o arquivo está sendo usado
ls -la /etc/nginx/sites-enabled/ | grep cobranca

# 3. Verificar se há link simbólico
ls -la /etc/nginx/sites-enabled/cobranca-api

# 4. Testar configuração do Nginx
nginx -t

# 5. Recarregar Nginx
systemctl reload nginx

# 6. Verificar status do Nginx
systemctl status nginx

# 7. Testar health check
curl https://api.cobrancaauto.com.br/health

# 8. Testar site
curl https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

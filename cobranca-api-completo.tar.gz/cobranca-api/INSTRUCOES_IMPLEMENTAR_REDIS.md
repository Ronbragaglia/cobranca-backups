# INSTRUÇÕES PARA IMPLEMENTAR REDIS

## 📋 VISÃO GERAL

Redis é **CRÍTICO** para a FASE 0 do roadmap técnico, sendo necessário para:
- **Rate Limiting** (por IP, tenant e endpoint)
- **Filas Distribuídas** (mais eficiente que database)
- **Cache Distribuído** (melhora performance significativamente)
- **Session Storage** (sessões persistentes entre instâncias)

## 🎯 OBJETIVO

Migrar de `database` para `redis` em:
- Queue connection (filas)
- Cache store (cache)
- Session driver (sessões)

---

## 📝 SITUAÇÃO ATUAL

### ✅ JÁ CONFIGURADO NO LARAVEL
- `config/database.php` - Redis connections configuradas (default e cache)
- `config/cache.php` - Redis store configurado
- `config/queue.php` - Redis connection configurada

### ❌ PRECISA IMPLEMENTAR
- Extensão Redis no Dockerfile
- Container Redis no docker-compose.prod.yml
- Variáveis de ambiente para usar Redis
- Pacote phpredis no composer.json

---

## 🔧 PASSO A PASSO

### 1. Atualizar Dockerfile

Adicionar extensão Redis do PHP:

```dockerfile
# Linha 21 - Adicionar redis às extensões
RUN apk update && apk add \
    git \
    curl \
    libpng-dev \
    oniguruma-dev \
    libxml2-dev \
    libzip-dev \
    zip \
    unzip \
    nodejs \
    npm \
    dcron \
    mariadb-client \
    && docker-php-ext-install pdo_mysql mbstring exif pcntl bcmath gd zip redis
```

**Arquivo:** [`Dockerfile`](Dockerfile:21)

---

### 2. Atualizar docker-compose.prod.yml

Adicionar serviço Redis:

```yaml
# Adicionar após o serviço mysql (após linha 21)

  redis:
    image: redis:7-alpine
    container_name: cobranca_redis
    restart: unless-stopped
    command: redis-server --appendonly yes --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    networks:
      - cobranca_network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

# Adicionar redis_data aos volumes (após linha 118)
volumes:
  mysql_data:
  redis_data:
  backups:
```

Atualizar serviços para usar Redis:

```yaml
# Serviço app - alterar QUEUE_CONNECTION
    environment:
      APP_ENV: production
      APP_KEY: ${APP_KEY}
      DB_CONNECTION: mysql
      DB_HOST: mysql
      DB_PORT: 3306
      DB_DATABASE: cobranca
      DB_USERNAME: cobranca_user
      DB_PASSWORD: ${DB_PASSWORD}
      QUEUE_CONNECTION: redis  # MUDAR DE database PARA redis
      CACHE_DRIVER: redis      # ADICIONAR
      SESSION_DRIVER: redis    # ADICIONAR
      REDIS_HOST: redis       # ADICIONAR
      REDIS_PASSWORD: ${REDIS_PASSWORD}  # ADICIONAR
      REDIS_PORT: 6379       # ADICIONAR
    depends_on:
      mysql:
        condition: service_healthy
      redis:                 # ADICIONAR
        condition: service_healthy  # ADICIONAR

# Serviço queue - alterar QUEUE_CONNECTION
    environment:
      APP_ENV: production
      APP_KEY: ${APP_KEY}
      DB_CONNECTION: mysql
      DB_HOST: mysql
      DB_PORT: 3306
      DB_DATABASE: cobranca
      DB_USERNAME: cobranca_user
      DB_PASSWORD: ${DB_PASSWORD}
      QUEUE_CONNECTION: redis  # MUDAR DE database PARA redis
      CACHE_DRIVER: redis      # ADICIONAR
      SESSION_DRIVER: redis    # ADICIONAR
      REDIS_HOST: redis       # ADICIONAR
      REDIS_PASSWORD: ${REDIS_PASSWORD}  # ADICIONAR
      REDIS_PORT: 6379       # ADICIONAR
    depends_on:
      - app
      - redis:                # ADICIONAR
        condition: service_healthy  # ADICIONAR

# Serviço scheduler - alterar QUEUE_CONNECTION
    environment:
      APP_ENV: production
      APP_KEY: ${APP_KEY}
      DB_CONNECTION: mysql
      DB_HOST: mysql
      DB_PORT: 3306
      DB_DATABASE: cobranca
      DB_USERNAME: cobranca_user
      DB_PASSWORD: ${DB_PASSWORD}
      QUEUE_CONNECTION: redis  # MUDAR DE database PARA redis
      CACHE_DRIVER: redis      # ADICIONAR
      SESSION_DRIVER: redis    # ADICIONAR
      REDIS_HOST: redis       # ADICIONAR
      REDIS_PASSWORD: ${REDIS_PASSWORD}  # ADICIONAR
      REDIS_PORT: 6379       # ADICIONAR
    depends_on:
      - app
      - redis:                # ADICIONAR
        condition: service_healthy  # ADICIONAR
```

**Arquivo:** [`docker-compose.prod.yml`](docker-compose.prod.yml:1)

---

### 3. Atualizar .env.example

Adicionar variáveis Redis:

```env
# Redis Configuration
REDIS_HOST=redis
REDIS_PASSWORD=your_redis_password_here
REDIS_PORT=6379
REDIS_DB=0
REDIS_CACHE_DB=1

# Queue & Cache Configuration
QUEUE_CONNECTION=redis
CACHE_DRIVER=redis
SESSION_DRIVER=redis
```

**Arquivo:** [`.env.example`](.env.example:1)

---

### 4. Atualizar .env (produção)

Adicionar as mesmas variáveis do .env.example, mas com valores reais:

```env
# Redis Configuration
REDIS_HOST=redis
REDIS_PASSWORD=senha_segura_aleatoria_aqui
REDIS_PORT=6379
REDIS_DB=0
REDIS_CACHE_DB=1

# Queue & Cache Configuration
QUEUE_CONNECTION=redis
CACHE_DRIVER=redis
SESSION_DRIVER=redis
```

**IMPORTANTE:** Gerar uma senha forte para `REDIS_PASSWORD`:

```bash
# Gerar senha forte
openssl rand -base64 32
```

**Arquivo:** [`.env`](.env:1)

---

### 5. Rebuild e Deploy

```bash
# Parar containers existentes
docker-compose -f docker-compose.prod.yml down

# Rebuild com as mudanças
docker-compose -f docker-compose.prod.yml build --no-cache

# Subir containers
docker-compose -f docker-compose.prod.yml up -d

# Verificar se Redis está rodando
docker-compose -f docker-compose.prod.yml logs redis

# Verificar se app está conectando ao Redis
docker-compose -f docker-compose.prod.yml logs app | grep redis
```

---

## ✅ VERIFICAÇÃO

### Testar conexão com Redis

```bash
# Entrar no container app
docker exec -it cobranca_app sh

# Testar conexão Redis
php artisan tinker
>>> Redis::ping()
=> true
>>> exit
```

### Testar filas com Redis

```bash
# Verificar se filas estão usando Redis
docker exec -it cobranca_app sh
php artisan queue:failed
php artisan queue:retry all
```

### Testar cache com Redis

```bash
# Testar cache
php artisan tinker
>>> Cache::put('test', 'value', 60)
=> true
>>> Cache::get('test')
=> "value"
>>> Cache::forget('test')
=> true
>>> exit
```

---

## 📊 BENEFÍCIOS ESPERADOS

### Performance
- **Filas:** 10-100x mais rápidas que database
- **Cache:** Acesso em memória vs disco
- **Rate Limiting:** Contagem em memória, sem queries ao banco

### Escalabilidade
- **Distribuído:** Múltiplos workers podem acessar o mesmo Redis
- **Sessões:** Sessões persistentes entre instâncias
- **Cache compartilhado:** Cache disponível para todas as instâncias

### Estabilidade
- **Persistência:** Redis com AOF (Append Only File)
- **Health checks:** Monitoramento de saúde do Redis
- **Retry automático:** Laravel lida com falhas de Redis

---

## ⚠️ CONSIDERAÇÕES

### Memória
- Redis usa RAM para armazenamento
- Monitorar uso de memória do container Redis
- Configurar `maxmemory` se necessário

### Backup
- Redis data precisa ser backupado
- Volume `redis_data` já configurado no docker-compose
- Considerar backup periódico do Redis

### Segurança
- Senha forte obrigatória (REDIS_PASSWORD)
- Redis não exposto para fora da rede Docker
- Usar Redis 7+ (versão mais recente e segura)

---

## 🚨 TROUBLESHOOTING

### Erro: "Connection refused"

**Causa:** App não consegue conectar ao Redis

**Solução:**
```bash
# Verificar se Redis está rodando
docker-compose -f docker-compose.prod.yml ps redis

# Verificar logs do Redis
docker-compose -f docker-compose.prod.yml logs redis

# Verificar rede Docker
docker network inspect cobranca_cobranca_network
```

### Erro: "NOAUTH Authentication required"

**Causa:** Senha do Redis incorreta

**Solução:**
```bash
# Verificar senha no .env
grep REDIS_PASSWORD .env

# Verificar senha no docker-compose.prod.yml
grep REDIS_PASSWORD docker-compose.prod.yml

# Deve ser a mesma senha
```

### Erro: "Redis connection timed out"

**Causa:** Redis não está healthy quando app tenta conectar

**Solução:**
```bash
# Verificar healthcheck do Redis
docker inspect cobranca_redis | grep -A 10 Health

# Aumentar tempo de espera no depends_on
# Ou adicionar delay antes de iniciar app
```

---

## 📚 REFERÊNCIAS

- [Laravel Redis Documentation](https://laravel.com/docs/redis)
- [Redis Documentation](https://redis.io/docs/)
- [Docker Redis Image](https://hub.docker.com/_/redis)

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA IMPLEMENTAÇÃO

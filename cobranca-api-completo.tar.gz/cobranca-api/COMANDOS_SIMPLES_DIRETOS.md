# COMANDOS SIMPLES E DIRETOS

## 🚨 PROBLEMA

O container `cobranca_app` está rodando, mas a porta 9000 não está exposta.

## ✅ SOLUÇÃO: COMANDOS SIMPLES E DIRETOS

Execute estes comandos UM POR VEZ:

```bash
docker stop cobranca_app
```

```bash
docker rm cobranca_app
```

```bash
docker run -d --name cobranca_app --restart unless-stopped --network cobranca-api_cobranca_network -p 127.0.0.1:9000:9000 -v /var/www/cobranca-api/storage:/var/www/storage cobranca-api_app php-fpm
```

```bash
sleep 10
```

```bash
docker port cobranca_app
```

```bash
curl -I http://127.0.0.1:9000
```

```bash
curl https://api.cobrancaauto.com.br/health
```

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `docker port cobranca_app`:
```
9000/tcp -> 127.0.0.1:9000
```

### Após `curl -I http://127.0.0.1:9000`:
```
HTTP/1.1 404 Not Found
```

### Após `curl https://api.cobrancaauto.com.br/health`:
```
{"status":"ok"}
```

### Após `curl https://api.cobrancaauto.com.br/`:
HTML ou JSON (não 502)

---

## 📝 CHECKLIST

- [ ] Container cobranca_app parado
- [ ] Container cobranca_app removido
- [ ] Novo container criado com porta exposta
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

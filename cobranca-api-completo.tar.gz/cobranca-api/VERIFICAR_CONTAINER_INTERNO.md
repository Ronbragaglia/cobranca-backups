# VERIFICAR DENTRO DO CONTAINER

## 🚨 PROBLEMA

O curl está retornando "File not found" mesmo que a porta 9000 esteja exposta.

## ✅ VERIFICAÇÃO

Execute estes comandos:

```bash
# 1. Verificar se o container está rodando
docker ps | grep cobranca_app
```

```bash
# 2. Verificar logs do container
docker logs cobranca_app | tail -50
```

```bash
# 3. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm
```

```bash
# 4. Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

```bash
# 5. Verificar se o diretório public existe
docker exec cobranca_app ls -la /var/www/public/
```

```bash
# 6. Verificar se o arquivo index.php existe
docker exec cobranca_app cat /var/www/public/index.php | head -20
```

```bash
# 7. Verificar se o Laravel está instalado
docker exec cobranca_app php artisan --version
```

```bash
# 8. Verificar se o .env está correto
docker exec cobranca_app cat /var/www/.env | grep -E "(APP_KEY|DB_HOST|REDIS_HOST)" | head -10
```

```bash
# 9. Testar o PHP-FPM dentro do container
docker exec cobranca_app wget -O- http://127.0.0.1:9000/index.php
```

```bash
# 10. Verificar se há erros de permissão
docker exec cobranca_app ls -la /var/www/storage/
```

---

## 🔧 SOLUÇÃO 1: VERIFICAR SE O DIRETÓRIO PUBLIC ESTÁ CORRETO

Se o diretório public não estiver correto, recrie:

```bash
# Verificar se o diretório public existe no host
ls -la /var/www/cobranca-api/public/

# Se não existir ou estiver vazio, copie do container
docker cp cobranca_app:/var/www/public /var/www/cobranca-api/public.backup
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR SE O LARAVEL ESTÁ CONFIGURADO CORRETAMENTE

Se o Laravel não estiver configurado corretamente:

```bash
# Entrar no container
docker exec -it cobranca_app sh

# Dentro do container, execute:
cd /var/www
php artisan config:cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
exit
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE O PHP-FPM ESTÁ PROCESSANDO CORRETAMENTE

Se o PHP-FPM não estiver processando corretamente:

```bash
# Verificar configuração do PHP-FPM
docker exec cobranca_app cat /usr/local/etc/php-fpm.d/www.conf

# Se a configuração estiver incorreta, atualize
docker exec cobranca_app sh -c "echo 'listen = 127.0.0.1:9000' > /usr/local/etc/php-fpm.d/www.conf"

# Reiniciar o container
docker restart cobranca_app
```

---

## 📝 RESUMO

### O que verificar:

1. Se o container está rodando
2. Logs do container
3. Se o PHP-FPM está rodando
4. Se o PHP-FPM está escutando
5. Se o diretório public existe
6. Se o arquivo index.php existe
7. Se o Laravel está instalado
8. Se o .env está correto
9. Testar o PHP-FPM dentro do container
10. Se há erros de permissão

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar se o container está rodando
docker ps | grep cobranca_app

# 2. Verificar logs do container
docker logs cobranca_app | tail -50

# 3. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# 4. Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000

# 5. Verificar se o diretório public existe
docker exec cobranca_app ls -la /var/www/public/

# 6. Verificar se o arquivo index.php existe
docker exec cobranca_app cat /var/www/public/index.php | head -20

# 7. Verificar se o Laravel está instalado
docker exec cobranca_app php artisan --version

# 8. Verificar se o .env está correto
docker exec cobranca_app cat /var/www/.env | grep -E "(APP_KEY|DB_HOST|REDIS_HOST)" | head -10

# 9. Testar o PHP-FPM dentro do container
docker exec cobranca_app wget -O- http://127.0.0.1:9000/index.php

# 10. Verificar se há erros de permissão
docker exec cobranca_app ls -la /var/www/storage/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

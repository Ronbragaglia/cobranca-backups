# SOLUÇÃO FINAL ATUALIZADA - 2026-02-04

## 🚨 PROBLEMAS IDENTIFICADOS

### Problema 1: Variáveis MySQL comentadas no .env ✅ RESOLVIDO
As variáveis `MYSQL_ROOT_PASSWORD` e `MYSQL_ALLOW_EMPTY_PASSWORD` estavam **comentadas** (com `#` na frente), mas foram descomentadas.

### Problema 2: Configuração do Nginx incompleta ❌ NÃO RESOLVIDO
A configuração do Nginx tem ````nginx` no início, o que causa erro:
```
nginx: [emerg] unknown directive "```nginx" in /etc/nginx/sites-enabled/cobranca-api:4
```

### Problema 3: Porta 9000 não exposta ❌ NÃO RESOLVIDO
A porta 9000 não está sendo exposta (netstat não mostra nada).

---

## ✅ SOLUÇÃO - PASSO A PASSO

### PARTE 1: VERIFICAR SE O PHP-FPM ESTÁ RODANDO

#### PASSO 1: Verificar logs do container app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -30
```

#### PASSO 2: Verificar se o PHP-FPM está rodando dentro do container

```bash
docker exec cobranca_app ps aux | grep php-fpm
```

**Deveria mostrar algo como:**
```
www-data   123  0.0  0.0 123456  7890 ?        Ss   18:00   0:00 php-fpm: master process
www-data   456  0.0  0.0 123456  7890 ?        S    18:00   0:00 php-fpm: pool www
```

#### PASSO 3: Verificar se o PHP-FPM está escutando na porta 9000

```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Deveria mostrar algo como:**
```
tcp        0      0.0.0.0:9000            0.0.0.0:*               LISTEN
```

#### PASSO 4: Verificar se a porta 9000 está exposta no host

```bash
docker port cobranca_app
```

**Deveria mostrar:**
```
9000/tcp -> 127.0.0.1:9000
```

#### PASSO 5: Testar conexão do host para o container

```bash
curl -I http://127.0.0.1:9000
```

**Deveria mostrar algo como:**
```
HTTP/1.1 404 Not Found
```

---

### PARTE 2: CORRIGIR CONFIGURAÇÃO DO NGINX

#### PASSO 6: Restaurar backup

```bash
cp /etc/nginx/sites-available/cobranca-api.backup /etc/nginx/sites-available/cobranca-api
```

#### PASSO 7: Editar arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

#### PASSO 8: Encontrar a linha com `proxy_pass http://127.0.0.1:8081;`

Procure por algo assim:

```nginx
# Proxy to Docker container (cobranca-nginx-simple on port 8081)
location / {
    proxy_pass http://127.0.0.1:8081;
```

#### PASSO 9: Alterar para conectar ao PHP-FPM na porta 9000

Substitua o bloco `location / { ... }` por:

```nginx
# Root directory
root /var/www/cobranca-api/public;
index index.php index.html;

# Health check endpoint
location /health {
    access_log off;
    try_files $uri /index.php?$query_string;
}

# PHP files - Conectar ao PHP-FPM do container Docker na porta 9000
location ~ \.php$ {
    try_files $uri =404;
    fastcgi_split_path_info ^(.+\.php)(/.+)$;

    # Conectar ao PHP-FPM do container Docker
    fastcgi_pass 127.0.0.1:9000;

    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_param PATH_INFO $fastcgi_path_info;

    # Timeout
    fastcgi_read_timeout 300;
    fastcgi_send_timeout 300;
    fastcgi_connect_timeout 60;

    # Buffers
    fastcgi_buffer_size 128k;
    fastcgi_buffers 256 16k;
    fastcgi_busy_buffers_size 256k;
}

# Static files
location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    access_log off;
}

# Main location
location / {
    try_files $uri $uri/ /index.php?$query_string;
    gzip_static on;
}

# Negar acesso a arquivos ocultos
location ~ /\. {
    deny all;
    access_log off;
    log_not_found off;
}
```

#### PASSO 10: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

#### PASSO 11: Testar configuração do Nginx

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

#### PASSO 12: Recarregar Nginx

```bash
systemctl reload nginx
```

#### PASSO 13: Verificar se o Nginx está rodando

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

---

### PARTE 3: TESTAR SITE

#### PASSO 14: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

**Deveria retornar:** `{"status":"ok"}` ou similar

#### PASSO 15: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

**Deveria retornar:** HTML ou JSON (não 502)

---

## 📝 RESUMO

### Problemas identificados:

1. ✅ Variáveis MySQL comentadas no .env - **RESOLVIDO**
2. ❌ Configuração do Nginx incompleta - **NÃO RESOLVIDO**
3. ❌ Porta 9000 não exposta - **NÃO RESOLVIDO**

### Soluções:

1. ✅ Descomentar as variáveis no .env - **FEITO**
2. ❌ Atualizar configuração do Nginx - **PENDENTE**
3. ❌ Verificar se o PHP-FPM está rodando - **PENDENTE**

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# PARTE 1: Verificar se o PHP-FPM está rodando
docker-compose -f docker-compose.prod.yml logs app | tail -30
docker exec cobranca_app ps aux | grep php-fpm
docker exec cobranca_app netstat -tlnp | grep 9000
docker port cobranca_app
curl -I http://127.0.0.1:9000

# PARTE 2: Corrigir configuração do Nginx
cp /etc/nginx/sites-available/cobranca-api.backup /etc/nginx/sites-available/cobranca-api
nano /etc/nginx/sites-available/cobranca-api
# Encontrar e alterar a linha proxy_pass para fastcgi_pass 127.0.0.1:9000
# Salvar: Ctrl+O, Enter, Ctrl+X

nginx -t
systemctl reload nginx
systemctl status nginx

# PARTE 3: Testar site
curl https://api.cobrancaauto.com.br/health
curl https://api.cobrancaauto.com.br/
```

---

## 📋 CHECKLIST

- [ ] PHP-FPM rodando dentro do container
- [ ] PHP-FPM escutando na porta 9000
- [ ] Porta 9000 exposta no host
- [ ] Configuração do Nginx atualizada
- [ ] Nginx recarregado
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

## 🔍 SE O PHP-FPM NÃO ESTIVER RODANDO

Se o PHP-FPM não estiver rodando, verifique:

1. Logs do container app:
```bash
docker-compose -f docker-compose.prod.yml logs app
```

2. Se o container está rodando:
```bash
docker-compose -f docker-compose.prod.yml ps app
```

3. Se há erros de inicialização:
```bash
docker logs cobranca_app
```

---

## 🔍 SE DER ERRO NO TESTE DO NGINX

Se o comando `nginx -t` der erro, verifique:

1. Se não tem ````nginx` no início do arquivo:
```bash
head -10 /etc/nginx/sites-available/cobranca-api
```

2. Se há erros de sintaxe:
```bash
nginx -t
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 2.0  
**STATUS:** PRONTO PARA EXECUÇÃO

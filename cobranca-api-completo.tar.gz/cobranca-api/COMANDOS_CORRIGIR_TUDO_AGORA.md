# COMANDOS PARA CORRIGIR TUDO AGORA

## 🚨 PROBLEMAS IDENTIFICADOS

1. **APP_KEY** está como placeholder (causa erro 500)
2. **Redis** não está configurado no .env
3. **Porta 9000** do PHP-FPM não está exposta (causa erro 502)
4. **Nginx** não está configurado corretamente

---

## ✅ SOLUÇÃO COMPLETA

Execute estes comandos na VPS, em ordem:

### 1. Gerar nova APP_KEY

```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml exec app php artisan key:generate --force
```

### 2. Editar .env para corrigir configurações

```bash
nano .env
```

**Faça estas alterações:**

```env
# 1. Verifique se APP_KEY foi gerada (deve estar como base64:...)
APP_KEY=base64:CHAVE_GERADA_ACIMA

# 2. Mude QUEUE_CONNECTION de database para redis
QUEUE_CONNECTION=redis

# 3. Mude REDIS_PASSWORD de null para uma senha forte
REDIS_PASSWORD=senha_forte_aqui

# 4. Adicione estas linhas (se não existirem)
REDIS_DB=0
REDIS_CACHE_DB=1
```

**Gerar senha forte para Redis:**
```bash
# Em outro terminal, gere uma senha
openssl rand -base64 32
```

**Salvar e sair:** Ctrl+O, Enter, Ctrl+X

### 3. Parar containers

```bash
docker-compose -f docker-compose.prod.yml down
```

### 4. Subir containers novamente

```bash
docker-compose -f docker-compose.prod.yml up -d
```

### 5. Verificar se containers estão rodando

```bash
docker-compose -f docker-compose.prod.yml ps
```

**Deveria mostrar:**
```
NAME                STATUS
cobranca_app       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_mysql       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
```

### 6. Testar conexão com Redis

```bash
docker-compose -f docker-compose.prod.yml exec app php artisan tinker
>>> Redis::ping()
=> true
>>> exit
```

### 7. Testar se a porta 9000 está exposta

```bash
# Verificar se a porta 9000 está escutando
netstat -tlnp | grep 9000

# Deveria mostrar:
# tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

### 8. Copiar configuração do Nginx

```bash
# O arquivo nginx-host.conf já foi criado no projeto
# Copiar para o servidor
scp nginx-host.conf root@76.13.167.54:/tmp/
```

### 9. Configurar Nginx no servidor

```bash
# SSH para o servidor
ssh root@76.13.167.54

# Mover arquivo para o lugar certo
mv /tmp/nginx-host.conf /etc/nginx/sites-available/cobranca-api

# Criar link simbólico
ln -s /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Testar configuração
nginx -t

# Recarregar Nginx
systemctl reload nginx
```

### 10. Testar health check

```bash
# Testar localmente (no servidor)
curl http://127.0.0.1:9000/health

# Testar externamente
curl https://api.cobrancaauto.com.br/health
```

### 11. Testar site principal

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 🔍 VERIFICAÇÃO

### Verificar logs do app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -50
```

### Verificar logs do Nginx

```bash
tail -f /var/log/nginx/cobranca-api-error.log
```

### Verificar logs do Redis

```bash
docker-compose -f docker-compose.prod.yml logs redis
```

---

## ⚠️ SE AINDA DER ERRO 500

### Limpar cache e sessões

```bash
docker-compose -f docker-compose.prod.yml exec app php artisan cache:clear
docker-compose -f docker-compose.prod.yml exec app php artisan config:clear
docker-compose -f docker-compose.prod.yml exec app php artisan view:clear
```

### Limpar cookies do navegador

1. Abra o navegador
2. Pressione F12 (Developer Tools)
3. Vá para Application → Cookies
4. Delete todos os cookies de `api.cobrancaauto.com.br`
5. Recarregue a página (F5)

---

## ⚠️ SE AINDA DER ERRO 502

### Verificar se PHP-FPM está rodando

```bash
docker-compose -f docker-compose.prod.yml logs app | grep fpm
```

### Verificar logs do Nginx

```bash
tail -100 /var/log/nginx/cobranca-api-error.log
```

### Verificar se a porta 9000 está aberta

```bash
netstat -tlnp | grep 9000
```

Se não mostrar nada, o container app não está expondo a porta corretamente.

---

## 📝 RESUMO DAS ALTERAÇÕES

### Arquivos modificados:

1. **[`.env`](.env:1)** - APP_KEY gerada, Redis configurado
2. **[`docker-compose.prod.yml`](docker-compose.prod.yml:38)** - Porta 9000 exposta
3. **[`nginx-host.conf`](nginx-host.conf:1)** - Configuração Nginx criada

### Novos arquivos criados:

1. **[`CORRIGIR_ERRO_CRIPTOGRAFIA.md`](CORRIGIR_ERRO_CRIPTOGRAFIA.md:1)** - Instruções para erro 500
2. **[`CORRIGIR_ERRO_502_BAD_GATEWAY.md`](CORRIGIR_ERRO_502_BAD_GATEWAY.md:1)** - Instruções para erro 502
3. **[`INSTRUCOES_IMPLEMENTAR_REDIS.md`](INSTRUCOES_IMPLEMENTAR_REDIS.md:1)** - Instruções para Redis
4. **[`ROADMAP_TECNICO.md`](ROADMAP_TECNICO.md:1)** - Roadmap técnico (versão 2.0)

---

## 🚀 PRÓXIMOS PASSOS

Após executar os comandos acima:

1. Acesse: https://api.cobrancaauto.com.br/health
2. Deveria retornar: `{"status":"ok"}` ou similar
3. Acesse: https://api.cobrancaauto.com.br/
4. O site deveria carregar sem erros

Se ainda tiver problemas, verifique os logs:

```bash
# Logs do app
docker-compose -f docker-compose.prod.yml logs -f app

# Logs do Nginx
tail -f /var/log/nginx/cobranca-api-error.log
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

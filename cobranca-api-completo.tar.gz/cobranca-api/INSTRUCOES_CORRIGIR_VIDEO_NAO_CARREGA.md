# 🔧 VÍDEO NÃO CARREGA - SOLUÇÃO

## 📋 PROBLEMA

O vídeo foi adicionado ao final do arquivo, mas provavelmente está fora do container principal ou em uma posição onde não é visível.

## 📋 SOLUÇÃO: ADICIONAR VÍDEO EM POSIÇÃO CORRETA

### Passo 1: Verificar estrutura do arquivo

```bash
cd /var/www/cobranca-api
tail -30 resources/views/landing.blade.php
```

### Passo 2: Opção 1 - Adicionar vídeo antes do último </div>@endif

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Remover o vídeo do final do arquivo (se existir)
sed -i '/{{-- Vídeo Demo do YouTube --}/,/iframe>/d' resources/views/landing.blade.php

# Adicionar vídeo antes do último </div>@endif
# Primeiro, vamos encontrar onde adicionar
grep -n "@endif" resources/views/landing.blade.php | tail -1
```

### Passo 3: Opção 2 - Adicionar vídeo usando Python (MAIS PRECISO)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para adicionar vídeo
cat > /tmp/add_video.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Remover vídeo existente (se houver)
content = re.sub(r'{{-- Vídeo Demo do YouTube --}}.*?</iframe>', '', content, flags=re.DOTALL)

# Código do vídeo
video_code = '''

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
'''

# Encontrar o último </div>@endif e adicionar antes dele
pattern = r'(\s*</div>\s*@endif)'
match = re.search(pattern, content)

if match:
    # Adicionar vídeo antes do último </div>@endif
    content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
    print("✅ Vídeo adicionado antes do último </div>@endif")
else:
    # Se não encontrar, adicionar antes do último @endif
    pattern = r'(\s*@endif)'
    match = re.search(pattern, content)
    if match:
        content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
        print("✅ Vídeo adicionado antes do último @endif")
    else:
        # Se não encontrar, adicionar no final
        content += video_code
        print("✅ Vídeo adicionado no final do arquivo")

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/add_video.py

# Limpar script temporário
rm -f /tmp/add_video.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Passo 4: Verificar se vídeo foi adicionado

```bash
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Passo 5: Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

## 📋 OPÇÃO 3: USAR VÍDEO LOCAL (MAIS SIMPLES)

Se o vídeo do YouTube não funcionar, use o vídeo local:

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para adicionar vídeo local
cat > /tmp/add_video_local.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Remover vídeo existente (se houver)
content = re.sub(r'{{-- Vídeo Demo.*?</iframe>', '', content, flags=re.DOTALL)
content = re.sub(r'{{-- Vídeo Demo Local.*?</video>', '', content, flags=re.DOTALL)

# Código do vídeo local
video_code = '''

{{-- Vídeo Demo Local --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <video
            controls
            class="w-full h-full"
        >
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">
            Seu navegador não suporta vídeos.
        </video>
    </div>
</div>
'''

# Encontrar o último </div>@endif e adicionar antes dele
pattern = r'(\s*</div>\s*@endif)'
match = re.search(pattern, content)

if match:
    # Adicionar vídeo antes do último </div>@endif
    content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
    print("✅ Vídeo adicionado antes do último </div>@endif")
else:
    # Se não encontrar, adicionar antes do último @endif
    pattern = r'(\s*@endif)'
    match = re.search(pattern, content)
    if match:
        content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
        print("✅ Vídeo adicionado antes do último @endif")
    else:
        # Se não encontrar, adicionar no final
        content += video_code
        print("✅ Vídeo adicionado no final do arquivo")

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/add_video_local.py

# Limpar script temporário
rm -f /tmp/add_video_local.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 VERIFICAÇÕES

### Verificar se vídeo foi adicionado

```bash
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

OU

```bash
grep -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar se backup foi criado

```bash
ls -lh /var/www/cobranca-api/resources/views/landing.blade.php.backup.*
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Acessar site no navegador

```
https://api.cobrancaauto.com.br
```

## 📋 SOLUÇÃO DE PROBLEMAS

### Problema: Vídeo ainda não aparece

**Solução:** Verificar se o vídeo está dentro do container principal

```bash
# Verificar estrutura do arquivo
tail -50 resources/views/landing.blade.php
```

### Problema: Vídeo do YouTube bloqueado

**Solução:** Usar vídeo local (Opção 3)

### Problema: Erro ao executar script Python

**Solução:** Verificar se Python3 está instalado

```bash
python3 --version
```

Se não estiver instalado:

```bash
apt update && apt install -y python3
```

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Opção 2: Adicionar vídeo usando Python (RECOMENDADO - MAIS PRECISO)

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/add_video.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r'{{-- Vídeo Demo do YouTube --}}.*?</iframe>', '', content, flags=re.DOTALL)

video_code = '''

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
'''

pattern = r'(\s*</div>\s*@endif)'
match = re.search(pattern, content)

if match:
    content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
    print("✅ Vídeo adicionado antes do último </div>@endif")
else:
    pattern = r'(\s*@endif)'
    match = re.search(pattern, content)
    if match:
        content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
        print("✅ Vídeo adicionado antes do último @endif")
    else:
        content += video_code
        print("✅ Vídeo adicionado no final do arquivo")

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

python3 /tmp/add_video.py
rm -f /tmp/add_video.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Opção 3: Usar vídeo local (MAIS SIMPLES)

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/add_video_local.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r'{{-- Vídeo Demo.*?</iframe>', '', content, flags=re.DOTALL)
content = re.sub(r'{{-- Vídeo Demo Local.*?</video>', '', content, flags=re.DOTALL)

video_code = '''

{{-- Vídeo Demo Local --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <video
            controls
            class="w-full h-full"
        >
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">
            Seu navegador não suporta vídeos.
        </video>
    </div>
</div>
'''

pattern = r'(\s*</div>\s*@endif)'
match = re.search(pattern, content)

if match:
    content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
    print("✅ Vídeo adicionado antes do último </div>@endif")
else:
    pattern = r'(\s*@endif)'
    match = re.search(pattern, content)
    if match:
        content = content[:match.start()] + video_code + match.group(0) + content[match.end():]
        print("✅ Vídeo adicionado antes do último @endif")
    else:
        content += video_code
        print("✅ Vídeo adicionado no final do arquivo")

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

python3 /tmp/add_video_local.py
rm -f /tmp/add_video_local.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

---

**Execute os comandos acima para corrigir o vídeo! 🚀**

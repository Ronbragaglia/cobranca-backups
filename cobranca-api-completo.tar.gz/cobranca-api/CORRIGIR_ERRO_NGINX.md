# CORRIGIR ERRO DO NGINX - ```nginx

## 🚨 PROBLEMA

O arquivo de configuração do Nginx tem ````nginx` no início, o que causa erro:

```
nginx: [emerg] unknown directive "```nginx" in /etc/nginx/sites-enabled/cobranca-api:4
```

## ✅ SOLUÇÃO

### PASSO 1: Restaurar backup

```bash
cp /etc/nginx/sites-available/cobranca-api.backup /etc/nginx/sites-available/cobranca-api
```

### PASSO 2: Editar arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

### PASSO 3: Encontrar a linha com `proxy_pass http://127.0.0.1:8081;`

Procure por algo assim:

```nginx
# Proxy to Docker container (cobranca-nginx-simple on port 8081)
location / {
    proxy_pass http://127.0.0.1:8081;
```

### PASSO 4: Alterar para conectar ao PHP-FPM na porta 9000

Substitua o bloco `location / { ... }` por:

```nginx
# Root directory
root /var/www/cobranca-api/public;
index index.php index.html;

# Health check endpoint
location /health {
    access_log off;
    try_files $uri /index.php?$query_string;
}

# PHP files - Conectar ao PHP-FPM do container Docker na porta 9000
location ~ \.php$ {
    try_files $uri =404;
    fastcgi_split_path_info ^(.+\.php)(/.+)$;

    # Conectar ao PHP-FPM do container Docker
    fastcgi_pass 127.0.0.1:9000;

    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_param PATH_INFO $fastcgi_path_info;

    # Timeout
    fastcgi_read_timeout 300;
    fastcgi_send_timeout 300;
    fastcgi_connect_timeout 60;

    # Buffers
    fastcgi_buffer_size 128k;
    fastcgi_buffers 256 16k;
    fastcgi_busy_buffers_size 256k;
}

# Static files
location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    access_log off;
}

# Main location
location / {
    try_files $uri $uri/ /index.php?$query_string;
    gzip_static on;
}

# Negar acesso a arquivos ocultos
location ~ /\. {
    deny all;
    access_log off;
    log_not_found off;
}
```

### PASSO 5: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

### PASSO 6: Testar configuração do Nginx

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### PASSO 7: Recarregar Nginx

```bash
systemctl reload nginx
```

### PASSO 8: Verificar se o Nginx está rodando

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

---

## 📝 RESUMO

### Problema:

- Arquivo de configuração do Nginx tem ````nginx` no início
- Isso causa erro de diretiva desconhecida

### Solução:

1. Restaurar backup
2. Editar arquivo e alterar `proxy_pass http://127.0.0.1:8081;` para `fastcgi_pass 127.0.0.1:9000;`
3. Testar e recarregar Nginx

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Restaurar backup
cp /etc/nginx/sites-available/cobranca-api.backup /etc/nginx/sites-available/cobranca-api

# 2. Editar arquivo
nano /etc/nginx/sites-available/cobranca-api

# 3. Encontrar e alterar a linha proxy_pass para fastcgi_pass 127.0.0.1:9000
# Salvar: Ctrl+O, Enter, Ctrl+X

# 4. Testar configuração
nginx -t

# 5. Recarregar Nginx
systemctl reload nginx

# 6. Verificar status
systemctl status nginx
```

---

## 🔍 SE DER ERRO NO TESTE DO NGINX

Se o comando `nginx -t` der erro, verifique:

1. Se não tem ````nginx` no início do arquivo:
```bash
head -10 /etc/nginx/sites-available/cobranca-api
```

2. Se há erros de sintaxe:
```bash
nginx -t
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

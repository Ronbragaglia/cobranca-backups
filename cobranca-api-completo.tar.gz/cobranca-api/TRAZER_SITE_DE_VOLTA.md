# TRAZER SITE DE VOLTA - INSTRUÇÕES SIMPLES

## 🚨 PROBLEMA

O container `cobranca_app` já existe e está impedindo a criação de um novo container com o mesmo nome.

## ✅ SOLUÇÃO RÁPIDA

Execute estes comandos em ordem:

```bash
# 1. Remover o container existente
docker rm -f cobranca_app

# 2. Subir todos os containers
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d

# 3. Aguardar 30 segundos
sleep 30

# 4. Verificar status dos containers
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps

# 5. Verificar se a porta 9000 está exposta
docker port cobranca_app

# 6. Testar conexão
curl -I http://127.0.0.1:9000

# 7. Testar health check
curl https://api.cobrancaauto.com.br/health

# 8. Testar site
curl https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps`:

```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

### Após `docker port cobranca_app`:

```
9000/tcp -> 127.0.0.1:9000
```

### Após `curl -I http://127.0.0.1:9000`:

```
HTTP/1.1 404 Not Found
```

### Após `curl https://api.cobrancaauto.com.br/health`:

```
{"status":"ok"}
```

### Após `curl https://api.cobrancaauto.com.br/`:

HTML ou JSON (não 502)

---

## 🔍 SE AINDA DER ERRO

Se ainda der erro, execute:

```bash
# Verificar logs do container app
docker logs cobranca_app | tail -50

# Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

---

## 📝 CHECKLIST

- [ ] Container cobranca_app removido
- [ ] Todos os containers rodando
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

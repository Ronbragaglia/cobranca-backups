# SOLUÇÃO SIMPLES - PHP-FPM IPv4

## 🚨 PROBLEMA

O PHP-FPM está escutando em `:::9000` (IPv6), mas o Nginx está tentando conectar em `127.0.0.1:9000` (IPv4).

## ✅ SOLUÇÃO

Execute estes comandos:

docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

docker restart cobranca_app

sleep 10

curl -I http://127.0.0.1:9000

curl -I https://api.cobrancaauto.com.br/

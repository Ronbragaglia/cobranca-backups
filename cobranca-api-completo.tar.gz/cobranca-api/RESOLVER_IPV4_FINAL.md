# 🔧 RESOLVER IPV4 FINAL

## 📋 Problema

1. O PHP-FPM está escutando em IPv6 (`:::9000`), não em IPv4 (`0.0.0.0:9000`)
2. A porta 9000 não está exposta do container para o host
3. O Nginx está configurado para conectar em `cobranca_app:9000` (nome do container)
4. O site está retornando `HTTP/1.1 500 Internal Server Error`

## 🚀 Execute estes comandos na VPS (em ordem):

### Passo 1: Reiniciar o PHP-FPM
```bash
docker exec cobranca_app killall php-fpm
docker exec cobranca_app php-fpm -D
```

### Passo 2: Aguardar 5 segundos
```bash
sleep 5
```

### Passo 3: Verificar se o PHP-FPM está escutando em IPv4
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm.conf)
```

### Passo 4: Se ainda estiver em IPv6, modificar o arquivo novamente
```bash
docker exec cobranca_app sh -c 'cat > /usr/local/etc/php-fpm.d/www.conf << '\''EOF'\''
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000
listen.owner = www-data
listen.group = www-data
listen.mode = 0660
pm = dynamic
pm.max_children = 10
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
EOF'

# Reiniciar o PHP-FPM
docker exec cobranca_app killall php-fpm
docker exec cobranca_app php-fpm -D

# Aguardar 5 segundos
sleep 5

# Verificar novamente
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm.conf)
```

### Passo 5: Testar conexão do Nginx com o PHP-FPM
```bash
docker exec cobranca_nginx wget -O- http://cobranca_app:9000/health
```

**Resultado esperado:**
```
{"status":"ok","app":"cobranca-auto"}
```

### Passo 6: Testar o site
```bash
curl -i http://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se o Passo 5 falhar

Se a conexão do Nginx com o PHP-FPM falhar, verifique os logs:

```bash
# Verificar logs do Nginx
docker logs cobranca_nginx --tail 50

# Verificar logs do app
docker logs cobranca_app --tail 50
```

## 🎯 Resumo

1. Reiniciar PHP-FPM: `docker exec cobranca_app killall php-fpm && docker exec cobranca_app php-fpm -D`
2. Verificar se está escutando em IPv4: `docker exec cobranca_app netstat -tlnp | grep 9000`
3. Testar conexão do Nginx: `docker exec cobranca_nginx wget -O- http://cobranca_app:9000/health`
4. Testar site: `curl -i http://api.cobrancaauto.com.br/`

Execute os comandos acima em ordem e me envie os resultados!

# VERIFICAR LOGS DE ERRO

## 🚨 PROBLEMA

O site ainda está retornando 502 Bad Gateway.

## ✅ VERIFICAÇÃO

Execute estes comandos:

```bash
# 1. Verificar logs de erro do Nginx
tail -50 /var/log/nginx/cobranca-api-error.log
```

```bash
# 2. Verificar logs de acesso do Nginx
tail -50 /var/log/nginx/cobranca-api-access.log
```

```bash
# 3. Verificar logs do container app
docker logs cobranca_app | tail -50
```

```bash
# 4. Verificar logs do container queue
docker logs cobranca_queue | tail -50
```

```bash
# 5. Verificar se o PHP-FPM está processando
docker exec cobranca_app ps aux | grep php-fpm
```

```bash
# 6. Testar conexão direta com o PHP-FPM
docker exec cobranca_app wget -O- http://127.0.0.1:9000/index.php 2>&1
```

```bash
# 7. Verificar se há erros no storage
docker exec cobranca_app ls -la /var/www/storage/logs/
```

---

## 🔧 SOLUÇÃO 1: REINICIAR PHP-FPM

Se o PHP-FPM não estiver processando corretamente:

```bash
docker exec cobranca_app kill -USR2 1
```

Ou reiniciar o container:

```bash
docker restart cobranca_app
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR CONFIGURAÇÃO DO PHP-FPM

Se a configuração do PHP-FPM estiver incorreta:

```bash
docker exec cobranca_app cat /usr/local/etc/php-fpm.d/www.conf
```

Deveria mostrar algo como:
```
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000

pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE O LARAVEL ESTÁ RODANDO

Se o Laravel não estiver rodando:

```bash
docker exec cobranca_app php artisan tinker --execute="echo 'Laravel OK';"
```

---

## 📝 RESUMO

### O que verificar:

1. Logs de erro do Nginx
2. Logs de acesso do Nginx
3. Logs do container app
4. Logs do container queue
5. Se o PHP-FPM está processando
6. Testar conexão direta com o PHP-FPM
7. Se há erros no storage

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar logs de erro do Nginx
tail -50 /var/log/nginx/cobranca-api-error.log

# 2. Verificar logs de acesso do Nginx
tail -50 /var/log/nginx/cobranca-api-access.log

# 3. Verificar logs do container app
docker logs cobranca_app | tail -50

# 4. Verificar logs do container queue
docker logs cobranca_queue | tail -50

# 5. Verificar se o PHP-FPM está processando
docker exec cobranca_app ps aux | grep php-fpm

# 6. Testar conexão direta com o PHP-FPM
docker exec cobranca_app wget -O- http://127.0.0.1:9000/index.php 2>&1

# 7. Verificar se há erros no storage
docker exec cobranca_app ls -la /var/www/storage/logs/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

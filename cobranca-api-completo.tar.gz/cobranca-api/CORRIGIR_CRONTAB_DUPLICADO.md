# 🔧 CORRIGIR DUPLICIDADE NO CRONTAB

## 📋 PROBLEMA IDENTIFICADO

Há **DOIS** backups configurados para as 2:00 AM no crontab:

```bash
# Backup 1 (existente)
0 2 * * * cd /root/backups/cobranca && ./backup-producao.sh >> /root/backups/backup.log 2>&1

# Backup 2 (novo)
0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql
```

## 🔧 SOLUÇÃO

### Opção 1: Manter apenas o backup existente (RECOMENDADO)

```bash
# Remover o backup duplicado do crontab
crontab -l | grep -v "mysqldump -u root cobranca" | crontab -

# Verificar crontab
crontab -l
```

### Opção 2: Manter ambos com horários diferentes

```bash
# Editar crontab
crontab -e

# Mudar horário do segundo backup para 3:00 AM
# De:
0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Para:
0 3 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql
```

### Opção 3: Combinar os backups

```bash
# Editar crontab
crontab -e

# Combinar os backups em uma linha
# De:
0 2 * * * cd /root/backups/cobranca && ./backup-producao.sh >> /root/backups/backup.log 2>&1
0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Para:
0 2 * * * cd /root/backups/cobranca && ./backup-producao.sh >> /root/backups/backup.log 2>&1 && mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql
```

## ✅ VERIFICAÇÃO

### Verificar crontab

```bash
# Verificar crontab
crontab -l

# Verificar se há duplicidade
crontab -l | grep "0 2"
```

### Testar backup manual

```bash
# Testar backup existente
cd /root/backups/cobranca && ./backup-producao.sh

# Verificar backup
ls -lh /root/backups/cobranca/

# Testar backup novo
mysqldump -u root cobranca > /backup/test.sql

# Verificar backup
ls -lh /backup/
```

## 📋 COMANDO PARA CORRIGIR (RECOMENDADO)

```bash
# Remover backup duplicado
crontab -l | grep -v "mysqldump -u root cobranca" | crontab -

# Verificar crontab
crontab -l

# Testar backup existente
cd /root/backups/cobranca && ./backup-producao.sh

# Verificar backup
ls -lh /root/backups/cobranca/
```

## 📋 COMANDO PARA CORRIGIR (OPÇÃO 2)

```bash
# Editar crontab
crontab -e

# Mudar horário do segundo backup para 3:00 AM
# De:
0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Para:
0 3 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Salvar e sair

# Verificar crontab
crontab -l
```

## 📋 COMANDO PARA CORRIGIR (OPÇÃO 3)

```bash
# Editar crontab
crontab -e

# Combinar os backups em uma linha
# De:
0 2 * * * cd /root/backups/cobranca && ./backup-producao.sh >> /root/backups/backup.log 2>&1
0 2 * * * mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Para:
0 2 * * * cd /root/backups/cobranca && ./backup-producao.sh >> /root/backups/backup.log 2>&1 && mysqldump -u root cobranca > /backup/cobranca-$(date +\%Y\%m\%d).sql

# Salvar e sair

# Verificar crontab
crontab -l
```

## ✅ CHECKLIST FINAL

- [ ] Crontab sem duplicidade
- [ ] Backup existente funcionando
- [ ] Backup novo funcionando (se aplicável)
- [ ] Logs de backup sendo gerados
- [ ] Backups sendo criados no diretório correto

## 🚀 PRÓXIMOS PASSOS

1. **Corrigir duplicidade no crontab**
2. **Testar backup manual**
3. **Verificar logs de backup**
4. **Agendar verificação diária de backups**

## 💚 SUCESSO FINAL

**✅ Crontab sem duplicidade**
**✅ Backups funcionando corretamente**
**✅ Sistema de backup otimizado**

**Crontab otimizado = Backups confiáveis = 💸**

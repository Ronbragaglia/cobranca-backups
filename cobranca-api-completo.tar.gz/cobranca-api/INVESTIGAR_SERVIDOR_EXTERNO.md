# 🔥 INVESTIGAR SERVIDOR EXTERNO FAZENDO REDIRECT

## 📋 PROBLEMA IDENTIFICADO

- NGINX está configurado corretamente (SEM redirect)
- `grep -r "return 3" /etc/nginx/` - Nada encontrado
- Mas ainda está recebendo **308 Permanent Redirect**!

**Isso significa que HÁ OUTRO SERVIDOR WEB ou PROXY na frente do NGINX!**

---

## ⚡ INVESTIGAÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos para encontrar o culpado:

```bash
# Passo 1: Verificar se há outro servidor web rodando
netstat -tlnp | grep -E ":(80|443)"

# Passo 2: Verificar todos os processos de servidor web
ps aux | grep -E "(nginx|apache|caddy|traefik|haproxy)" | grep -v grep

# Passo 3: Verificar se há Docker containers rodando
docker ps
docker ps -a | grep -E "(nginx|apache|caddy|traefik|proxy|80|443)"

# Passo 4: Verificar se há Caddy rodando
systemctl status caddy 2>/dev/null
ps aux | grep caddy | grep -v grep

# Passo 5: Verificar se há Apache rodando
systemctl status apache2 2>/dev/null
ps aux | grep apache | grep -v grep

# Passo 6: Verificar se há Traefik rodando
systemctl status traefik 2>/dev/null
ps aux | grep traefik | grep -v grep

# Passo 7: Verificar se há HAProxy rodando
systemctl status haproxy 2>/dev/null
ps aux | grep haproxy | grep -v grep

# Passo 8: Verificar portas 8080, 8081, 8082 (você tem regras UFW para elas!)
netstat -tlnp | grep -E ":(8080|8081|8082)"

# Passo 9: Verificar qual processo está escutando na porta 80
lsof -i :80 2>/dev/null || ss -tlnp | grep :80

# Passo 10: Verificar qual processo está escutando na porta 443
lsof -i :443 2>/dev/null || ss -tlnp | grep :443
```

---

## 🎯 CENÁRIOS MAIS PROVÁVEIS

### Cenário 1: Há Docker Container Proxy

```bash
# Verificar containers
docker ps

# Se encontrar, parar
docker stop <container_name>
docker rm <container_name>

# Reiniciar NGINX
systemctl restart nginx

# Testar
curl -I http://api.cobrancaauto.com.br/
```

### Cenário 2: Há Caddy Rodando

```bash
# Parar Caddy
systemctl stop caddy
systemctl disable caddy

# Reiniciar NGINX
systemctl restart nginx

# Testar
curl -I http://api.cobrancaauto.com.br/
```

### Cenário 3: Há Apache Rodando

```bash
# Parar Apache
systemctl stop apache2
systemctl disable apache2

# Reiniciar NGINX
systemctl restart nginx

# Testar
curl -I http://api.cobrancaauto.com.br/
```

### Cenário 4: Há Traefik Rodando

```bash
# Parar Traefik
systemctl stop traefik
systemctl disable traefik

# Reiniciar NGINX
systemctl restart nginx

# Testar
curl -I http://api.cobrancaauto.com.br/
```

### Cenário 5: Há Proxy na Porta 8081/8082

```bash
# Verificar o que está rodando nessas portas
netstat -tlnp | grep -E ":(8081|8082)"

# Se encontrar, parar o serviço
# Depois testar
curl -I http://api.cobrancaauto.com.br/
```

---

## 🚀 SOLUÇÃO RADICAL (PARAR TUDO EXCETO NGINX)

```bash
# Passo 1: Parar todos os servidores web conhecidos
systemctl stop apache2 2>/dev/null
systemctl stop caddy 2>/dev/null
systemctl stop traefik 2>/dev/null
systemctl stop haproxy 2>/dev/null

# Passo 2: Parar todos os Docker containers
docker stop $(docker ps -q) 2>/dev/null

# Passo 3: Matar processos zumbis
pkill -9 apache
pkill -9 caddy
pkill -9 traefik
pkill -9 haproxy

# Passo 4: Reiniciar NGINX
systemctl restart nginx

# Passo 5: Verificar o que está escutando
netstat -tlnp | grep -E ":(80|443)"

# Passo 6: Testar
curl -I http://api.cobrancaauto.com.br/
```

---

## 📊 VERIFICAR QUAL SERVIÇO ESTÁ RESPONDENDO

```bash
# Testar porta 80
telnet localhost 80
# OU
nc -zv localhost 80

# Testar porta 443
telnet localhost 443
# OU
nc -zv localhost 443

# Verificar banner do servidor
curl -I http://localhost/ 2>&1 | grep -i server
```

---

## 🔍 VERIFICAR CLOUDFLARE

Se nada funcionar, pode ser o Cloudflare fazendo o redirect:

```bash
# Acesse: https://dash.cloudflare.com/
# Vá em: DNS > api.cobrancaauto.com.br
# Verifique: Proxy Status = DNS only (nuvem cinza)
# Se estiver Proxied (nuvem laranja), mude para DNS only
```

---

## ✅ APÓS ENCONTRAR E PARAR O SERVIÇO

```bash
# Testar
curl -I http://api.cobrancaauto.com.br/

# Deve retornar: HTTP/1.1 200 OK (não 308!)

# Testar no navegador
http://api.cobrancaauto.com.br
```

---

## 💚 SUCESSO!

Quando encontrar e parar o serviço fazendo o redirect, o site voltará a funcionar!

**Execute os comandos de investigação para encontrar o culpado!**

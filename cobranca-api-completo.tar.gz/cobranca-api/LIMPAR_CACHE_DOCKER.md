# LIMPAR CACHE DOCKER E FORÇAR RELEITURA DO .ENV

## 🚨 PROBLEMA

O Docker está usando uma versão em cache do arquivo `.env` e não está lendo as variáveis `MYSQL_ROOT_PASSWORD` e `MYSQL_ALLOW_EMPTY_PASSWORD` que foram adicionadas.

## ✅ SOLUÇÃO

Execute estes comandos na VPS, em ordem:

---

## PASSO 1: Parar containers

```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml down
```

---

## PASSO 2: Limpar cache do Docker

```bash
# Remover cache do Docker
docker system prune -a

# Parar containers Docker (para limpar cache)
docker stop $(docker ps -aq)

# Iniciar Docker novamente
docker start
```

---

## PASSO 3: Verificar arquivo .env

```bash
cat .env | grep -E "(MYSQL_ROOT_PASSWORD|MYSQL_ALLOW_EMPTY_PASSWORD)"
```

**Deveria mostrar:**
```
MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

**Se NÃO mostrar:** Execute o PASSO 4 abaixo.

---

## PASSO 4: Adicionar variáveis manualmente (se necessário)

Se as variáveis não aparecerem no arquivo, adicione manualmente:

```bash
nano .env
```

**Adicionar ao final do arquivo:**
```env
MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

**Salvar e sair:** Ctrl+O, Enter, Ctrl+X

---

## PASSO 5: Subir containers

```bash
docker-compose -f docker-compose.prod.yml up -d
```

---

## PASSO 6: Aguardar 30 segundos

```bash
sleep 30
```

---

## PASSO 7: Verificar status dos containers

```bash
docker-compose -f docker-compose.prod.yml ps
```

**Deveria mostrar:**
```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

---

## PASSO 8: Verificar logs do MySQL

```bash
docker-compose -f docker-compose.prod.yml logs mysql | tail -30
```

**Deveria mostrar algo como:**
```
[Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
[Note] [Entrypoint]: Switching to dedicated user 'mysql'
[Note] [Entrypoint]: ready for connections
```

---

## PASSO 9: Verificar se a porta 9000 está exposta

```bash
netstat -tlnp | grep 9000
```

**Deveria mostrar:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

---

## PASSO 10: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

**Deveria retornar:** `{"status":"ok"}` ou similar

---

## PASSO 11: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

**Deveria retornar:** HTML ou JSON (não 502)

---

## 🔍 SE AINDA DER ERRO 502

### Verificar logs do Nginx (no servidor)

```bash
tail -100 /var/log/nginx/cobranca-api-error.log
```

### Verificar logs do Nginx (no container)

```bash
docker-compose -f docker-compose.prod.yml logs nginx-laravel | tail -100
```

---

## 📝 RESUMO

### Arquivos atualizados:

1. [`.env`](.env:1) - Variáveis MySQL adicionadas

### Comandos para executar:

1. Limpar cache do Docker
2. Verificar arquivo .env
3. Adicionar variáveis manualmente (se necessário)
4. Subir containers
5. Verificar status
6. Verificar logs
7. Testar health check e site

---

## 🚀 RESULTADO ESPERADO

Após executar os passos acima:

1. ✅ Cache do Docker limpo
2. ✅ Variáveis MySQL definidas
3. ✅ MySQL parou de reiniciar
4. ✅ Todos os containers rodando
5. ✅ Porta 9000 exposta
6. ✅ Health check funcionando
7. ✅ Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔥 FIX - REDIRECT 308 E CONFIGURAÇÃO DUPLICADA

## 📋 PROBLEMA IDENTIFICADO

1. **`conflicting server name "api.cobrancaauto.com.br"`** - Há múltiplas configurações do mesmo domínio
2. **`HTTP/1.1 308 Permanent Redirect`** - Está redirecionando HTTP para HTTPS
3. **Access log mostra HTTP 200 antes** - O site estava funcionando!

---

## ⚡ SOLUÇÃO RÁPIDA (2 MINUTOS)

Execute estes comandos na VPS:

```bash
# Passo 1: Verificar configurações duplicadas
ls -la /etc/nginx/sites-enabled/
ls -la /etc/nginx/sites-available/

# Passo 2: Remover configurações duplicadas
# Se houver múltiplos arquivos com "api.cobrancaauto.com.br", remova os extras
rm /etc/nginx/sites-enabled/default 2>/dev/null

# Passo 3: Verificar qual arquivo está ativo
cat /etc/nginx/sites-enabled/cobranca-api

# Passo 4: Criar configuração SEM redirect HTTPS
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# Passo 5: Garantir link simbólico correto
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Passo 6: Testar configuração
nginx -t

# Passo 7: Reiniciar NGINX
systemctl restart nginx

# Passo 8: Testar
curl -I http://api.cobrancaauto.com.br/
curl -I http://76.13.167.54/
```

---

## 🔧 DIAGNÓSTICO DETALHADO

### Passo 1: Listar todas as configurações

```bash
# Verificar sites-available
ls -la /etc/nginx/sites-available/

# Verificar sites-enabled
ls -la /etc/nginx/sites-enabled/

# Verificar conteúdo de cada arquivo
for file in /etc/nginx/sites-enabled/*; do
    echo "=== $file ==="
    cat "$file" | grep -E "server_name|listen"
done
```

### Passo 2: Identificar duplicatas

```bash
# Procurar por "api.cobrancaauto.com.br" em todas as configs
grep -r "api.cobrancaauto.com.br" /etc/nginx/sites-*/ 2>/dev/null
```

### Passo 3: Remover duplicatas

```bash
# Se houver múltiplos arquivos, mantenha apenas um
rm /etc/nginx/sites-enabled/default 2>/dev/null
rm /etc/nginx/sites-available/default 2>/dev/null

# Se houver outros arquivos com o mesmo server_name, remova-os
# Mas mantenha o cobranca-api
```

### Passo 4: Criar configuração limpa

```bash
# Backup
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Criar nova configuração
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF
```

### Passo 5: Garantir link simbólico

```bash
# Remover link antigo se existir
rm /etc/nginx/sites-enabled/cobranca-api 2>/dev/null

# Criar novo link
ln -s /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Verificar
ls -la /etc/nginx/sites-enabled/
```

### Passo 6: Testar e reiniciar

```bash
# Testar configuração
nginx -t

# Se der erro, verifique o que está errado
cat /etc/nginx/sites-available/cobranca-api

# Reiniciar
systemctl restart nginx
systemctl status nginx
```

### Passo 7: Testar acesso

```bash
# Testar HTTP
curl -I http://api.cobrancaauto.com.br/

# Deve retornar: HTTP/1.1 200 OK

# Testar IP direto
curl -I http://76.13.167.54/

# Deve retornar: HTTP/1.1 200 OK
```

---

## 🎯 SOBRE O REDIRECT 308

O código 308 significa "Permanent Redirect". Isso acontece quando:

1. **Há uma configuração SSL/HTTPS** que redireciona HTTP para HTTPS
2. **Mas o certificado SSL pode não estar configurado corretamente**

### Opção A: Remover redirect (Recomendado agora)

Use a configuração acima que não tem redirect.

### Opção B: Configurar HTTPS corretamente

Se você quer HTTPS, precisa:

```bash
# Instalar certbot
apt update
apt install certbot python3-certbot-nginx -y

# Obter certificado
certbot --nginx -d api.cobrancaauto.com.br

# Isso vai configurar automaticamente o redirect HTTP -> HTTPS
```

---

## 📊 VERIFICAÇÃO FINAL

Após aplicar a solução:

```bash
# 1. Verificar logs não tem mais "conflicting server name"
tail -f /var/log/nginx/error.log

# 2. Testar HTTP
curl -I http://api.cobrancaauto.com.br/

# Deve retornar: HTTP/1.1 200 OK (não 308!)

# 3. Testar no navegador
http://api.cobrancaauto.com.br

# 4. Verificar access log
tail -f /var/log/nginx/access.log
```

---

## ✅ SUCESSO!

Quando funcionar, você verá:
- `curl -I http://api.cobrancaauto.com.br/` retorna `HTTP/1.1 200 OK`
- Site carregando no navegador
- Sem erros "conflicting server name"
- Sem redirect 308

**Site funcionando = Cliente feliz = 💸**

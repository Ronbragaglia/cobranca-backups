# 🔧 CORRIGIR DUPLICIDADE DO LIMIT_REQ_ZONE NO NGINX

## 📋 PROBLEMA IDENTIFICADO

Há **MÚLTIPLAS** linhas de `limit_req_zone` no arquivo NGINX:

```bash
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
                limit_req zone=api burst=20 nodelay;
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
}limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
```

**Erro:** `nginx: [emerg] limit_req_zone "api" is already bound to key "$binary_remote_addr"`

## 🔧 SOLUÇÃO

### Opção 1: Executar script de correção (RECOMENDADO)

```bash
# Baixar e executar script
cd /tmp
wget https://github.com/seu-repo/cobranca-api/raw/main/scripts/corrigir-limit-req-duplicado.sh
chmod +x corrigir-limit-req-duplicado.sh
./corrigir-limit-req-duplicado.sh
```

### Opção 2: Executar comandos manualmente

```bash
# Passo 1: Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Remover todas as linhas de limit_req_zone
sed -i '/limit_req_zone/d' /etc/nginx/sites-available/cobranca-api

# Passo 3: Adicionar limit_req_zone na posição correta
sed -i '/^server {/i limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;' /etc/nginx/sites-available/cobranca-api

# Passo 4: Testar configuração
nginx -t

# Passo 5: Recarregar NGINX
systemctl reload nginx

# Passo 6: Verificar configuração
grep "limit_req" /etc/nginx/sites-available/cobranca-api
```

### Opção 3: Editar arquivo manualmente

```bash
# Passo 1: Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Editar arquivo
nano /etc/nginx/sites-available/cobranca-api

# Passo 3: Remover todas as linhas de limit_req_zone
# Deixe apenas uma linha antes do bloco server:
# limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

# Passo 4: Salvar e sair (Ctrl+O, Enter, Ctrl+X)

# Passo 5: Testar configuração
nginx -t

# Passo 6: Recarregar NGINX
systemctl reload nginx
```

## ✅ VERIFICAÇÃO

### Verificar configuração NGINX

```bash
# Verificar configuração NGINX
nginx -t

# Verificar limit_req_zone
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Verificar status NGINX
systemctl status nginx

# Testar HTTPS
curl -I https://api.cobrancaauto.com.br
```

### Resultado esperado

```bash
# nginx -t
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful

# grep "limit_req" /etc/nginx/sites-available/cobranca-api
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
                limit_req zone=api burst=20 nodelay;

# curl -I https://api.cobrancaauto.com.br
HTTP/1.1 200 OK
Server: nginx/1.18.0 (Ubuntu)
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Cache-Control: no-cache, private
Date: Tue, 03 Feb 2026 17:18:19 GMT
```

## 📋 COMANDOS PARA CORRIGIR (COPIAR E COLAR)

```bash
# Backup da configuração atual
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup.$(date +%Y%m%d_%H%M%S)

# Remover todas as linhas de limit_req_zone
sed -i '/limit_req_zone/d' /etc/nginx/sites-available/cobranca-api

# Adicionar limit_req_zone na posição correta
sed -i '/^server {/i limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;' /etc/nginx/sites-available/cobranca-api

# Testar configuração
nginx -t

# Recarregar NGINX
systemctl reload nginx

# Verificar configuração
grep "limit_req" /etc/nginx/sites-available/cobranca-api

# Testar HTTPS
curl -I https://api.cobrancaauto.com.br
```

## ✅ CHECKLIST FINAL

- [ ] Backup da configuração criado
- [ ] Todas as linhas de limit_req_zone removidas
- [ ] limit_req_zone adicionado na posição correta
- [ ] Configuração NGINX testada com sucesso
- [ ] NGINX recarregado
- [ ] Site acessível via HTTPS
- [ ] Rate limiting funcionando

## 🚀 PRÓXIMOS PASSOS

1. **Corrigir duplicidade do limit_req_zone** - Executar comandos acima
2. **Testar rate limiting** - Simular ataque com múltiplas requisições
3. **Monitorar logs** - `tail -f /var/log/nginx/error.log`
4. **Verificar backups** - Confirmar que backups estão sendo criados

## 💚 SUCESSO FINAL

**✅ limit_req_zone configurado corretamente**
**✅ NGINX testado e recarregado**
**✅ Site acessível via HTTPS**
**✅ Rate limiting funcionando**

**NGINX configurado corretamente = Site seguro = 💸**

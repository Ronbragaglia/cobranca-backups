# 🔥 FIX URGENTE 502 BAD GATEWAY - EXECUTAR AGORA!

## 🚨 SITUAÇÃO CRÍTICA
- Site: api.cobrancaauto.com.br
- Erro: 502 Bad Gateway
- Problema: NGINX não está processando PHP
- Acesso: SSH root@76.13.167.54

---

## ⚡ SOLUÇÃO RÁPIDA (2 minutos)

### Passo 1: Baixar o script na VPS
```bash
ssh root@76.13.167.54
cd /root
wget https://raw.githubusercontent.com/seu-repo/cobranca-api/main/scripts/fix-502-nginx-php-urgente.sh
chmod +x fix-502-nginx-php-urgente.sh
```

### Passo 2: Executar o script
```bash
./fix-502-nginx-php-urgente.sh
```

### Passo 3: Testar o site
```bash
# Teste no navegador
http://api.cobrancaauto.com.br

# Teste via curl na VPS
curl -I http://localhost/
```

---

## 📋 O QUE O SCRIPT FAZ

1. **Diagnóstico Completo**
   - Verifica status PHP-FPM
   - Verifica status NGINX
   - Verifica socket PHP-FPM
   - Verifica versão PHP

2. **Análise de Configuração**
   - Mostra configuração atual NGINX
   - Testa sintaxe NGINX
   - Verifica logs de erro

3. **Verificação de Permissões**
   - Permissões do diretório Laravel
   - Permissões do socket PHP-FPM
   - Usuário NGINX vs PHP-FPM

4. **Correção Automática**
   - Backup da configuração atual
   - Cria configuração NGINX correta
   - Corrige permissões
   - Reinicia serviços

5. **Testes de Validação**
   - Cria arquivo de teste PHP
   - Testa via curl local
   - Testa comunicação NGINX-PHP-FPM

---

## 🔧 SE O SCRIPT NÃO FUNCIONAR

### Diagnóstico Manual Rápido

```bash
# 1. Verificar PHP-FPM
systemctl status php8.2-fpm

# 2. Verificar NGINX
systemctl status nginx

# 3. Verificar socket
ls -la /var/run/php/php8.2-fpm.sock

# 4. Verificar logs
tail -20 /var/log/nginx/error.log
tail -20 /var/log/php8.2-fpm.log

# 5. Testar configuração NGINX
nginx -t
```

### Correção Manual

```bash
# 1. Editar configuração NGINX
nano /etc/nginx/sites-available/cobranca-api

# 2. Garantir que tenha esta configuração:
location ~ \.php$ {
    include snippets/fastcgi-php.conf;
    fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}

# 3. Testar e reiniciar
nginx -t
systemctl restart php8.2-fpm
systemctl restart nginx
```

---

## 🎯 CAUSAS MAIS COMUNS DO 502

### 1. Socket PHP-FPM não existe
```bash
# Solução
systemctl restart php8.2-fpm
```

### 2. Permissões incorretas no socket
```bash
# Solução
chmod 666 /var/run/php/php8.2-fpm.sock
systemctl restart php8.2-fpm
```

### 3. Usuário NGINX diferente do PHP-FPM
```bash
# Verificar
grep user /etc/nginx/nginx.conf
grep -E "^(user|group)" /etc/php/8.2/fpm/pool.d/www.conf

# Ambos devem ser www-data
```

### 4. Configuração NGINX errada
```bash
# Verificar se fastcgi_pass está correto
cat /etc/nginx/sites-available/cobranca-api | grep fastcgi_pass
```

---

## 📞 MONITORAMENTO

### Verificar logs em tempo real
```bash
# Terminal 1: NGINX
tail -f /var/log/nginx/error.log

# Terminal 2: PHP-FPM
tail -f /var/log/php8.2-fpm.log
```

### Verificar tráfego
```bash
# Verificar conexões
netstat -an | grep :80

# Verificar processos PHP
ps aux | grep php-fpm
```

---

## ✅ SUCESSO

Quando funcionar, você verá:
- Site carregando no navegador
- Resposta HTTP 200 OK
- Arquivo test-php.php mostrando phpinfo()
- Sem erros nos logs

### Limpar arquivo de teste
```bash
rm /var/www/cobranca-api/public/test-php.php
```

---

## 🚨 EMERGÊNCIA

Se nada funcionar, tente:
```bash
# Reiniciar tudo
systemctl restart php8.2-fpm
systemctl restart nginx
systemctl restart mysql

# Verificar se há processos bloqueados
ps aux | grep -E "(nginx|php|mysql)"

# Matar processos zumbis
pkill -9 php-fpm
pkill -9 nginx
systemctl start php8.2-fpm
systemctl start nginx
```

---

## 📞 SUPORTE

Se ainda tiver problemas, colete estas informações:
```bash
# Diagnóstico completo
./fix-502-nginx-php-urgente.sh > diagnostico.txt 2>&1
cat diagnostico.txt
```

---

**💚 BOA SORTE! O SITE VOLTARÁ A FUNCIONAR!**

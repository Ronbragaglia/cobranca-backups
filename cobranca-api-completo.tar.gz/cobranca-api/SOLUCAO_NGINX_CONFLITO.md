# 🔧 SOLUÇÃO - CONFLITO DE PORTA 80

## 📋 Problema Identificado

O Nginx do sistema está falhando porque a porta 80 já está sendo usada pelo container `cobranca_nginx`:

```
nginx: [emerg] bind() to 0.0.0.0:80 failed (98: Unknown error)
```

Erro 98 = "Address already in use" (porta já está em uso)

## 📋 Situação Atual

Temos dois Nginx rodando:
1. ❌ Nginx do sistema (`nginx.service`) - Falhando (porta 80 em uso)
2. ✅ Nginx do container Docker (`cobranca_nginx`) - Funcionando (porta 80 mapeada)

## 🚀 Solução: Parar o Nginx do sistema e usar apenas o do container

### Passo 1: Parar o Nginx do sistema
```bash
systemctl stop nginx
systemctl disable nginx
```

### Passo 2: Verificar se o Nginx do sistema parou
```bash
systemctl status nginx
```

**Resultado esperado:**
```
× nginx.service - A high performance web server and a reverse proxy server
     Loaded: loaded (/lib/systemd/system/nginx.service; disabled; vendor preset: enabled)
     Active: inactive (dead)
```

### Passo 3: Verificar se o container `cobranca_nginx` está rodando
```bash
docker ps | grep nginx
```

**Resultado esperado:**
```
42d6d188f923   nginx:alpine       "/docker-entrypoint.…"   ...              Up ...             0.0.0.0:80->80/tcp, [::]:80->80/tcp   cobranca_nginx
```

### Passo 4: Verificar se a porta 80 está livre
```bash
netstat -tlnp | grep :80
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN      .../docker-proxy
```

### Passo 5: Testar o site
```bash
curl -I http://localhost
curl -I http://localhost/index.php
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Solução Alternativa: Parar o container e usar o Nginx do sistema

Se você preferir usar o Nginx do sistema ao invés do container:

### Passo 1: Parar o container `cobranca_nginx`
```bash
docker stop cobranca_nginx
docker rm cobranca_nginx
```

### Passo 2: Iniciar o Nginx do sistema
```bash
systemctl start nginx
systemctl enable nginx
```

### Passo 3: Verificar se o Nginx do sistema está rodando
```bash
systemctl status nginx
netstat -tlnp | grep :80
```

### Passo 4: Testar o site
```bash
curl -I http://localhost
curl -I https://api.cobrancaauto.com.br/
```

## 🎯 Recomendação

**Recomendo usar a Solução 1** (parar o Nginx do sistema e usar apenas o do container) porque:

1. O container `cobranca_nginx` já está configurado corretamente
2. Ele já está funcionando e processando requisições
3. É mais fácil gerenciar com Docker Compose
4. Mantém a consistência com o resto da aplicação

Execute os comandos acima na VPS e me envie os resultados!

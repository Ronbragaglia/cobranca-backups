# DIAGNÓSTICO DO CONTAINER APP

## 🚨 PROBLEMA

Container `cobranca_app` está marcado como "unhealthy" e não inicia.

## 🔍 PASSOS PARA DIAGNÓSTICO

Execute estes comandos na VPS para identificar o problema:

### 1. Verificar logs do container app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -200
```

**Procure por:**
- Erros de conexão com MySQL
- Erros de conexão com Redis
- Erros de PHP-FPM
- Erros de inicialização do Laravel

### 2. Verificar logs do container mysql

```bash
docker-compose -f docker-compose.prod.yml logs mysql | tail -100
```

**Procure por:**
- Erros de inicialização
- Erros de permissão
- Erros de conexão

### 3. Verificar logs do container redis

```bash
docker-compose -f docker-compose.prod.yml logs redis | tail -50
```

**Procure por:**
- Erros de autenticação
- Erros de conexão

### 4. Verificar se o .env está correto

```bash
cat .env | grep -E "(DB_PASSWORD|REDIS_PASSWORD|APP_KEY)"
```

**Verifique se:**
- DB_PASSWORD está definida
- REDIS_PASSWORD está definida
- APP_KEY está definida

### 5. Verificar se os volumes existem

```bash
ls -la storage/
```

**Verifique se:**
- O diretório storage existe
- Tem permissões corretas

### 6. Tentar iniciar o container app manualmente

```bash
docker-compose -f docker-compose.prod.yml up app
```

### 7. Verificar logs em tempo real

```bash
docker-compose -f docker-compose.prod.yml logs -f app
```

---

## 📝 POSSÍVEIS CAUSAS

### 1. MySQL não está iniciando corretamente

Se o mysql está reiniciando (Restarting), o app não consegue conectar.

**Solução:**
```bash
# Verificar logs do mysql
docker-compose -f docker-compose.prod.yml logs mysql

# Se houver erro de permissão, corrigir
docker-compose -f docker-compose.prod.yml down -v
docker-compose -f docker-compose.prod.yml up -d mysql
```

### 2. Redis não está iniciando corretamente

Se o redis não estiver healthy, o app não consegue conectar.

**Solução:**
```bash
# Verificar logs do redis
docker-compose -f docker-compose.prod.yml logs redis

# Se houver erro de senha, corrigir no .env
nano .env
```

### 3. Porta 9000 não está sendo exposta

Se a porta 9000 não estiver exposta, o Nginx não consegue conectar.

**Solução:**
```bash
# Verificar se a porta está exposta
netstat -tlnp | grep 9000

# Se não mostrar, verificar docker-compose.prod.yml
cat docker-compose.prod.yml | grep -A 3 "app:"
```

### 4. PHP-FPM não está iniciando

Se o PHP-FPM não estiver rodando, o app não responde.

**Solução:**
```bash
# Verificar logs do app
docker-compose -f docker-compose.prod.yml logs app | grep fpm

# Se não mostrar "fpm is running", há problema de inicialização
```

---

## 🚀 SOLUÇÃO RÁPIDA

Se tudo estiver falhando, tente esta solução alternativa:

### Usar Nginx do servidor em vez de Docker

1. **Parar containers Docker**
```bash
docker-compose -f docker-compose.prod.yml down
```

2. **Configurar Nginx do servidor para conectar ao PHP-FPM do container app**

Copiar o arquivo [`nginx-host.conf`](nginx-host.conf:1) para o servidor:

```bash
# No servidor
scp nginx-host.conf root@76.13.167.54:/tmp/
mv /tmp/nginx-host.conf /etc/nginx/sites-available/cobranca-api
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api
nginx -t
systemctl reload nginx
```

3. **Subir apenas os containers necessários (sem nginx-laravel)**

```bash
docker-compose -f docker-compose.prod.yml up -d mysql redis app queue scheduler backup
```

Isso vai:
- Usar o Nginx do servidor (que já está configurado)
- Conectar ao PHP-FPM do container app via porta 9000
- Evitar conflitos com o nginx-laravel

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

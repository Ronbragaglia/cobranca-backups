# 🔥 DIAGNÓSTICO FINAL COMPLETO - PROBLEMAS MÚLTIPLOS

## 📋 PROBLEMAS IDENTIFICADOS

### 1. Erro de Sintaxe PHP no Tinker
```
PHP Parse error: Syntax error, unexpected '}', expecting EOF on line 12
```
**Causa:** O bash interpretou os caracteres `$` no comando tinker

### 2. Conflicting Server Name no NGINX
```
[warn] conflicting server name "api.cobrancaauto.com.br" on 0.0.0.0:80, ignored
[warn] conflicting server name "api.cobrancaauto.com.br" on 0.0.0.0:443, ignored
```
**Causa:** Há múltiplas configurações NGINX para o mesmo domínio

### 3. Erro 419 Page Expired
**Causa:** Sessão do Laravel expirando ou problema com CSRF token

---

## ⚡ SOLUÇÃO COMPLETA (5 MINUTOS)

Execute estes comandos na VPS:

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Verificar se há múltiplas configurações NGINX
find /etc/nginx -name "*.conf" -type f -exec grep -l "api.cobrancaauto.com.br" {} \;

# Passo 3: Listar todos os arquivos de configuração
ls -la /etc/nginx/sites-available/
ls -la /etc/nginx/sites-enabled/

# Passo 4: Verificar configuração atual
cat /etc/nginx/sites-available/cobranca-api

# Passo 5: Verificar se há configuração duplicada
grep -r "server_name.*api.cobrancaauto.com.br" /etc/nginx/ 2>/dev/null

# Passo 6: Se houver duplicatas, remover
# Manter APENAS um arquivo em sites-enabled
ls -la /etc/nginx/sites-enabled/

# Deve ter APENAS: cobranca-api -> /etc/nginx/sites-available/cobranca-api

# Passo 7: Verificar usuários no banco de dados
php artisan tinker --execute="echo App\Models\User::all(['id', 'email', 'name', 'tenant_id'])->toJson(JSON_PRETTY_PRINT);"

# Passo 8: Se o usuário admin não existir, criar via arquivo PHP separado
cat > /tmp/criar_admin.php << 'PHPEOF'
<?php
require __DIR__ . '/vendor/autoload.php';
\$app = require_once __DIR__ . '/bootstrap/app.php';
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
\$tenant = Tenant::firstOrCreate(['subdomain' => 'principal'], ['name' => 'Principal', 'subscription_status' => 'active']);
\$user = User::updateOrCreate(['email' => 'admin@cobranca.com'], ['name' => 'Admin', 'password' => Hash::make('123456'), 'email_verified_at' => now(), 'tenant_id' => \$tenant->id]);
echo "Usuário criado/atualizado com sucesso!\n";
echo "Email: admin@cobranca.com\n";
echo "Senha: 123456\n";
echo "Tenant ID: " . \$user->tenant_id . "\n";
PHPEOF
php /tmp/criar_admin.php

# Passo 9: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 10: Limpar sessões
rm -rf storage/framework/sessions/*
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions
chown -R www-data:www-data storage/framework/sessions

# Passo 11: Corrigir permissões do storage
chmod -R 775 storage/
chown -R www-data:www-data storage/

# Passo 12: Reiniciar PHP-FPM
systemctl restart php8.2-fpm

# Passo 13: Reiniciar NGINX
systemctl restart nginx

# Passo 14: Verificar status dos serviços
systemctl status php8.2-fpm
systemctl status nginx

# Passo 15: Testar localmente
curl -I http://localhost/
curl -I http://localhost/login
```

---

## 🔧 SOLUÇÃO ALTERNATIVA - USAR USUÁRIO DEMO

Se o usuário admin não funcionar, tente o usuário demo:

```bash
# Acessar diretório
cd /var/www/cobranca-api

# Criar/atualizar usuário demo
cat > /tmp/criar_demo.php << 'PHPEOF'
<?php
require __DIR__ . '/vendor/autoload.php';
\$app = require_once __DIR__ . '/bootstrap/app.php';
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
\$tenant = Tenant::firstOrCreate(['subdomain' => 'demo'], ['name' => 'Demo', 'subscription_status' => 'active']);
\$user = User::updateOrCreate(['email' => 'demo@seucrm.com'], ['name' => 'Admin Demo', 'password' => Hash::make('password'), 'email_verified_at' => now(), 'tenant_id' => \$tenant->id]);
echo "Usuário demo criado/atualizado!\n";
echo "Email: demo@seucrm.com\n";
echo "Senha: password\n";
echo "Tenant ID: " . \$user->tenant_id . "\n";
PHPEOF
php /tmp/criar_demo.php

# Limpar cache
php artisan config:clear
php artisan cache:clear

# Limpar sessões
rm -rf storage/framework/sessions/*
```

**Acesse com:**
- **Email:** demo@seucrm.com
- **Senha:** password

---

## 🚨 SOLUÇÃO RADICAL - REDEFINIR TUDO

Se nada funcionar, redefina tudo:

```bash
# Passo 1: Acessar diretório
cd /var/www/cobranca-api

# Passo 2: Backup do .env
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

# Passo 3: Limpar banco e rodar seeders
php artisan migrate:fresh --seed

# Passo 4: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 5: Limpar sessões
rm -rf storage/framework/sessions/*
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions

# Passo 6: Reiniciar serviços
systemctl restart php8.2-fpm
systemctl restart nginx
```

---

## 📊 VERIFICAÇÃO FINAL

Após executar os comandos:

```bash
# 1. Verificar usuários no banco
php artisan tinker --execute="echo App\Models\User::all(['id', 'email', 'name'])->toJson(JSON_PRETTY_PRINT);"

# 2. Verificar configuração NGINX
cat /etc/nginx/sites-available/cobranca-api

# 3. Testar site
curl -I http://api.cobrancaauto.com.br/

# 4. Testar login
curl -X POST http://api.cobrancaauto.com.br/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@cobranca.com","password":"123456"}'
```

---

## 💚 SUCESSO!

Após aplicar a solução:

1. **Tente fazer login com:**
   - Email: admin@cobranca.com
   - Senha: 123456

2. **Se não funcionar, tente o usuário demo:**
   - Email: demo@seucrm.com
   - Senha: password

3. **Se ainda não funcionar, use o usuário demo criado pelo migrate:fresh**

**Execute os comandos acima na VPS para resolver todos os problemas!**

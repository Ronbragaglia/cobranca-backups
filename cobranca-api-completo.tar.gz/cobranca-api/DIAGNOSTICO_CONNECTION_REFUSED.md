# DIAGNÓSTICO CONNECTION REFUSED

## 🚨 PROBLEMA

Agora está retornando "Connection refused" na porta 443, não 502 Bad Gateway. Isso significa que o Nginx não está conseguindo conectar ao PHP-FPM na porta 9000.

## ✅ DIAGNÓSTICO

Execute estes comandos:

```bash
# 1. Verificar se o PHP-FPM está escutando no container
docker exec cobranca_app netstat -tlnp | grep 9000
```

```bash
# 2. Verificar se o PHP-FPM está processando
docker exec cobranca_app ps aux | grep php-fpm
```

```bash
# 3. Testar conexão do host para o container
curl -I http://127.0.0.1:9000
```

```bash
# 4. Verificar se o firewall está bloqueando
ufw status
```

```bash
# 5. Verificar se há regras do iptables bloqueando
iptables -L -n | grep 9000
```

```bash
# 6. Verificar logs do Nginx
tail -20 /var/log/nginx/cobranca-api-error.log
```

```bash
# 7. Verificar arquivo de configuração do Nginx
cat /etc/nginx/sites-available/cobranca-api | grep -A 5 "location ~ \.php$"
```

```bash
# 8. Verificar se o arquivo de configuração foi atualizado
cat /etc/nginx/sites-available/cobranca-api | grep "9000"
```

---

## 🔧 SOLUÇÃO 1: VERIFICAR SE O PHP-FPM ESTÁ ESCUTANDO NO ENDEREÇO CORRETO

Se o PHP-FPM estiver escutando em `:::9000` (IPv6), altere para `0.0.0.0:9000`:

```bash
# Verificar se está escutando em IPv6
docker exec cobranca_app netstat -tlnp | grep 9000

# Se estiver em IPv6, alterar configuração do PHP-FPM
docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

# Reiniciar container
docker restart cobranca_app

# Testar novamente
curl -I http://127.0.0.1:9000
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR SE HÁ BLOQUEIO DO FIREWALL

Se houver regras do iptables bloqueando a porta 9000:

```bash
# Verificar regras
iptables -L -n | grep 9000

# Se houver, liberar
iptables -I INPUT -p tcp --dport 9000 -j ACCEPT
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE O NGINX ESTÁ CONFIGURADO CORRETAMENTE

Se o arquivo de configuração não tiver `fastcgi_pass 127.0.0.1:9000;`, adicione:

```bash
# Verificar se tem fastcgi_pass
cat /etc/nginx/sites-available/cobranca-api | grep fastcgi_pass

# Se não tiver, adicionar a configuração de PHP
cat >> /etc/nginx/sites-available/cobranca-api << 'EOF'

location ~ \.php$ {
    try_files $uri =404;
    fastcgi_split_path_info ^(.+\.php)(/.+)$;
    fastcgi_pass 127.0.0.1:9000;
    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_param PATH_INFO $fastcgi_path_info;
    fastcgi_read_timeout 300;
    fastcgi_send_timeout 300;
    fastcgi_connect_timeout 60;
    fastcgi_buffer_size 128k;
    fastcgi_buffers 256 16k;
    fastcgi_busy_buffers_size 256k;
}
EOF

# Testar configuração
nginx -t

# Recarregar Nginx
systemctl reload nginx
```

---

## 📝 RESUMO

### O que verificar:

1. Se o PHP-FPM está escutando no endereço correto
2. Se há bloqueio do firewall
3. Se o Nginx está configurado corretamente
4. Logs de erro do Nginx

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar se o PHP-FPM está escutando no endereço correto
docker exec cobranca_app netstat -tlnp | grep 9000

# 2. Verificar se o PHP-FPM está processando
docker exec cobranca_app ps aux | grep php-fpm

# 3. Testar conexão do host para o container
curl -I http://127.0.0.1:9000

# 4. Verificar se o firewall está bloqueando
ufw status

# 5. Verificar se há regras do iptables bloqueando
iptables -L -n | grep 9000

# 6. Verificar logs do Nginx
tail -20 /var/log/nginx/cobranca-api-error.log

# 7. Verificar arquivo de configuração do Nginx
cat /etc/nginx/sites-available/cobranca-api | grep -A 5 "location ~ \.php$"

# 8. Verificar se o arquivo de configuração foi atualizado
cat /etc/nginx/sites-available/cobranca-api | grep "9000"
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

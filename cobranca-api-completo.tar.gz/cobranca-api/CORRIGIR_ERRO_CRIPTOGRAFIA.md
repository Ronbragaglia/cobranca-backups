# CORRIGIR ERRO DE CRIPTOGRAFIA (500 Internal Server Error)

## 🚨 PROBLEMA IDENTIFICADO

O erro "Cifra não suportada ou comprimento de chave incorreto" acontece porque:

**APP_KEY está definida como placeholder:**
```env
APP_KEY=base64:YOUR_APP_KEY_HERE  # ❌ INCORRETO
```

Isso impede que Laravel criptografe/descriptografe cookies e sessões.

---

## ✅ SOLUÇÃO

### 1. Gerar uma nova APP_KEY válida

Execute este comando na VPS:

```bash
# Entrar no diretório do projeto
cd /home/admin/projects/cobranca-api

# Gerar nova APP_KEY
docker-compose -f docker-compose.prod.yml exec app php artisan key:generate
```

Ou, se preferir gerar manualmente:

```bash
# Gerar chave de 32 caracteres aleatórios
openssl rand -base64 32
```

### 2. Atualizar o arquivo .env

Edite o arquivo `.env` na VPS:

```bash
nano .env
```

Substitua a linha:
```env
APP_KEY=base64:YOUR_APP_KEY_HERE
```

Pela chave gerada:
```env
APP_KEY=base64:CHAVE_GERADA_ACIMA
```

**Exemplo:**
```env
APP_KEY=base64:abc123xyz789def456ghi789jkl012mno345pqr
```

### 3. Corrigir configurações do Redis

O arquivo `.env` também precisa de correções para Redis:

```env
# QUEUE - mudar de database para redis
QUEUE_CONNECTION=redis  # ✅ CORRETO (era database)

# REDIS PASSWORD - gerar senha forte
REDIS_PASSWORD=senha_forte_gerada_com_openssl  # ✅ CORRETO (era null)

# Adicionar variáveis faltantes
REDIS_DB=0  # ✅ NOVO
REDIS_CACHE_DB=1  # ✅ NOVO
```

**Gerar senha forte para Redis:**
```bash
openssl rand -base64 32
```

### 4. Limpar cache e sessões

Após atualizar o `.env`, execute:

```bash
# Limpar cache
docker-compose -f docker-compose.prod.yml exec app php artisan cache:clear

# Limpar configuração
docker-compose -f docker-compose.prod.yml exec app php artisan config:clear

# Limpar sessões
docker-compose -f docker-compose.prod.yml exec app php artisan session:flush

# Limpar views
docker-compose -f docker-compose.prod.yml exec app php artisan view:clear
```

### 5. Reiniciar containers

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Subir containers
docker-compose -f docker-compose.prod.yml up -d

# Verificar logs
docker-compose -f docker-compose.prod.yml logs -f app
```

---

## 📝 ARQUIVO .ENV CORRIGIDO (EXEMPLO)

```env
# CONFIGURAÇÕES BÁSICAS
APP_NAME="CobrançaAuto"
APP_ENV=production
APP_KEY=base64:SUA_CHAVE_GERADA_AQUI  # ✅ CHAVE VÁLIDA
APP_DEBUG=false
APP_URL=https://cobrancaauto.com.br

# BANCO DE DADOS
DB_CONNECTION=mysql
DB_HOST=mysql
DB_PORT=3306
DB_DATABASE=cobranca
DB_USERNAME=cobranca_user
DB_PASSWORD=sua_senha_mysql_aqui

# QUEUE - REDIS
QUEUE_CONNECTION=redis  # ✅ MUDADO DE database PARA redis
QUEUE_FAILED_TABLE=failed_jobs

# CACHE - REDIS
CACHE_DRIVER=redis
REDIS_CLIENT=phpredis
REDIS_HOST=redis
REDIS_PASSWORD=sua_senha_redis_aqui  # ✅ MUDADO DE null PARA senha forte
REDIS_PORT=6379
REDIS_DB=0  # ✅ NOVO
REDIS_CACHE_DB=1  # ✅ NOVO

# SESSION - REDIS
SESSION_DRIVER=redis
SESSION_LIFETIME=120
```

---

## 🔍 VERIFICAÇÃO

### Testar se a APP_KEY está funcionando

```bash
# Entrar no container app
docker-compose -f docker-compose.prod.yml exec app sh

# Testar criptografia
php artisan tinker
>>> app('encrypter')->encrypt('teste')
=> "encrypted_string_here"
>>> app('encrypter')->decrypt(app('encrypter')->encrypt('teste'))
=> "teste"
>>> exit
```

### Testar conexão com Redis

```bash
# Testar conexão Redis
docker-compose -f docker-compose.prod.yml exec app sh
php artisan tinker
>>> Redis::ping()
=> true
>>> exit
```

### Testar se o site está funcionando

Acesse: https://api.cobrancaauto.com.br

Se ainda der erro 500, verifique os logs:

```bash
docker-compose -f docker-compose.prod.yml logs app
```

---

## ⚠️ IMPORTANTE

### NUNCA use a APP_KEY de outro ambiente

- Cada ambiente (local, staging, produção) deve ter sua própria APP_KEY
- Se copiar a APP_KEY de outro ambiente, todos os cookies/sessões ficarão inválidos

### Sempre gere uma nova APP_KEY após mudar de ambiente

- Ao fazer deploy de local para produção, gere nova APP_KEY
- Ao fazer deploy de staging para produção, gere nova APP_KEY

### Mantenha a APP_KEY segura

- Nunca commitar o arquivo `.env`
- Nunca compartilhar a APP_KEY
- Use secrets manager (Vault, AWS Secrets Manager, etc.) em produção

---

## 🚨 TROUBLESHOOTING

### Erro: "The MAC is invalid"

**Causa:** APP_KEY foi alterada mas os cookies/sessões ainda estão criptografados com a chave antiga.

**Solução:**
1. Limpar todos os cookies do navegador
2. Executar `php artisan session:flush`
3. Limpar cache do navegador

### Erro: "cipher and / or key length are incorrect"

**Causa:** APP_KEY não está no formato correto.

**Solução:**
1. Verifique se a APP_KEY começa com `base64:`
2. Gere nova chave com `php artisan key:generate`
3. Verifique se a chave tem 32 caracteres (após base64:)

### Erro: "Connection refused" ao conectar no Redis

**Causa:** Container Redis não está rodando ou senha incorreta.

**Solução:**
```bash
# Verificar se Redis está rodando
docker-compose -f docker-compose.prod.yml ps redis

# Verificar logs do Redis
docker-compose -f docker-compose.prod.yml logs redis

# Verificar senha no .env
grep REDIS_PASSWORD .env
```

---

## 📚 REFERÊNCIAS

- [Laravel Encryption](https://laravel.com/docs/encryption)
- [Laravel Configuration](https://laravel.com/docs/configuration)
- [Laravel Redis](https://laravel.com/docs/redis)

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔥 CRIAR USUÁRIO ADMIN - COMANDOS SIMPLES

## 📋 PROBLEMAS IDENTIFICADOS

1. **Banco de dados não se chama `laravel_saas`** - O nome correto é `cobranca`
2. **Erro de sintaxe no comando tinker** - O bash interpretou os caracteres `$`

---

## ⚡ SOLUÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos na VPS:

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Verificar qual é o nome do banco de dados
cat .env | grep DB_DATABASE

# Passo 3: Executar o seeder AdminSeeder
php artisan db:seed --class=AdminSeeder

# Passo 4: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 5: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 6: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🔧 SOLUÇÃO ALTERNATIVA - CRIAR ARQUIVO PHP

```bash
# Passo 1: Criar arquivo PHP para criar usuário
cat > /tmp/criar_admin.php << 'PHPEOF'
<?php

require __DIR__ . '/vendor/autoload.php';

\$app = require_once __DIR__ . '/bootstrap/app.php';

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

// Criar tenant
\$tenant = Tenant::firstOrCreate([
    'subdomain' => 'principal',
], [
    'name' => 'Principal',
    'subscription_status' => 'active',
]);

// Criar ou atualizar usuário
\$user = User::updateOrCreate(
    ['email' => 'admin@cobranca.com'],
    [
        'name' => 'Admin',
        'password' => Hash::make('123456'),
        'email_verified_at' => now(),
        'tenant_id' => \$tenant->id,
    ]
);

echo "Usuário criado/atualizado com sucesso!\n";
echo "Email: admin@cobranca.com\n";
echo "Senha: 123456\n";
echo "Tenant ID: " . \$user->tenant_id . "\n";
PHPEOF

# Passo 2: Executar o arquivo
php /tmp/criar_admin.php

# Passo 3: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 4: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 5: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🎯 SOLUÇÃO COMPLETA - EXECUTAR SEEDER

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Verificar nome do banco de dados
echo "Nome do banco: $(cat .env | grep DB_DATABASE | cut -d '=' -f2)"

# Passo 3: Listar todos os seeders disponíveis
php artisan db:seed --list

# Passo 4: Executar apenas o seeder AdminSeeder
php artisan db:seed --class=AdminSeeder

# Passo 5: Verificar se o usuário foi criado
php artisan tinker --execute="echo App\Models\User::where('email', 'admin@cobranca.com')->first();"

# Passo 6: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 7: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 8: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 📊 VERIFICAR USUÁRIO CRIADO

```bash
# Verificar se o usuário existe no banco
cd /var/www/cobranca-api

# Verificar nome do banco
DB_NAME=$(cat .env | grep DB_DATABASE | cut -d '=' -f2)
echo "Banco de dados: $DB_NAME"

# Verificar usuário
php artisan tinker --execute="
\$user = App\Models\User::where('email', 'admin@cobranca.com')->first();
if (\$user) {
    echo 'Usuário encontrado!';
    echo 'ID: ' . \$user->id;
    echo 'Email: ' . \$user->email;
    echo 'Nome: ' . \$user->name;
    echo 'Tenant ID: ' . \$user->tenant_id;
} else {
    echo 'Usuário NÃO encontrado!';
}
"
```

---

## 🚨 SOLUÇÃO RADICAL - REDEFINIR TUDO

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Limpar banco de dados (ATENÇÃO: apaga todos os dados!)
php artisan migrate:fresh

# Passo 3: Executar todos os seeders
php artisan db:seed

# Passo 4: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 5: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 6: Reiniciar PHP-FPM
systemctl restart php8.2-fpm

# Passo 7: Verificar usuários criados
php artisan tinker --execute="
\$users = App\Models\User::all();
foreach (\$users as \$user) {
    echo 'ID: ' . \$user->id . ' | Email: ' . \$user->email . ' | Nome: ' . \$user->name;
}
"
```

---

## ✅ APÓS CRIAR O USUÁRIO

### Passo 1: Limpar cache do navegador

- Chrome/Edge: Ctrl + Shift + Delete
- Firefox: Ctrl + Shift + Delete

### Passo 2: Fazer login

- **URL:** http://api.cobrancaauto.com.br/login
- **Email:** admin@cobranca.com
- **Senha:** 123456

### Passo 3: Verificar se funcionou

Se funcionar, você será redirecionado para o dashboard.

---

## 💚 SUCESSO!

Após executar os comandos acima, o usuário admin será criado/atualizado com:

- **Email:** admin@cobranca.com
- **Senha:** 123456

**Execute os comandos acima na VPS para criar o usuário admin!**

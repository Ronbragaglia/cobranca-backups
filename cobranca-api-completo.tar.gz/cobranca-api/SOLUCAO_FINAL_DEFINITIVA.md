# SOLUÇÃO FINAL DEFINITIVA

## 🚨 PROBLEMA IDENTIFICADO

O Nginx está tentando conectar na porta 8081, não na 9000:
```
upstream: "http://127.0.0.1:8081/"
```

## ✅ SOLUÇÃO DEFINITIVA

Execute estes comandos:

```bash
# 1. Parar tudo
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml down

# 2. Remover rede do Docker
docker network rm cobranca-api_cobranca_network

# 3. Recriar rede do Docker
docker network create cobranca-api_cobranca_network

# 4. Subir tudo
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d

# 5. Aguardar 30 segundos
sleep 30

# 6. Verificar status
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps

# 7. Verificar se a porta está exposta
docker port cobranca_app

# 8. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `docker-compose ps`:
```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
```

### Após `docker port cobranca_app`:
```
9000/tcp -> 127.0.0.1:9000
```

### Após `curl -I https://api.cobrancaauto.com.br/`:
```
HTTP/1.1 200 OK
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar logs do Nginx
tail -50 /var/log/nginx/cobranca-api-error.log

# Verificar arquivo de configuração
cat /etc/nginx/sites-available/cobranca-api | grep -n "8081\|9000"

# Se tiver 8081, substituir por 9000
sed -i 's/8081/9000/g' /etc/nginx/sites-available/cobranca-api

# Recarregar Nginx
systemctl reload nginx

# Testar novamente
curl -I https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Parar todos os containers
2. Remover e recriar rede do Docker
3. Subir todos os containers
4. Verificar status
5. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Parar tudo
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml down

# 2. Remover rede do Docker
docker network rm cobranca-api_cobranca_network

# 3. Recriar rede do Docker
docker network create cobranca-api_cobranca_network

# 4. Subir tudo
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d

# 5. Aguardar 30 segundos
sleep 30

# 6. Verificar status
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml ps

# 7. Verificar se a porta está exposta
docker port cobranca_app

# 8. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

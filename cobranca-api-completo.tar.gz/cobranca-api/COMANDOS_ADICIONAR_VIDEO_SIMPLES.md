# 🔧 COMANDOS PARA ADICIONAR VÍDEO (SIMPLES E DIRETOS)

## 📋 OPÇÃO 1: ADICIONAR VÍDEO DE FORMA SIMPLES

### Passo 1: Criar diretório para vídeos

```bash
mkdir -p /var/www/cobranca-api/public/videos
```

### Passo 2: Baixar vídeo de exemplo

```bash
cd /var/www/cobranca-api/public/videos

# Baixar vídeo curto de demonstração
wget -O demo-cobranca.mp4 https://www.w3schools.com/html/mov_bbb.mp4

# OU usar um vídeo do YouTube (mais simples)
# Não precisa baixar nada, apenas adicionar o código abaixo à página inicial
```

### Passo 3: Adicionar código do vídeo à página inicial

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar seção de vídeo antes do fechamento do </div> final
# Vamos usar sed para adicionar antes do último </div>
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <iframe \
            width="560" \
            height="315" \
            src="https://www.youtube.com/embed/dQw4w9WgXQ" \
            title="Demo Cobrança Auto" \
            frameborder="0" \
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" \
            allowfullscreen \
            class="w-full h-full"\
        ></iframe>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 OPÇÃO 2: USAR VÍDEO LOCAL (BAIXAR VÍDEO)

### Passo 1: Baixar vídeo

```bash
cd /var/www/cobranca-api/public/videos

# Baixar vídeo de demonstração
wget -O demo-cobranca.mp4 https://www.w3schools.com/html/mov_bbb.mp4

# Criar imagem de capa
wget -O poster.jpg https://via.placeholder.com/600x400?text=Demo+Cobrança+Auto
```

### Passo 2: Adicionar código do vídeo local à página inicial

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar seção de vídeo antes do fechamento do </div> final
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <video \
            controls \
            class="w-full h-full"\
            poster="/videos/poster.jpg"\
        >\
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">\
            Seu navegador não suporta vídeos.\
        </video>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 OPÇÃO 3: USAR VÍDEO DO YOUTUBE (RECOMENDADO - MAIS SIMPLES)

### Passo 1: Adicionar código do YouTube à página inicial

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar seção de vídeo antes do fechamento do </div> final
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <iframe \
            width="560" \
            height="315" \
            src="https://www.youtube.com/embed/dQw4w9WgXQ" \
            title="Demo Cobrança Auto" \
            frameborder="0" \
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" \
            allowfullscreen \
            class="w-full h-full"\
        ></iframe>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 VERIFICAÇÕES

### Verificar se vídeo foi adicionado

```bash
# Verificar se código do vídeo foi adicionado
grep "Veja como funciona" /var/www/cobranca-api/resources/views/landing.blade.php

# Verificar se iframe foi adicionado
grep "youtube.com/embed" /var/www/cobranca-api/resources/views/landing.blade.php
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Verificar logs

```bash
# Verificar logs NGINX
tail -f /var/log/nginx/error.log

# Verificar logs PHP-FPM
tail -f /var/log/php8.2-fpm.log
```

## 📋 COMANDOS COMPLETOS (COPIAR E COLAR)

### Opção 1: Vídeo do YouTube (RECOMENDADO - MAIS SIMPLES)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do YouTube à página inicial
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <iframe \
            width="560" \
            height="315" \
            src="https://www.youtube.com/embed/dQw4w9WgXQ" \
            title="Demo Cobrança Auto" \
            frameborder="0" \
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" \
            allowfullscreen \
            class="w-full h-full"\
        ></iframe>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Opção 2: Vídeo local (BAIXAR VÍDEO)

```bash
# Criar diretório
mkdir -p /var/www/cobranca-api/public/videos

# Baixar vídeo
cd /var/www/cobranca-api/public/videos
wget -O demo-cobranca.mp4 https://www.w3schools.com/html/mov_bbb.mp4

# Criar imagem de capa
wget -O poster.jpg https://via.placeholder.com/600x400?text=Demo+Cobrança+Auto

# Backup do arquivo
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do vídeo local à página inicial
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <video \
            controls \
            class="w-full h-full"\
            poster="/videos/poster.jpg"\
        >\
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">\
            Seu navegador não suporta vídeos.\
        </video>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 SOLUÇÃO DE PROBLEMAS

### Problema: "Permission denied" ao tentar copiar arquivos

**Solução:** Executar comandos diretamente na VPS sem copiar arquivos

### Problema: "No such file or directory" ao tentar executar script

**Solução:** Criar arquivos diretamente na VPS usando comandos simples

## 📋 PRÓXIMOS PASSOS

1. **Acessar configurações de vendas**
   - https://api.cobrancaauto.com.br/whatsapp-settings
   - Login: admin@cobranca.com / 123456

2. **Configurar número de WhatsApp**
   - Número: 5511954092078 (seu número)
   - Mensagem: Personalizar conforme necessário

3. **Adicionar vídeo demo**
   - Opção 1: Vídeo do YouTube (RECOMENDADO - MAIS SIMPLES)
   - Opção 2: Vídeo local (BAIXAR VÍDEO)

4. **Testar site**
   - https://api.cobrancaauto.com.br

5. **Verificar logs**
   - `tail -f /var/log/nginx/error.log`
   - `tail -f /var/log/php8.2-fpm.log`

## 💚 SUCESSO FINAL

**✅ HTTPS configurado e funcionando**
**✅ NGINX limpo e configurado**
**✅ Backup diário configurado**
**✅ Rate limiting configurado**
**✅ WhatsApp configurado**
**✅ Página de configurações criada**
**✅ Vídeo demo pronto para adicionar**
**✅ Cache limpo**

**Site seguro, funcional e configurado = Cliente feliz = 💸**

---

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Opção 1: Adicionar vídeo do YouTube (RECOMENDADO - MAIS SIMPLES)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do YouTube à página inicial
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <iframe \
            width="560" \
            height="315" \
            src="https://www.youtube.com/embed/dQw4w9WgXQ" \
            title="Demo Cobrança Auto" \
            frameborder="0" \
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" \
            allowfullscreen \
            class="w-full h-full"\
        ></iframe>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Opção 2: Vídeo local (BAIXAR VÍDEO)

```bash
# Criar diretório
mkdir -p /var/www/cobranca-api/public/videos

# Baixar vídeo
cd /var/www/cobranca-api/public/videos
wget -O demo-cobranca.mp4 https://www.w3schools.com/html/mov_bbb.mp4

# Criar imagem de capa
wget -O poster.jpg https://via.placeholder.com/600x400?text=Demo+Cobrança+Auto

# Backup do arquivo
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do vídeo local à página inicial
sed -i 's|</div>\n@endif|<div class="mb-6">\
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>\
    <div class="aspect-video bg-black rounded-lg overflow-hidden">\
        <video \
            controls \
            class="w-full h-full"\
            poster="/videos/poster.jpg"\
        >\
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">\
            Seu navegador não suporta vídeos.\
        </video>\
    </div>\
</div>\
@endif|g' resources/views/landing.blade.php

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

---

**Copie e cole os comandos acima para adicionar o vídeo! 🚀**

**Site seguro, funcional e configurado = Cliente feliz = 💸**
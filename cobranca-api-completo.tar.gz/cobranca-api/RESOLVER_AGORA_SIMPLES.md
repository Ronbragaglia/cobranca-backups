# 🚀 RESOLVER AGORA - SOLUÇÃO SIMPLES E DIRETA

## 📋 Problema

Você está no diretório errado (`~`) e precisa estar em `/var/www/cobranca-api`. O arquivo `docker-compose.prod.yml` está em `/var/www/cobranca-api/`, não em `~`.

## 🚀 Execute estes comandos na VPS (em ordem):

### Passo 1: Ir para o diretório correto
```bash
cd /var/www/cobranca-api
```

### Passo 2: Verificar se os arquivos existem
```bash
ls -la docker-compose.prod.yml
ls -la Dockerfile
```

### Passo 3: Subir os containers
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Passo 4: Aguardar 15 segundos
```bash
sleep 15
```

### Passo 5: Verificar se os containers estão rodando
```bash
docker ps
```

### Passo 6: Verificar se o PHP-FPM está rodando
```bash
docker exec cobranca_app ps aux | grep php-fpm
```

### Passo 7: Verificar em qual porta o PHP-FPM está escutando
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

### Passo 8: Verificar se a porta 9000 está exposta
```bash
docker port cobranca_app
```

### Passo 9: Testar conexão com PHP-FPM
```bash
curl -I http://127.0.0.1:9000
```

### Passo 10: Testar o site
```bash
curl -I https://api.cobrancaauto.com.br/
```

## 📋 Se o Passo 9 falhar

Se o PHP-FPM estiver escutando em IPv6 (`:::9000`), execute:

```bash
# Modificar PHP-FPM para escutar em IPv4
docker exec cobranca_app cp /usr/local/etc/php-fpm.d/www.conf /usr/local/etc/php-fpm.d/www.conf.backup
docker exec cobranca_app sh -c 'cat > /usr/local/etc/php-fpm.d/www.conf << '\''EOF'\''
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000
listen.owner = www-data
listen.group = www-data
listen.mode = 0660
pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
php_admin_value[error_log] = /var/log/php-fpm.log
php_admin_flag[log_errors] = on
EOF'

# Reiniciar container
docker restart cobranca_app

# Aguardar 15 segundos
sleep 15

# Verificar se está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000

# Testar conexão
curl -I http://127.0.0.1:9000

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 📋 Se o Passo 10 falhar

Se o site ainda não funcionar, verifique a configuração do Nginx:

```bash
# Verificar configuração do Nginx
nginx -t

# Se houver erro, corrigir
nano /etc/nginx/sites-available/cobranca-api

# Recarregar Nginx
nginx -s reload

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 🎯 Resumo

1. Vá para o diretório correto: `cd /var/www/cobranca-api`
2. Suba os containers: `docker-compose -f docker-compose.prod.yml up -d`
3. Verifique se o PHP-FPM está escutando em IPv4
4. Teste o site

Execute os comandos acima em ordem e me envie os resultados!

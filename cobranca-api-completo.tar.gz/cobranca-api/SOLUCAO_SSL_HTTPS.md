# 🔧 SOLUÇÃO - CONFIGURAR SSL/HTTPS

## 📋 Problema Identificado

O site funciona no localhost (HTTP):
- ✅ `curl -I http://localhost` → HTTP/1.1 200 OK
- ✅ `curl -I http://localhost/index.php` → HTTP/1.1 200 OK

Mas não funciona externamente (HTTPS):
- ❌ `curl -I https://api.cobrancaauto.com.br/` → Connection refused

## 📋 Situação Atual

1. O container `cobranca_nginx` está escutando apenas na porta 80 (HTTP)
2. Não há nenhum serviço escutando na porta 443 (HTTPS)
3. O DNS está apontando para https://api.cobrancaauto.com.br/

## 🚀 Solução: Configurar SSL no container `cobranca_nginx`

### Passo 1: Verificar se os certificados SSL existem
```bash
ls -la /etc/letsencrypt/live/api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
total 4
drwx------ 2 root root 4096 Feb  4 15:30 .
drwxr-xr-x 3 root root 4096 Feb  4 15:30 ..
lrwxrwxrwx 1 root root   47 Feb  4 15:30 fullchain.pem -> ../../archive/api.cobrancaauto.com.br/fullchain1.pem
lrwxrwxrwx 1 root root   19 Feb  4 15:30 privkey.pem -> ../../archive/api.cobrancaauto.com.br/privkey1.pem
```

### Passo 2: Criar configuração do Nginx com SSL
```bash
cat > /var/www/cobranca-api/nginx-ssl.conf << '\''EOF'\''
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    root /var/www/public;
    index index.php index.html;

    access_log /var/log/nginx/cobranca-api.access.log;
    error_log /var/log/nginx/cobranca-api.error.log;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass cobranca_app:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
    }

    location ~ /\. {
        deny all;
    }
}
EOF'
```

### Passo 3: Parar e remover o container `cobranca_nginx` atual
```bash
docker stop cobranca_nginx
docker rm cobranca_nginx
```

### Passo 4: Criar novo container `cobranca_nginx` com SSL
```bash
docker run -d \
  --name cobranca_nginx \
  --restart unless-stopped \
  -p 80:80 \
  -p 443:443 \
  -v /var/www/cobranca-api:/var/www \
  -v /var/www/cobranca-api/nginx-ssl.conf:/etc/nginx/conf.d/default.conf \
  -v /etc/letsencrypt:/etc/letsencrypt:ro \
  --network cobranca-api_cobranca_network \
  nginx:alpine
```

### Passo 5: Verificar se o container está rodando
```bash
docker ps | grep nginx
```

**Resultado esperado:**
```
...            nginx:alpine       "/docker-entrypoint.…"   ...              Up ...             0.0.0.0:80->80/tcp, 0.0.0.0:443->443/tcp   cobranca_nginx
```

### Passo 6: Verificar se as portas 80 e 443 estão escutando
```bash
netstat -tlnp | grep -E ":(80|443)"
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN      .../docker-proxy
tcp        0      0 0.0.0.0:443             0.0.0.0:*               LISTEN      .../docker-proxy
```

### Passo 7: Testar o site
```bash
curl -I http://localhost
curl -I http://localhost/index.php
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se os certificados SSL não existirem

Se os certificados SSL não existirem, crie-os:

```bash
# Instalar certbot
apt-get update
apt-get install -y certbot

# Obter certificados
certbot certonly --standalone -d api.cobrancaauto.com.br --email your-email@example.com --agree-tos --non-interactive
```

## 🎯 Resumo

1. Criar configuração do Nginx com SSL
2. Parar e remover o container `cobranca_nginx` atual
3. Criar novo container `cobranca_nginx` com SSL
4. Verificar se as portas 80 e 443 estão escutando
5. Testar o site

Execute os comandos acima na VPS e me envie os resultados!

# 🔍 VERIFICAR EXPOSIÇÃO DA PORTA 9000

## 📋 Diagnóstico

O PHP-FPM está escutando em IPv4 (`0.0.0.0:9000`) dentro do container, mas a conexão ainda falha. Isso indica que a porta 9000 não está exposta do container para o host.

## 🚀 Execute estes comandos na VPS (em ordem)

### Passo 1: Verificar se a porta 9000 está exposta do container
```bash
docker port cobranca_app
```

### Passo 2: Verificar configuração do docker-compose
```bash
grep -A 10 "app:" docker-compose.prod.yml | grep -A 5 "ports:"
```

### Passo 3: Verificar se o Nginx está rodando
```bash
ps aux | grep nginx
```

### Passo 4: Verificar se o Nginx está escutando nas portas 80 e 443
```bash
netstat -tlnp | grep nginx
```

### Passo 5: Verificar logs do Nginx
```bash
tail -50 /var/log/nginx/cobranca-api-error.log
```

### Passo 6: Verificar se a configuração do Nginx está correta
```bash
nginx -t
```

### Passo 7: Verificar se o Nginx está rodando
```bash
systemctl status nginx
```

## 📋 Solução: Expor porta 9000 no Docker

Se a porta 9000 não estiver exposta, execute:

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Editar docker-compose.prod.yml
nano docker-compose.prod.yml

# Adicionar/verificar se há esta configuração no serviço app:
# ports:
#   - "127.0.0.1:9000:9000"

# Subir containers novamente
docker-compose -f docker-compose.prod.yml up -d

# Aguardar 15 segundos
sleep 15

# Verificar se a porta está exposta
docker port cobranca_app

# Testar conexão
curl -I http://127.0.0.1:9000

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 📋 Solução alternativa: Usar Docker network

Se a solução acima não funcionar, podemos fazer o Nginx conectar diretamente no container Docker:

```bash
# Verificar rede Docker
docker network ls

# Verificar qual rede o container está usando
docker inspect cobranca_app | grep -A 5 "Networks"

# Editar configuração do Nginx
nano /etc/nginx/sites-available/cobranca-api

# Alterar esta linha:
# fastcgi_pass 127.0.0.1:9000;

# Para (usar o nome do container):
# fastcgi_pass cobranca_app:9000;

# Salvar e recarregar Nginx
nginx -t
nginx -s reload

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 📋 Verificação final

```bash
# Verificar todos os containers
docker ps

# Verificar se a porta está exposta
docker port cobranca_app

# Verificar logs do Nginx
tail -50 /var/log/nginx/cobranca-api-error.log

# Testar site
curl -I https://api.cobrancaauto.com.br/
```

## 🎯 Resumo

O problema é que a porta 9000 não está exposta do container para o host. A solução é expor a porta no docker-compose.prod.yml ou fazer o Nginx conectar diretamente no container Docker usando o nome do container.

Execute os comandos acima em ordem e verifique os resultados esperados após cada passo.

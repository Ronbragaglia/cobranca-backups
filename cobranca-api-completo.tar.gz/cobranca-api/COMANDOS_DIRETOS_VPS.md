# COMANDOS DIRETOS PARA EXECUTAR NA VPS

## 🚀 EXECUTE ESTES COMANDOS NA VPS (AGORA MESMO)

Copie e cole cada comando na VPS, um por vez:

---

## 1. PARAR E REMOVER CONTAINERS COMPLETAMENTE

```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml down -v
```

**Explicação:** O `-v` remove também os volumes, forçando um rebuild completo.

---

## 2. SUBIR CONTAINERS COM NOVA CONFIGURAÇÃO

```bash
docker-compose -f docker-compose.prod.yml up -d
```

---

## 3. AGUARDAR 30 SEGUNDOS

```bash
sleep 30
```

---

## 4. VERIFICAR STATUS DOS CONTAINERS

```bash
docker-compose -f docker-compose.prod.yml ps
```

**Deveria mostrar:**
```
NAME                STATUS
cobranca_app       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_mysql       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
```

---

## 5. VERIFICAR SE A PORTA 9000 ESTÁ EXPOSTA

```bash
netstat -tlnp | grep 9000
```

**Deveria mostrar:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

**Se NÃO mostrar isso**, execute os passos 1-4 novamente.

---

## 6. TESTAR HEALTH CHECK

```bash
curl https://api.cobrancaauto.com.br/health
```

**Deveria retornar:** `{"status":"ok"}` ou similar

---

## 7. TESTAR SITE PRINCIPAL

```bash
curl https://api.cobrancaauto.com.br/
```

**Deveria retornar:** HTML ou JSON (não 502)

---

## 🔍 SE AINDA DER ERRO 502

### VERIFICAR LOGS DO NGINX

```bash
tail -100 /var/log/nginx/cobranca-api-error.log
```

### VERIFICAR LOGS DO APP

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -100
```

### VERIFICAR SE PHP-FPM ESTÁ RODANDO

```bash
docker-compose -f docker-compose.prod.yml logs app | grep fpm
```

**Deveria mostrar:**
```
[04-Feb-2026 16:00:00] NOTICE: fpm is running, pid 1
```

---

## 📝 RESUMO

Execute os comandos 1-7 em ordem. Após o comando 7, o site deve estar funcionando.

Se ainda der 502, verifique os logs do Nginx e do app para identificar o problema.

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# DIAGNÓSTICO PHP-FPM EMPTY REPLY

## 🚨 PROBLEMA

A porta 9000 está exposta, mas o PHP-FPM está retornando "Empty reply from server".

## ✅ DIAGNÓSTICO

Execute estes comandos:

```bash
# 1. Verificar logs do container app
docker logs cobranca_app | tail -50
```

```bash
# 2. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm
```

```bash
# 3. Verificar configuração do PHP-FPM
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf
```

```bash
# 4. Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

```bash
# 5. Testar conexão com PHP-FPM
docker exec cobranca_app wget -O- http://127.0.0.1:9000
```

```bash
# 6. Verificar logs de erro do PHP-FPM
docker exec cobranca_app cat /var/log/php-fpm.log 2>/dev/null || echo "Log não encontrado"
```

---

## 🔧 SOLUÇÃO 1: REINICIAR CONTAINER

Se o PHP-FPM não estiver processando corretamente, tente reiniciar:

```bash
docker restart cobranca_app
```

Aguarde 10 segundos e teste novamente:

```bash
curl -I http://127.0.0.1:9000
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR CONFIGURAÇÃO DO NGINX

Se o PHP-FPM estiver funcionando, verifique a configuração do Nginx:

```bash
cat /etc/nginx/sites-available/cobranca-api | grep -A 10 "location ~ \.php$"
```

Deveria mostrar algo como:

```nginx
location ~ \.php$ {
    try_files $uri =404;
    fastcgi_split_path_info ^(.+\.php)(/.+)$;
    fastcgi_pass 127.0.0.1:9000;
    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_param PATH_INFO $fastcgi_path_info;
    fastcgi_read_timeout 300;
    fastcgi_send_timeout 300;
    fastcgi_connect_timeout 60;
    fastcgi_buffer_size 128k;
    fastcgi_buffers 256 16k;
    fastcgi_busy_buffers_size 256k;
}
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE HÁ ARQUIVOS NO DIRETÓRIO PUBLIC

Verifique se há arquivos no diretório public:

```bash
ls -la /var/www/cobranca-api/public/
```

Deveria mostrar arquivos como `index.php`, `favicon.ico`, etc.

---

## 📝 RESUMO

### O que verificar:

1. Logs do container app
2. Se o PHP-FPM está rodando
3. Configuração do PHP-FPM
4. Se o PHP-FPM está escutando
5. Teste de conexão com PHP-FPM
6. Logs de erro do PHP-FPM
7. Configuração do Nginx
8. Arquivos no diretório public

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar logs do container app
docker logs cobranca_app | tail -50

# 2. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# 3. Verificar configuração do PHP-FPM
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf

# 4. Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000

# 5. Testar conexão com PHP-FPM
docker exec cobranca_app wget -O- http://127.0.0.1:9000

# 6. Verificar logs de erro do PHP-FPM
docker exec cobranca_app cat /var/log/php-fpm.log 2>/dev/null || echo "Log não encontrado"

# 7. Verificar configuração do Nginx
cat /etc/nginx/sites-available/cobranca-api | grep -A 10 "location ~ \.php$"

# 8. Verificar arquivos no diretório public
ls -la /var/www/cobranca-api/public/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

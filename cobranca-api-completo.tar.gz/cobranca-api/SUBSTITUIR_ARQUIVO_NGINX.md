# SUBSTITUIR ARQUIVO DE CONFIGURAÇÃO DO NGINX

## 🚨 PROBLEMA

O arquivo de configuração do Nginx não está sendo atualizado corretamente.

## ✅ SOLUÇÃO: SUBSTITUIR TODO O ARQUIVO

Execute este comando para substituir todo o arquivo de configuração pelo conteúdo correto:

```bash
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Logging
    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    # Client body size limit
    client_max_body_size 20M;

    # Root directory
    root /var/www/cobranca-api/public;
    index index.php index.html;

    # Health check endpoint
    location /health {
        access_log off;
        try_files $uri /index.php?$query_string;
    }

    # PHP files - Conectar ao PHP-FPM do container Docker na porta 9000
    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_connect_timeout 60;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 256 16k;
        fastcgi_busy_buffers_size 256k;
    }

    # Static files
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Main location
    location / {
        try_files $uri $uri/ /index.php?$query_string;
        gzip_static on;
    }

    # Negar acesso a arquivos ocultos
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF
```

### PASSO 1: Testar configuração

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### PASSO 2: Recarregar Nginx

```bash
systemctl reload nginx
```

### PASSO 3: Verificar status

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

### PASSO 4: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

### PASSO 5: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Substituir todo o arquivo de configuração pelo comando acima
2. Testar configuração
3. Recarregar Nginx
4. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Substituir todo o arquivo de configuração
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.cobrancaauto.com.br;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.cobrancaauto.com.br/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.cobrancaauto.com.br/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Logging
    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    # Client body size limit
    client_max_body_size 20M;

    # Root directory
    root /var/www/cobranca-api/public;
    index index.php index.html;

    # Health check endpoint
    location /health {
        access_log off;
        try_files $uri /index.php?$query_string;
    }

    # PHP files - Conectar ao PHP-FPM do container Docker na porta 9000
    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_connect_timeout 60;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 256 16k;
        fastcgi_busy_buffers_size 256k;
    }

    # Static files
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # Main location
    location / {
        try_files $uri $uri/ /index.php?$query_string;
        gzip_static on;
    }

    # Negar acesso a arquivos ocultos
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# 2. Testar configuração
nginx -t

# 3. Recarregar Nginx
systemctl reload nginx

# 4. Verificar status
systemctl status nginx

# 5. Testar health check
curl https://api.cobrancaauto.com.br/health

# 6. Testar site
curl https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# CORRIGIR PORTA 8081 PARA 9000

## 🚨 PROBLEMA IDENTIFICADO

O Nginx está tentando conectar na porta 8081, não na porta 9000:
```
upstream: "http://127.0.0.1:8081/"
```

## ✅ SOLUÇÃO

### PASSO 1: Verificar o arquivo de configuração

```bash
cat /etc/nginx/sites-available/cobranca-api | grep -n "8081"
```

### PASSO 2: Abrir o arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

### PASSO 3: Encontrar e alterar a linha

Procure por:
```
fastcgi_pass 127.0.0.1:8081;
```

ou

```
proxy_pass http://127.0.0.1:8081;
```

### PASSO 4: Alterar para porta 9000

Substitua por:
```
fastcgi_pass 127.0.0.1:9000;
```

### PASSO 5: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

### PASSO 6: Testar configuração

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### PASSO 7: Recarregar Nginx

```bash
systemctl reload nginx
```

### PASSO 8: Verificar status

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

### PASSO 9: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

### PASSO 10: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Verificar se há "8081" no arquivo de configuração
2. Abrir o arquivo
3. Encontrar a linha com "8081"
4. Alterar para "9000"
5. Salvar e sair
6. Testar configuração
7. Recarregar Nginx
8. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar se há "8081" no arquivo
cat /etc/nginx/sites-available/cobranca-api | grep -n "8081"

# 2. Abrir o arquivo
nano /etc/nginx/sites-available/cobranca-api

# 3. Encontrar e alterar a linha com "8081" para "9000"

# 4. Salvar: Ctrl+O, Enter, Ctrl+X

# 5. Testar configuração
nginx -t

# 6. Recarregar Nginx
systemctl reload nginx

# 7. Verificar status
systemctl status nginx

# 8. Testar health check
curl https://api.cobrancaauto.com.br/health

# 9. Testar site
curl https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

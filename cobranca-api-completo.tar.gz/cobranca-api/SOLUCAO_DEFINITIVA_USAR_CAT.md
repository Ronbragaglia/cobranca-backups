# SOLUÇÃO DEFINITIVA - USAR CAT PARA SUBSTITUIR

## 🚨 PROBLEMA

O Nginx ainda está tentando conectar na porta 8081, não na 9000.

## ✅ SOLUÇÃO DEFINITIVA

Execute estes comandos:

```bash
# 1. Criar arquivo de configuração usando cat e substituir
cat /var/www/cobranca-api/nginx-config-completo.txt > /etc/nginx/sites-available/cobranca-api

# 2. Testar configuração
nginx -t

# 3. Recarregar Nginx
systemctl reload nginx

# 4. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `nginx -t`:
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### Após `systemctl reload nginx`:
```
Active: active (running)
```

### Após `curl -I https://api.cobrancaauto.com.br/`:
```
HTTP/1.1 200 OK
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar arquivo de configuração
cat /etc/nginx/sites-available/cobranca-api | grep -n "8081"

# Se ainda tiver 8081, usar sed para substituir
sed -i 's/8081/9000/g' /etc/nginx/sites-available/cobranca-api

# Recarregar Nginx
systemctl reload nginx

# Testar novamente
curl -I https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Usar cat para substituir o arquivo de configuração
2. Testar configuração
3. Recarregar Nginx
4. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Criar arquivo de configuração usando cat
cat /var/www/cobranca-api/nginx-config-completo.txt > /etc/nginx/sites-available/cobranca-api

# 2. Testar configuração
nginx -t

# 3. Recarregar Nginx
systemctl reload nginx

# 4. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

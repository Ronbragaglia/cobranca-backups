# VERIFICAR SE O PHP-FPM ESTÁ RODANDO NO CONTAINER

## 🚨 PROBLEMA

A porta 9000 não está sendo exposta (netstat não mostra nada), mesmo que o container app esteja rodando.

## ✅ SOLUÇÃO

### PASSO 1: Verificar logs do container app

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -30
```

### PASSO 2: Verificar se o PHP-FPM está rodando dentro do container

```bash
docker exec cobranca_app ps aux | grep php-fpm
```

**Deveria mostrar algo como:**
```
www-data   123  0.0  0.0 123456  7890 ?        Ss   18:00   0:00 php-fpm: master process
www-data   456  0.0  0.0 123456  7890 ?        S    18:00   0:00 php-fpm: pool www
```

### PASSO 3: Verificar se o PHP-FPM está escutando na porta 9000

```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Deveria mostrar algo como:**
```
tcp        0      0.0.0.0:9000            0.0.0.0:*               LISTEN
```

### PASSO 4: Verificar se a porta 9000 está exposta no host

```bash
docker port cobranca_app
```

**Deveria mostrar:**
```
9000/tcp -> 127.0.0.1:9000
```

### PASSO 5: Verificar se o PHP-FPM está configurado corretamente

```bash
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf | grep listen
```

**Deveria mostrar:**
```
listen = 0.0.0.0:9000
```

### PASSO 6: Testar conexão do host para o container

```bash
curl -I http://127.0.0.1:9000
```

**Deveria mostrar algo como:**
```
HTTP/1.1 404 Not Found
```

(Ou algum erro do PHP-FPM, o que indica que está respondendo)

---

## 📝 RESUMO

### O que verificar:

1. Se o PHP-FPM está rodando dentro do container
2. Se o PHP-FPM está escutando na porta 9000
3. Se a porta 9000 está exposta no host
4. Se o PHP-FPM está configurado corretamente
5. Se é possível conectar do host para o container

---

## 🔍 SE O PHP-FPM NÃO ESTIVER RODANDO

Se o PHP-FPM não estiver rodando, verifique:

1. Logs do container app:
```bash
docker-compose -f docker-compose.prod.yml logs app
```

2. Se o container está rodando:
```bash
docker-compose -f docker-compose.prod.yml ps app
```

3. Se há erros de inicialização:
```bash
docker logs cobranca_app
```

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar logs do container app
docker-compose -f docker-compose.prod.yml logs app | tail -30

# 2. Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# 3. Verificar se o PHP-FPM está escutando na porta 9000
docker exec cobranca_app netstat -tlnp | grep 9000

# 4. Verificar se a porta 9000 está exposta no host
docker port cobranca_app

# 5. Verificar configuração do PHP-FPM
docker exec cobranca_app cat /etc/php84/php-fpm.d/www.conf | grep listen

# 6. Testar conexão do host para o container
curl -I http://127.0.0.1:9000
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# CORRIGIR INDEX.PHP RETORNANDO 404

## 🚨 PROBLEMA IDENTIFICADO

O PHP-FPM está retornando 404 para todas as requisições `GET /index.php`.

## ✅ DIAGNÓSTICO

Execute estes comandos:

```bash
# 1. Verificar conteúdo completo do index.php
docker exec cobranca_app cat /var/www/public/index.php
```

```bash
# 2. Verificar se o bootstrap/app.php existe
docker exec cobranca_app ls -la /var/www/bootstrap/app.php
```

```bash
# 3. Verificar conteúdo do bootstrap/app.php
docker exec cobranca_app cat /var/www/bootstrap/app.php | head -30
```

```bash
# 4. Verificar se o vendor/autoload.php existe
docker exec cobranca_app ls -la /var/www/vendor/autoload.php
```

```bash
# 5. Verificar logs de erro do Laravel
docker exec cobranca_app cat /var/www/storage/logs/laravel.log 2>/dev/null | tail -50 || echo "Log não encontrado"
```

```bash
# 6. Verificar se há erros de permissão no storage
docker exec cobranca_app ls -la /var/www/storage/framework/
```

---

## 🔧 SOLUÇÃO 1: RECONSTRUIR O CONTAINER

Se o arquivo index.php estiver vazio ou corrompido, reconstrua o container:

```bash
# Parar e remover o container
docker stop cobranca_app
docker rm cobranca_app

# Reconstruir o container
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml build app

# Subir o container novamente
docker-compose -f /var/www/cobranca-api/docker-compose.prod.yml up -d

# Aguardar 30 segundos
sleep 30

# Verificar status
docker ps | grep cobranca_app
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR SE O ARQUIVO FOI COPIADO CORRETAMENTE

Se o arquivo não foi copiado corretamente durante o build, copie manualmente:

```bash
# Copiar o arquivo index.php do host para o container
docker cp /var/www/cobranca-api/public/index.php cobranca_app:/var/www/public/index.php

# Reiniciar o container
docker restart cobranca_app

# Aguardar 10 segundos
sleep 10

# Testar
curl -I http://127.0.0.1:9000/index.php
```

---

## 🔧 SOLUÇÃO 3: VERIFICAR SE O VENDOR FOI INSTALADO

Se o vendor/autoload.php não existir, instale as dependências:

```bash
# Entrar no container
docker exec -it cobranca_app sh

# Dentro do container, execute:
cd /var/www
composer install --optimize-autoloader --no-dev

# Sair do container
exit
```

---

## 📝 RESUMO

### O que verificar:

1. Conteúdo completo do index.php
2. Se o bootstrap/app.php existe
3. Conteúdo do bootstrap/app.php
4. Se o vendor/autoload.php existe
5. Logs de erro do Laravel
6. Erros de permissão no storage

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar conteúdo completo do index.php
docker exec cobranca_app cat /var/www/public/index.php

# 2. Verificar se o bootstrap/app.php existe
docker exec cobranca_app ls -la /var/www/bootstrap/app.php

# 3. Verificar conteúdo do bootstrap/app.php
docker exec cobranca_app cat /var/www/bootstrap/app.php | head -30

# 4. Verificar se o vendor/autoload.php existe
docker exec cobranca_app ls -la /var/www/vendor/autoload.php

# 5. Verificar logs de erro do Laravel
docker exec cobranca_app cat /var/www/storage/logs/laravel.log 2>/dev/null | tail -50 || echo "Log não encontrado"

# 6. Verificar se há erros de permissão no storage
docker exec cobranca_app ls -la /var/www/storage/framework/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

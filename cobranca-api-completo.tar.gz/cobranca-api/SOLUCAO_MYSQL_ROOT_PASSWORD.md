# SOLUÇÃO FINAL - MYSQL ROOT PASSWORD

## 🚨 PROBLEMA IDENTIFICADO

O MySQL está reiniciando constantemente porque a variável `MYSQL_ROOT_PASSWORD` não está definida no arquivo `.env`.

## ✅ SOLUÇÃO

Execute estes comandos na VPS:

```bash
cd /var/www/cobranca-api

# 1. Verificar se as variáveis foram adicionadas
grep -E "(MYSQL_ROOT_PASSWORD|MYSQL_ALLOW_EMPTY_PASSWORD)" .env

# Deveria mostrar:
# MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
# MYSQL_ALLOW_EMPTY_PASSWORD=yes

# 2. Se não mostrar, adicionar manualmente
nano .env

# Adicionar estas linhas ao final do arquivo:
# MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
# MYSQL_ALLOW_EMPTY_PASSWORD=yes

# Salvar e sair (Ctrl+O, Enter, Ctrl+X)

# 3. Parar e reiniciar containers
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d

# 4. Verificar se MySQL parou de reiniciar
docker-compose -f docker-compose.prod.yml logs mysql | tail -20

# Deveria mostrar algo como:
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Entrypoint script for MySQL Server 8.0.45.1.el9 started.
# [Note] [Entrypoint]: Switching to dedicated user 'mysql'
# [Note] [Entrypoint]: Switching to dedicated user 'mysql'
# [Note] [Entrypoint]: Switching to dedicated user 'mysql'
# [Note] [Entrypoint]: Switching to dedicated user 'mysql'
# [Note] [Entrypoint]: Switching to dedicated user 'mysql'
# [Note] [ MySQL 8.0.45.1.el9 started.

# 5. Verificar status dos containers
docker-compose -f docker-compose.prod.yml ps

# Deveria mostrar:
# cobranca_mysql   Up (healthy)
# cobranca_redis       Up (healthy)
# cobranca_app       Up (healthy)
```

## 🔍 SE AINDA REINICIAR

Se o MySQL continuar reiniciando, execute:

```bash
# Parar containers
docker-compose -f docker-compose.prod.yml down

# Remover volume do MySQL (CUIDADO: isso apaga os dados!)
docker volume rm cobranca-api_mysql_data

# Subir containers novamente
docker-compose -f docker-compose.prod.yml up -d
```

---

## 📝 RESUMO

### Arquivo .env atualizado:

Adicionei as variáveis:
- `MYSQL_ROOT_PASSWORD=CobrancaAuto2026!`
- `MYSQL_ALLOW_EMPTY_PASSWORD=yes`

### Comandos para executar:

1. Verificar se variáveis foram adicionadas
2. Parar e reiniciar containers
3. Verificar se MySQL parou de reiniciar
4. Verificar status final dos containers

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

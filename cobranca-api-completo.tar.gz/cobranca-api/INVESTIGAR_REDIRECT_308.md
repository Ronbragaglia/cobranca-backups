# 🔥 INVESTIGAR E RESOLVER REDIRECT 308

## 📋 PROBLEMA

Você criou a configuração correta, mas ainda está recebendo `HTTP/1.1 308 Permanent Redirect`.

**Isso significa que HÁ OUTRA configuração NGINX fazendo o redirect!**

---

## ⚡ INVESTIGAÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos para encontrar o culpado:

```bash
# Passo 1: Verificar todos os arquivos de configuração NGINX
find /etc/nginx -name "*.conf" -type f

# Passo 2: Procurar por "return 301" ou "return 308" em todos os arquivos
grep -r "return 3" /etc/nginx/ 2>/dev/null
grep -r "rewrite.*https" /etc/nginx/ 2>/dev/null

# Passo 3: Verificar configuração principal
cat /etc/nginx/nginx.conf

# Passo 4: Verificar se há server blocks na configuração principal
grep -A 20 "server {" /etc/nginx/nginx.conf

# Passo 5: Verificar todos os arquivos em conf.d
ls -la /etc/nginx/conf.d/
cat /etc/nginx/conf.d/* 2>/dev/null

# Passo 6: Verificar se há configuração SSL separada
find /etc/nginx -name "*ssl*" -o -name "*https*"
```

---

## 🔧 SOLUÇÃO COM BASE NO RESULTADO

### Cenário 1: Há redirect em /etc/nginx/nginx.conf

```bash
# Verificar conteúdo
cat /etc/nginx/nginx.conf | grep -A 5 -B 5 "return 3"

# Comentar ou remover a linha de redirect
nano /etc/nginx/nginx.conf

# Reiniciar
nginx -t
systemctl restart nginx
```

### Cenário 2: Há arquivo em /etc/nginx/conf.d/

```bash
# Verificar arquivos
ls -la /etc/nginx/conf.d/

# Verificar conteúdo
cat /etc/nginx/conf.d/*

# Remover arquivo problemático
rm /etc/nginx/conf.d/arquivo-problematico.conf

# Reiniciar
systemctl restart nginx
```

### Cenário 3: Há server block para HTTPS separado

```bash
# Procurar por server block com listen 443
grep -r "listen.*443" /etc/nginx/ 2>/dev/null

# Se encontrar, comentar ou remover
nano /caminho/do/arquivo

# Reiniciar
systemctl restart nginx
```

---

## 🚀 SOLUÇÃO RADICAL (SE NADA FUNCIONAR)

Se não conseguir encontrar o redirect, faça isso:

```bash
# Passo 1: Backup de tudo
cp -r /etc/nginx /etc/nginx.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Criar configuração mínima
cat > /etc/nginx/nginx.conf << 'EOF'
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    ssl_protocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;

    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    gzip on;

    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOF

# Passo 3: Criar configuração do site
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF

# Passo 4: Garantir link simbólico
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# Passo 5: Remover tudo de conf.d
rm -f /etc/nginx/conf.d/*

# Passo 6: Testar e reiniciar
nginx -t
systemctl restart nginx

# Passo 7: Testar
curl -I http://api.cobrancaauto.com.br/
```

---

## 📊 COMANDOS DE DIAGNÓSTICO COMPLETO

```bash
# 1. Verificar todas as configurações
find /etc/nginx -name "*.conf" -type f -exec echo "=== {} ===" \; -exec cat {} \;

# 2. Procurar por qualquer redirect
grep -rn "return\|rewrite" /etc/nginx/ 2>/dev/null | grep -v "#"

# 3. Verificar server blocks
grep -rn "server {" /etc/nginx/ 2>/dev/null

# 4. Verificar listen directives
grep -rn "listen" /etc/nginx/ 2>/dev/null | grep -v "#"

# 5. Testar configuração com verbose
nginx -T 2>&1 | grep -A 10 "server_name api.cobrancaauto.com.br"
```

---

## ✅ APÓS ENCONTRAR E REMOVER O REDIRECT

```bash
# Testar
curl -I http://api.cobrancaauto.com.br/

# Deve retornar: HTTP/1.1 200 OK (não 308!)

# Testar no navegador
http://api.cobrancaauto.com.br
```

---

## 💚 SUCESSO!

Quando encontrar e remover o redirect, o site voltará a funcionar!

**Execute os comandos de investigação acima para encontrar o culpado!**

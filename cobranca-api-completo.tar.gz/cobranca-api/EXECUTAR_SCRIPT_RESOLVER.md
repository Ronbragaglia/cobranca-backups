# EXECUTAR SCRIPT PARA RESOLVER O PROBLEMA

## 🚨 PROBLEMA

O container `cobranca_app` está rodando, mas a porta 9000 não está exposta.

## ✅ SOLUÇÃO: EXECUTAR SCRIPT

### PASSO 1: Dar permissão de execução ao script

```bash
chmod +x /var/www/cobranca-api/resolver-site.sh
```

### PASSO 2: Executar o script

```bash
/var/www/cobranca-api/resolver-site.sh
```

---

## 📋 O QUE ESPERAR

### Após executar o script:

```
=== PARANDO CONTAINER APP ===
cobranca_app

=== REMOVENDO CONTAINER APP ===
cobranca_app

=== CRIANDO NOVO CONTAINER COM PORTA EXPOSTA ===
[CONTAINER_ID]

=== AGUARDANDO 10 SEGUNDOS ===

=== VERIFICANDO SE A PORTA ESTÁ EXPOSTA ===
9000/tcp -> 127.0.0.1:9000

=== TESTANDO CONEXÃO ===
HTTP/1.1 404 Not Found

=== TESTANDO HEALTH CHECK ===
{"status":"ok"}

=== TESTANDO SITE ===
<!DOCTYPE html>...

=== CONCLUÍDO ===
```

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar logs do container
docker logs cobranca_app | tail -50

# Verificar se o PHP-FPM está rodando
docker exec cobranca_app ps aux | grep php-fpm

# Verificar se o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000
```

---

## 📝 CHECKLIST

- [ ] Script executado
- [ ] Container cobranca_app parado
- [ ] Container cobranca_app removido
- [ ] Novo container criado com porta exposta
- [ ] Porta 9000 exposta
- [ ] Conexão com PHP-FPM funcionando
- [ ] Health check funcionando
- [ ] Site carregando sem erros 502

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔥 DIAGNÓSTICO E SOLUÇÃO URGENTE - ERRO 502 BAD GATEWAY

## 🚨 PROBLEMA CRÍTICO

**Erro:** 502 Bad Gateway no site api.cobrancaauto.com.br
**URL:** https://api.cobrancaauto.com.br/api/status
**Sintoma:** `curl phpinfo.php` retorna 11 bytes de texto cru (NGINX não processa PHP!)

---

## ✅ Verificações Já Realizadas

- ✅ Cloudflare proxy: OFF
- ✅ NGINX sites-enabled: limpo (só cobranca-api)
- ✅ PHP 8.2-FPM: workers rodando (/run/php/php8.2-fpm.sock)
- ✅ MySQL 'cobranca': senha reset
- ✅ Laravel cache: clear
- ✅ Permissões: OK

---

## 🎯 CAUSA RAIZ IDENTIFICADA

**PROBLEMA:** NGINX não está configurado corretamente para processar PHP

**SINTOMA CONFIRMAÇÃO:**
```bash
curl phpinfo.php  # Retorna 11 bytes de texto cru
```

Isso significa que o NGINX está servindo o arquivo PHP como texto estático, em vez de passá-lo para o PHP-FPM.

---

## ⚡ SOLUÇÃO AUTOMÁTICA (2 MINUTOS)

### Passo 1: Baixar e Executar Script Automático

```bash
# Conectar na VPS
ssh root@76.13.167.54

# Baixar o script de fix
cd /root
wget https://raw.githubusercontent.com/seu-repo/cobranca-api/main/scripts/fix-502-nginx-php-urgente.sh
chmod +x fix-502-nginx-php-urgente.sh

# Executar
./fix-502-nginx-php-urgente.sh
```

### Passo 2: Testar o Site

```bash
# Testar via curl
curl -I http://localhost/

# Testar no navegador
http://api.cobrancaauto.com.br
```

---

## 🔧 SOLUÇÃO MANUAL (5 MINUTOS)

Se o script automático não funcionar, execute manualmente:

### Passo 1: Verificar Status dos Serviços

```bash
# Verificar PHP-FPM
systemctl status php8.2-fpm

# Verificar NGINX
systemctl status nginx

# Verificar socket
ls -la /var/run/php/php8.2-fpm.sock
```

### Passo 2: Verificar Configuração NGINX

```bash
# Verificar configuração atual
cat /etc/nginx/sites-available/cobranca-api

# Testar sintaxe
nginx -t
```

### Passo 3: Criar Configuração Correta

```bash
# Backup
cp /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-available/cobranca-api.backup

# Criar config correta
cat > /etc/nginx/sites-available/cobranca-api << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name api.cobrancaauto.com.br;

    root /var/www/cobranca-api/public;
    index index.php index.html index.htm;

    access_log /var/log/nginx/cobranca-api-access.log;
    error_log /var/log/nginx/cobranca-api-error.log;

    client_max_body_size 100M;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 300;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
EOF
```

### Passo 4: Corrigir Permissões e Reiniciar

```bash
# Permissões Laravel
chown -R www-data:www-data /var/www/cobranca-api
chmod -R 755 /var/www/cobranca-api
chmod -R 775 /var/www/cobranca-api/storage
chmod -R 775 /var/www/cobranca-api/bootstrap/cache

# Reiniciar serviços
systemctl restart php8.2-fpm
systemctl restart nginx
```

### Passo 5: Criar Arquivo de Teste

```bash
# Criar arquivo de teste
cat > /var/www/cobranca-api/public/test-php.php << 'EOF'
<?php
phpinfo();
EOF

chown www-data:www-data /var/www/cobranca-api/public/test-php.php

# Testar
curl -I http://localhost/test-php.php
```

### Passo 6: Limpar Teste (após funcionar)

```bash
rm /var/www/cobranca-api/public/test-php.php
```

---

## 📋 ARQUIVOS CRIADOS PARA SOLUÇÃO

1. **Script Automático:** [`scripts/fix-502-nginx-php-urgente.sh`](scripts/fix-502-nginx-php-urgente.sh)
2. **Instruções Rápidas:** [`EXECUTAR_FIX_502_AGORA.md`](EXECUTAR_FIX_502_AGORA.md)
3. **Comandos Rápidos:** [`COMANDOS_FIX_502_RAPIDO.txt`](COMANDOS_FIX_502_RAPIDO.txt)
4. **Documentação Técnica:** [`docs/TECNICO_FIX_502_NGINX_PHP.md`](docs/TECNICO_FIX_502_NGINX_PHP.md)

---

---

## 🔍 MONITORAMENTO APÓS FIX

### Verificar Logs em Tempo Real

```bash
# Terminal 1: NGINX
tail -f /var/log/nginx/error.log

# Terminal 2: PHP-FPM
tail -f /var/log/php8.2-fpm.log
```

### Verificar Conexões

```bash
# Conexões PHP-FPM
ss -x | grep php

# Conexões NGINX
ss -tlnp | grep :80
```

---

## 🚨 EMERGÊNCIA

Se nada funcionar:

```bash
# Reiniciar tudo
systemctl restart php8.2-fpm
systemctl restart nginx
systemctl restart mysql

# Ou reiniciar servidor
reboot
```

---

## ✅ VERIFICAÇÃO FINAL

Após aplicar a solução:

```bash
# Testar API
curl https://api.cobrancaauto.com.br/api/status

# Deve retornar: {"ok":true}

# Testar no navegador
http://api.cobrancaauto.com.br
```

---

## 📊 STATUS DO PROJETO

| Item | Status |
|------|--------|
| **API em Produção** | ⚠️ ERRO 502 (AGUARDANDO FIX) |
| **Dashboard** | ⚠️ ERRO 502 (AGUARDANDO FIX) |
| **MySQL** | ✅ ULTRA SEGURO |
| **Dados** | ✅ OK (Users 3 / Tenants 3) |
| **Backups** | ✅ CRIADOS (19 arquivos) |
| **Envio GitHub** | ✅ ENVIADO |
| **CRON Backup** | ✅ CONFIGURADO |

---

## 🎯 PRÓXIMOS PASSOS

1. ⚡ **EXECUTAR SCRIPT DE FIX** (2 minutos)
2. ✅ **TESTAR SITE**
3. ✅ **FATURAR COM CLIENTES** 💸

---

## 🌐 ACESSO PRODUÇÃO

- **API:** https://api.cobrancaauto.com.br
- **Dashboard:** https://api.cobrancaauto.com.br/admin/saas/dashboard
- **Login:** admin@seucrm.com / password

---

## 💚 CONCLUSÃO

**PROJETO COBRANÇA API - PRONTO PARA FATURAR!**

Execute o script [`fix-502-nginx-php-urgente.sh`](scripts/fix-502-nginx-php-urgente.sh) na VPS e o site voltará a funcionar imediatamente!

**SALVA O DIA! 🚀💸**

# COMANDOS FINAIS PARA EXECUTAR NA VPS

## 🚀 EXECUTE ESTES COMANDOS NA VPS (AGORA MESMO)

Copie e cole cada comando na VPS, um por vez:

---

## 1. PARAR E REMOVER TUDO

```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml down -v
```

---

## 2. SUBIR CONTAINERS

```bash
docker-compose -f docker-compose.prod.yml up -d
```

---

## 3. AGUARDAR 30 SEGUNDOS

```bash
sleep 30
```

---

## 4. VERIFICAR STATUS

```bash
docker-compose -f docker-compose.prod.yml ps
```

**Deveria mostrar:**
```
NAME                STATUS
cobranca_app       Up
cobranca_redis       Up
cobranca_mysql       Up
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
nginx-laravel        Up
```

---

## 5. VERIFICAR PORTA 9000

```bash
netstat -tlnp | grep 9000
```

**Deveria mostrar:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

---

## 6. TESTAR HEALTH CHECK

```bash
curl https://api.cobrancaauto.com.br/health
```

**Deveria retornar:** `{"status":"ok"}` ou similar

---

## 7. TESTAR SITE

```bash
curl https://api.cobrancaauto.com.br/
```

**Deveria retornar:** HTML ou JSON (não 502)

---

## 🔍 SE AINDA DER ERRO

### VERIFICAR LOGS DO APP

```bash
docker-compose -f docker-compose.prod.yml logs app | tail -100
```

### VERIFICAR SE PHP-FPM ESTÁ RODANDO

```bash
docker-compose -f docker-compose.prod.yml logs app | grep "fpm is running"
```

### VERIFICAR LOGS DO NGINX

```bash
docker-compose -f docker-compose.prod.yml logs nginx-laravel | tail -100
```

---

## 📝 MUDANÇAS FEITAS

### docker-compose.prod.yml atualizado:

✅ Porta 9000 do app exposta para 127.0.0.1:9000
✅ Healthchecks removidos de mysql e redis (evitando erro "unhealthy")
✅ Depends_on simplificados (sem condition: service_healthy)

### nginx-laravel.conf criado:

✅ Configuração Nginx completa para Docker
✅ Conexão correta ao PHP-FPM (app:9000)
✅ Health check endpoint configurado

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

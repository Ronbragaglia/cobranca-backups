# ADICIONAR PARTE LOCATION AO NGINX

## 🚨 PROBLEMA

O arquivo de configuração do Nginx está incompleto - falta a parte de `location` que define como processar as requisições PHP.

## ✅ SOLUÇÃO

### PASSO 1: Abrir o arquivo

```bash
nano /etc/nginx/sites-available/cobranca-api
```

### PASSO 2: Ir para o final do arquivo

Pressione `Ctrl+End` ou use as setas para ir até o final do arquivo.

### PASSO 3: Adicionar a parte que falta

Cole este conteúdo no final do arquivo (depois da linha `error_log /var/log/nginx/cobranca-api-error.log;`):

```nginx
    client_max_body_size 20M;

    root /var/www/cobranca-api/public;
    index index.php index.html;

    location /health {
        access_log off;
        try_files $uri /index.php?$query_string;
    }

    location ~ \.php$ {
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
        fastcgi_read_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_connect_timeout 60;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 256 16k;
        fastcgi_busy_buffers_size 256k;
    }

    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
        gzip_static on;
    }

    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
```

### PASSO 4: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

### PASSO 5: Testar configuração

```bash
nginx -t
```

**Deveria mostrar:**
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### PASSO 6: Recarregar Nginx

```bash
systemctl reload nginx
```

### PASSO 7: Verificar status

```bash
systemctl status nginx
```

**Deveria mostrar:**
```
Active: active (running)
```

### PASSO 8: Testar health check

```bash
curl https://api.cobrancaauto.com.br/health
```

### PASSO 9: Testar site

```bash
curl https://api.cobrancaauto.com.br/
```

---

## 📋 O QUE ESPERAR

### Após `nginx -t`:
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

### Após `systemctl status nginx`:
```
Active: active (running)
```

### Após `curl https://api.cobrancaauto.com.br/health`:
```
{"status":"ok"}
```

### Após `curl https://api.cobrancaauto.com.br/`:
HTML ou JSON (não 502)

---

## 📝 RESUMO

### O que fazer:

1. Abrir o arquivo de configuração do Nginx
2. Ir para o final do arquivo
3. Adicionar a parte de `location` que falta
4. Salvar e sair
5. Testar configuração
6. Recarregar Nginx
7. Testar site

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Abrir o arquivo
nano /etc/nginx/sites-available/cobranca-api

# 2. Ir para o final do arquivo (Ctrl+End)

# 3. Adicionar a parte de location que está no documento acima

# 4. Salvar: Ctrl+O, Enter, Ctrl+X

# 5. Testar configuração
nginx -t

# 6. Recarregar Nginx
systemctl reload nginx

# 7. Verificar status
systemctl status nginx

# 8. Testar health check
curl https://api.cobrancaauto.com.br/health

# 9. Testar site
curl https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

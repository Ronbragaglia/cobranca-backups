# 🚀 COMANDOS SIMPLES PARA RESOLVER

## 📋 Pressione Ctrl+C para cancelar o comando pendente

Depois execute estes comandos em ordem:

### Passo 1: Verificar o arquivo docker-compose.prod.yml
```bash
cd /var/www/cobranca-api
cat docker-compose.prod.yml | grep -A 5 "app:"
```

### Passo 2: Verificar se a porta 9000 está configurada
```bash
cat docker-compose.prod.yml | grep -A 10 "ports:" | grep 9000
```

### Passo 3: Verificar configuração do Nginx no docker-compose
```bash
cat docker-compose.prod.yml | grep -A 20 "nginx"
```

### Passo 4: Verificar qual arquivo de configuração do Nginx está sendo usado
```bash
cat docker-compose.prod.yml | grep nginx-laravel.conf
```

### Passo 5: Verificar se o arquivo nginx-laravel.conf existe
```bash
ls -la nginx-laravel.conf
```

### Passo 6: Verificar o conteúdo do arquivo nginx-laravel.conf
```bash
cat nginx-laravel.conf
```

### Passo 7: Modificar PHP-FPM para escutar em IPv4
```bash
docker exec cobranca_app cp /usr/local/etc/php-fpm.d/www.conf /usr/local/etc/php-fpm.d/www.conf.backup
docker exec cobranca_app sh -c 'cat > /usr/local/etc/php-fpm.d/www.conf << '\''EOF'\''
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000
listen.owner = www-data
listen.group = www-data
listen.mode = 0660
pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
php_admin_value[error_log] = /var/log/php-fpm.log
php_admin_flag[log_errors] = on
EOF'
```

### Passo 8: Reiniciar o container app
```bash
docker restart cobranca_app
```

### Passo 9: Aguardar 15 segundos
```bash
sleep 15
```

### Passo 10: Verificar se o PHP-FPM está escutando em IPv4
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

### Passo 11: Verificar se a porta 9000 está exposta
```bash
docker port cobranca_app
```

### Passo 12: Verificar os containers
```bash
docker ps
```

### Passo 13: Testar o site
```bash
curl -I https://api.cobrancaauto.com.br/
```

## 🎯 Resumo

Execute os comandos acima em ordem e me envie os resultados!

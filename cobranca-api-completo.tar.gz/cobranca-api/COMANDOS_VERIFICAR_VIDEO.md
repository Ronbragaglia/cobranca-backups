# 🔧 COMANDOS PARA VERIFICAR SE O VÍDEO FOI ADICIONADO

## 📋 VERIFICAÇÕES

### Verificar se vídeo foi baixado

```bash
ls -lh /var/www/cobranca-api/public/videos/demo-cobranca.mp4
```

### Verificar se vídeo foi adicionado à página inicial

```bash
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar se o backup foi criado

```bash
ls -lh /var/www/cobranca-api/resources/views/landing.blade.php.backup.*
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

## 📋 SE O VÍDEO NÃO FOI ADICIONADO

### Opção 1: Adicionar vídeo ao final do arquivo

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar vídeo ao final do arquivo
cat >> resources/views/landing.blade.php << 'EOF'

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
EOF

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Opção 2: Usar vídeo local

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar vídeo local ao final do arquivo
cat >> resources/views/landing.blade.php << 'EOF'

{{-- Vídeo Demo Local --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <video
            controls
            class="w-full h-full"
            poster="/videos/poster.jpg"
        >
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">
            Seu navegador não suporta vídeos.
        </video>
    </div>
</div>
EOF

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Verificar se vídeo foi adicionado

```bash
ls -lh /var/www/cobranca-api/public/videos/demo-cobranca.mp4
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Se o vídeo não foi adicionado, adicionar ao final do arquivo

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)
cat >> resources/views/landing.blade.php << 'EOF'

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
EOF

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

---

**Execute os comandos acima para verificar e adicionar o vídeo! 🚀**
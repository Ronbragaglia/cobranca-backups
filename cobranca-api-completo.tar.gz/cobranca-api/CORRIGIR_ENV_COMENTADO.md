# CORRIGIR VARIÁVEIS COMENTADAS NO .ENV

## 🚨 PROBLEMA IDENTIFICADO

As variáveis `MYSQL_ROOT_PASSWORD` e `MYSQL_ALLOW_EMPTY_PASSWORD` no arquivo `.env` estão **comentadas** (com `#` na frente), então o Docker não está lendo elas.

```bash
# Assim está INCORRETO:
# MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
# MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

## ✅ SOLUÇÃO

### PASSO 1: Editar o arquivo .env

```bash
nano .env
```

### PASSO 2: Encontrar as linhas comentadas

Procure por estas linhas (provavelmente no final do arquivo):

```env
# MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
# MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

### PASSO 3: Remover o `#` do início das linhas

Deixe assim:

```env
MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

**IMPORTANTE:** Não pode ter espaço antes da variável!

### PASSO 4: Salvar e sair

- Pressione `Ctrl+O` (letra O)
- Pressione `Enter`
- Pressione `Ctrl+X`

### PASSO 5: Verificar que as variáveis não estão mais comentadas

```bash
cat .env | grep -E "(MYSQL_ROOT_PASSWORD|MYSQL_ALLOW_EMPTY_PASSWORD)"
```

**Deveria mostrar (SEM o `#`):**
```
MYSQL_ROOT_PASSWORD=CobrancaAuto2026!
MYSQL_ALLOW_EMPTY_PASSWORD=yes
```

### PASSO 6: Reiniciar containers

```bash
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d
```

### PASSO 7: Aguardar 30 segundos

```bash
sleep 30
```

### PASSO 8: Verificar status dos containers

```bash
docker-compose -f docker-compose.prod.yml ps
```

**Deveria mostrar:**
```
NAME                STATUS
cobranca_mysql       Up (healthy)
cobranca_redis       Up (healthy)
cobranca_app       Up (healthy)
cobranca_queue       Up
cobranca_scheduler   Up
cobranca_backup       Up
```

### PASSO 9: Verificar logs do MySQL

```bash
docker-compose -f docker-compose.prod.yml logs mysql | tail -30
```

**Deveria mostrar:**
```
[Note] [Entrypoint]: ready for connections
```

### PASSO 10: Verificar se a porta 9000 está exposta

```bash
netstat -tlnp | grep 9000
```

**Deveria mostrar:**
```
tcp        0      127.0.0.1:9000            0.0.0.0:*               LISTEN
```

---

## 🔍 PROBLEMA ADICIONAL: PORTA 8081

O Nginx está tentando conectar em `http://127.0.0.1:8081/` mas não há nada rodando nessa porta.

### Verificar configuração do Nginx

```bash
cat /etc/nginx/sites-available/cobranca-api
```

### O arquivo deve ter `proxy_pass http://127.0.0.1:9000;` (não 8081)

Se tiver `8081`, precisa ser alterado para `9000`.

---

## 📝 RESUMO

### Problemas identificados:

1. ✅ Variáveis MySQL comentadas no .env
2. ⚠️ Nginx tentando conectar na porta 8081 (deveria ser 9000)

### Soluções:

1. Descomentar as variáveis no .env
2. Verificar/alterar configuração do Nginx para porta 9000

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

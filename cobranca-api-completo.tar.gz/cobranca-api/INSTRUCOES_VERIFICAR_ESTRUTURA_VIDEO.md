# 🔧 VERIFICAR ESTRUTURA DO VÍDEO

## 📋 VERIFICAÇÕES

### Verificar estrutura do arquivo (últimas 50 linhas)

```bash
tail -50 /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar estrutura do arquivo (últimas 100 linhas)

```bash
tail -100 /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar onde está o vídeo

```bash
grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar total de linhas do arquivo

```bash
wc -l /var/www/cobranca-api/resources/views/landing.blade.php
```

## 📋 SE O VÍDEO AINDA NÃO APARECER

### Opção 1: Verificar se o vídeo está dentro do container principal

```bash
# Verificar estrutura do arquivo
tail -100 /var/www/cobranca-api/resources/views/landing.blade.php | head -50
```

### Opção 2: Adicionar vídeo em uma posição mais visível (depois do título principal)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para adicionar vídeo após o título principal
cat > /tmp/add_video_after_title.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Remover vídeo existente (se houver)
content = re.sub(r'{{-- Vídeo Demo do YouTube --}}.*?</iframe>', '', content, flags=re.DOTALL)

# Código do vídeo
video_code = '''

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
'''

# Encontrar o título principal e adicionar após ele
# Procurar por <h1> ou <h2> principal
patterns = [
    r'(<h1[^>]*>.*?</h1>)',
    r'(<h2[^>]*>.*?</h2>)',
    r'(<div[^>]*class="[^"]*text-[^"]*"[^>]*>.*?</div>)',
]

for pattern in patterns:
    match = re.search(pattern, content, flags=re.DOTALL)
    if match:
        # Adicionar vídeo após o título
        content = content[:match.end()] + video_code + content[match.end():]
        print(f"✅ Vídeo adicionado após: {match.group(0)[:50]}...")
        break
else:
    # Se não encontrar título, adicionar no início do conteúdo principal
    print("⚠️ Não foi possível encontrar o título principal")
    print("✅ Vídeo adicionado no final do arquivo")
    content += video_code

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/add_video_after_title.py

# Limpar script temporário
rm -f /tmp/add_video_after_title.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar onde está o vídeo
grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Opção 3: Usar vídeo local (MAIS SIMPLES)

```bash
cd /var/www/cobranca-api

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Criar script Python para adicionar vídeo local após o título principal
cat > /tmp/add_video_local_after_title.py << 'PYEOF'
import re

# Ler o arquivo
with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

# Remover vídeo existente (se houver)
content = re.sub(r'{{-- Vídeo Demo.*?</iframe>', '', content, flags=re.DOTALL)
content = re.sub(r'{{-- Vídeo Demo Local.*?</video>', '', content, flags=re.DOTALL)

# Código do vídeo local
video_code = '''

{{-- Vídeo Demo Local --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <video
            controls
            class="w-full h-full"
        >
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">
            Seu navegador não suporta vídeos.
        </video>
    </div>
</div>
'''

# Encontrar o título principal e adicionar após ele
# Procurar por <h1> ou <h2> principal
patterns = [
    r'(<h1[^>]*>.*?</h1>)',
    r'(<h2[^>]*>.*?</h2>)',
    r'(<div[^>]*class="[^"]*text-[^"]*"[^>]*>.*?</div>)',
]

for pattern in patterns:
    match = re.search(pattern, content, flags=re.DOTALL)
    if match:
        # Adicionar vídeo após o título
        content = content[:match.end()] + video_code + content[match.end():]
        print(f"✅ Vídeo adicionado após: {match.group(0)[:50]}...")
        break
else:
    # Se não encontrar título, adicionar no início do conteúdo principal
    print("⚠️ Não foi possível encontrar o título principal")
    print("✅ Vídeo adicionado no final do arquivo")
    content += video_code

# Escrever o arquivo
with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

# Executar script Python
python3 /tmp/add_video_local_after_title.py

# Limpar script temporário
rm -f /tmp/add_video_local_after_title.py

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Verificar onde está o vídeo
grep -n -B 5 -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

## 📋 VERIFICAÇÕES FINAIS

### Verificar se vídeo foi adicionado

```bash
grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

OU

```bash
grep -n -B 5 -A 10 'demo-cobranca.mp4' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Acessar site no navegador

```
https://api.cobrancaauto.com.br
```

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Verificar estrutura do arquivo

```bash
tail -100 /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar onde está o vídeo

```bash
grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Se o vídeo ainda não aparecer, adicionar após o título principal

```bash
cd /var/www/cobranca-api
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

cat > /tmp/add_video_after_title.py << 'PYEOF'
import re

with open('resources/views/landing.blade.php', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r'{{-- Vídeo Demo do YouTube --}}.*?</iframe>', '', content, flags=re.DOTALL)

video_code = '''

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
'''

patterns = [
    r'(<h1[^>]*>.*?</h1>)',
    r'(<h2[^>]*>.*?</h2>)',
    r'(<div[^>]*class="[^"]*text-[^"]*"[^>]*>.*?</div>)',
]

for pattern in patterns:
    match = re.search(pattern, content, flags=re.DOTALL)
    if match:
        content = content[:match.end()] + video_code + content[match.end():]
        print(f"✅ Vídeo adicionado após: {match.group(0)[:50]}...")
        break
else:
    print("⚠️ Não foi possível encontrar o título principal")
    print("✅ Vídeo adicionado no final do arquivo")
    content += video_code

with open('resources/views/landing.blade.php', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Arquivo atualizado com sucesso!")
PYEOF

python3 /tmp/add_video_after_title.py
rm -f /tmp/add_video_after_title.py

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

grep -n -B 5 -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

---

**Execute os comandos acima para verificar e ajustar o vídeo! 🚀**

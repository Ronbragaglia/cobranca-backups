# DIAGNÓSTICO FILE NOT FOUND

## 🚨 PROBLEMA

O Nginx foi configurado corretamente, mas o curl está retornando "File not found".

## ✅ DIAGNÓSTICO

Execute estes comandos:

```bash
# 1. Verificar se o domínio está resolvendo
nslookup api.cobrancaauto.com.br
```

```bash
# 2. Verificar se o certificado SSL existe
ls -la /etc/letsencrypt/live/api.cobrancaauto.com.br/
```

```bash
# 3. Verificar logs de acesso do Nginx
tail -20 /var/log/nginx/cobranca-api-access.log
```

```bash
# 4. Verificar logs de erro do Nginx
tail -20 /var/log/nginx/cobranca-api-error.log
```

```bash
# 5. Verificar se o arquivo de configuração está sendo usado
ls -la /etc/nginx/sites-enabled/ | grep cobranca
```

```bash
# 6. Testar com o IP
curl -I http://76.13.167.54/health
```

```bash
# 7. Testar com HTTP
curl -I http://api.cobrancaauto.com.br/health
```

---

## 🔧 SOLUÇÃO 1: CRIAR LINK SIMBÓLICO

Se o arquivo não estiver sendo usado, crie o link simbólico:

```bash
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api
```

---

## 🔧 SOLUÇÃO 2: VERIFICAR SE O DOMÍNIO ESTÁ CONFIGURADO

Se o domínio não estiver configurado corretamente, verifique:

1. Se o DNS está apontando para o IP correto
2. Se o certificado SSL é válido
3. Se o Cloudflare está configurado corretamente

---

## 🔧 SOLUÇÃO 3: TESTAR COM OUTRO DOMÍNIO

Se api.cobrancaauto.com.br não funcionar, tente:

```bash
curl -I http://76.13.167.54/health
```

---

## 📝 RESUMO

### O que verificar:

1. Se o domínio está resolvendo
2. Se o certificado SSL existe
3. Logs de acesso do Nginx
4. Logs de erro do Nginx
5. Se o arquivo de configuração está sendo usado
6. Testar com o IP
7. Testar com HTTP

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar se o domínio está resolvendo
nslookup api.cobrancaauto.com.br

# 2. Verificar se o certificado SSL existe
ls -la /etc/letsencrypt/live/api.cobrancaauto.com.br/

# 3. Verificar logs de acesso do Nginx
tail -20 /var/log/nginx/cobranca-api-access.log

# 4. Verificar logs de erro do Nginx
tail -20 /var/log/nginx/cobranca-api-error.log

# 5. Verificar se o arquivo de configuração está sendo usado
ls -la /etc/nginx/sites-enabled/ | grep cobranca

# 6. Testar com o IP
curl -I http://76.13.167.54/health

# 7. Testar com HTTP
curl -I http://api.cobrancaauto.com.br/health

# 8. Criar link simbólico se necessário
ln -sf /etc/nginx/sites-available/cobranca-api /etc/nginx/sites-enabled/cobranca-api

# 9. Recarregar Nginx
systemctl reload nginx

# 10. Testar novamente
curl https://api.cobrancaauto.com.br/health
curl https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

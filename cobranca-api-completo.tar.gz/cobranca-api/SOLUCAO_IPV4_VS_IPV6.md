# SOLUÇÃO PROBLEMA IPv4 vs IPv6

## 🚨 PROBLEMA IDENTIFICADO

O PHP-FPM está escutando em `:::9000` (IPv6), mas o Nginx está tentando conectar em `127.0.0.1:9000` (IPv4). Isso pode estar causando problemas de compatibilidade.

## ✅ SOLUÇÃO

### PASSO 1: Verificar como o PHP-FPM está escutando

```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Se mostrar `:::9000` (IPv6):**
O PHP-FPM está configurado para escutar em IPv6. Precisamos alterar para IPv4.

### PASSO 2: Alterar configuração do PHP-FPM para IPv4

```bash
docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

# Reiniciar o PHP-FPM
docker restart cobranca_app

# Aguardar 10 segundos
sleep 10

# Verificar se agora está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Deveria mostrar `0.0.0.0:9000` (IPv4):**

### PASSO 3: Testar conexão

```bash
curl -I http://127.0.0.1:9000/index.php
```

### PASSO 4: Testar site

```bash
curl -I https://api.cobrancaauto.com.br/
```

---

## 📝 RESUMO

### O que fazer:

1. Verificar como o PHP-FPM está escutando
2. Alterar configuração do PHP-FPM para IPv4
3. Reiniciar o PHP-FPM
4. Testar conexão
5. Testar site

---

## 🔍 SE AINDA NÃO FUNCIONAR

Se ainda não funcionar, execute:

```bash
# Verificar logs do PHP-FPM
docker logs cobranca_app | tail -50

# Verificar se o PHP-FPM está processando
docker exec cobranca_app ps aux | grep php-fpm

# Testar conexão direta
docker exec cobranca_app wget -O- http://127.0.0.1:9000/index.php
```

---

## 🚀 COMANDOS COMPLETOS (COPIAR E COLAR)

```bash
# 1. Verificar como o PHP-FPM está escutando
docker exec cobranca_app netstat -tlnp | grep 9000

# 2. Alterar configuração do PHP-FPM para IPv4
docker exec cobranca_app sh -c "echo 'listen = 0.0.0.0:9000' > /usr/local/etc/php-fpm.d/www.conf"

# 3. Reiniciar o PHP-FPM
docker restart cobranca_app

# 4. Aguardar 10 segundos
sleep 10

# 5. Verificar se agora está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000

# 6. Testar conexão
curl -I http://127.0.0.1:9000/index.php

# 7. Testar site
curl -I https://api.cobrancaauto.com.br/
```

---

**ÚLTIMA ATUALIZAÇÃO:** 2026-02-04  
**VERSÃO:** 1.0  
**STATUS:** PRONTO PARA EXECUÇÃO

# 🔥 FIX ERRO 419 EXPIRED - LARAVEL

## 📋 PROBLEMA

**Erro:** 419 Page Expired
**Causa:** Sessão do Laravel expirou ou cache corrompido

---

## ⚡ SOLUÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos na VPS:

```bash
# Passo 1: Limpar todo o cache do Laravel
cd /var/www/cobranca-api

# Limpar cache de configuração
php artisan config:clear

# Limpar cache de aplicação
php artisan cache:clear

# Limpar cache de rotas
php artisan route:clear

# Limpar cache de views
php artisan view:clear

# Limpar cache de eventos
php artisan event:clear

# Limpar cache de comandos
php artisan optimize:clear

# Passo 2: Limpar cache de sessão
rm -rf storage/framework/sessions/*

# Passo 3: Limpar cache de views compiladas
rm -rf storage/framework/views/*

# Passo 4: Corrigir permissões
chmod -R 775 storage/framework
chmod -R 775 storage/logs

# Passo 5: Verificar APP_URL
cat .env | grep APP_URL

# Deve ser: APP_URL=http://api.cobrancaauto.com.br

# Se estiver diferente, corrigir:
# nano .env
# Alterar APP_URL=http://api.cobrancaauto.com.br
```

---

## 🔧 SOLUÇÃO COMPLETA

### Passo 1: Limpar Cache

```bash
cd /var/www/cobranca-api

# Limpar todos os caches
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan event:clear
php artisan optimize:clear
```

### Passo 2: Limpar Sessões

```bash
# Remover todas as sessões
rm -rf storage/framework/sessions/*

# Recriar diretório com permissões corretas
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions
```

### Passo 3: Verificar Configuração .env

```bash
# Verificar APP_URL
cat .env | grep APP_URL

# Deve ser: APP_URL=http://api.cobrancaauto.com.br

# Se estiver com https, mudar para http:
sed -i 's/APP_URL=https:\/\/api.cobrancaauto.com.br/APP_URL=http:\/\/api.cobrancaauto.com.br/' .env

# Se estiver com localhost, mudar para o domínio:
sed -i 's/APP_URL=http:\/\/localhost/APP_URL=http:\/\/api.cobrancaauto.com.br/' .env

# Limpar cache após mudar .env
php artisan config:clear
php artisan cache:clear
```

### Passo 4: Verificar APP_KEY

```bash
# Verificar APP_KEY
cat .env | grep APP_KEY

# Se estiver vazia ou incorreta, gerar nova:
php artisan key:generate

# Limpar cache
php artisan config:clear
php artisan cache:clear
```

### Passo 5: Verificar SESSION_DRIVER

```bash
# Verificar qual driver de sessão está sendo usado
cat .env | grep SESSION_DRIVER

# Opções válidas: file, redis, database, cookie

# Se estiver usando file (padrão), verificar permissões:
ls -la storage/framework/sessions

# Se não existir, criar:
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions
```

### Passo 6: Reiniciar PHP-FPM

```bash
# Reiniciar PHP-FPM para limpar cache em memória
systemctl restart php8.2-fpm

# Reiniciar NGINX
systemctl restart nginx
```

---

## 🚨 SOLUÇÃO RADICAL (SE NADA FUNCIONAR)

```bash
# Passo 1: Fazer backup do .env
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Gerar nova APP_KEY
php artisan key:generate

# Passo 3: Limpar tudo
cd /var/www/cobranca-api
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan event:clear
php artisan optimize:clear

# Passo 4: Limpar sessões
rm -rf storage/framework/sessions/*
rm -rf storage/framework/cache/*

# Passo 5: Limpar logs (opcional)
rm -f storage/logs/laravel.log

# Passo 6: Corrigir permissões
chmod -R 775 storage/
chown -R www-data:www-data storage/

# Passo 7: Reiniciar serviços
systemctl restart php8.2-fpm
systemctl restart nginx

# Passo 8: Testar
curl -I http://api.cobrancaauto.com.br/
```

---

## 📊 VERIFICAR CONFIGURAÇÃO

```bash
# Verificar configuração atual
cd /var/www/cobranca-api

# Verificar APP_URL
echo "APP_URL: $(grep ^APP_URL .env | cut -d '=' -f2)"

# Verificar APP_ENV
echo "APP_ENV: $(grep ^APP_ENV .env | cut -d '=' -f2)"

# Verificar SESSION_DRIVER
echo "SESSION_DRIVER: $(grep ^SESSION_DRIVER .env | cut -d '=' -f2)"

# Verificar CACHE_DRIVER
echo "CACHE_DRIVER: $(grep ^CACHE_DRIVER .env | cut -d '=' -f2)"

# Verificar permissões do storage
ls -la storage/framework/sessions/
```

---

## ✅ APÓS APLICAR A SOLUÇÃO

### Passo 1: Limpar Cache do Navegador

Antes de testar novamente, limpe o cache do navegador:

**Chrome/Edge:**
- Windows: Ctrl + Shift + Delete
- Mac: Cmd + Shift + Delete

**Firefox:**
- Windows/Linux: Ctrl + Shift + Delete
- Mac: Cmd + Shift + Delete

### Passo 2: Fazer Login Novamente

Acesse:
- **URL:** http://api.cobrancaauto.com.br/login
- **Email:** admin@cobranca.com
- **Senha:** 123456

### Passo 3: Se Ainda Não Funcionar

1. **Tente em modo anônimo:**
   - Chrome: Ctrl + Shift + N
   - Firefox: Ctrl + Shift + P

2. **Tente outro navegador**

3. **Verifique se há cookies antigos:**
   - Limpe todos os cookies do domínio
   - Limpe o cache do navegador

---

## 🔍 DIAGNÓSTICO ADICIONAL

Se ainda não funcionar, verifique os logs:

```bash
# Verificar logs do Laravel
tail -50 /var/www/cobranca-api/storage/logs/laravel.log

# Verificar logs do PHP-FPM
tail -50 /var/log/php8.2-fpm.log

# Verificar logs do NGINX
tail -50 /var/log/nginx/error.log
```

---

## 💚 SUCESSO!

Após aplicar a solução:

1. Limpe o cache do navegador
2. Acesse: http://api.cobrancaauto.com.br/login
3. Faça login com: admin@cobranca.com / 123456
4. Você será redirecionado para o dashboard

**O erro 419 deve desaparecer!**

---

## 📝 NOTA IMPORTANTE

**Mude a senha após fazer login!**

1. Acesse: http://api.cobrancaauto.com.br/profile
2. Procure por: "Mudar Senha"
3. Digite a nova senha
4. Confirme a nova senha
5. Salve as alterações

**Senhas padrão são inseguras!**

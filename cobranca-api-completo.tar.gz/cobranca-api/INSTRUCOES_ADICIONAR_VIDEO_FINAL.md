# 🎬 INSTRUÇÕES PARA ADICIONAR VÍDEO DEMO

## 📋 SITUAÇÃO ATUAL

✅ **Vídeo baixado** - `demo-cobranca.mp4` (771K)
✅ **Site funcionando** - HTTP/2 200 OK
✅ **HTTPS configurado** - Security headers presentes
❌ **Vídeo não adicionado** - Precisa adicionar à página inicial

## 📋 OPÇÕES PARA ADICIONAR O VÍDEO

### Opção 1: Executar script remoto (RECOMENDADO - MAIS SIMPLES)

Execute este comando no seu terminal local:

```bash
chmod +x scripts/executar-adicionar-video-remoto.sh && ./scripts/executar-adicionar-video-remoto.sh
```

Este script irá:
1. Enviar o script de adição de vídeo para a VPS
2. Executar o script na VPS
3. Adicionar o vídeo à página inicial
4. Limpar o cache do Laravel
5. Limpar o script temporário

### Opção 2: Executar script diretamente na VPS

Execute estes comandos diretamente na VPS:

```bash
cd /var/www/cobranca-api

# Criar arquivo temporário com o código do vídeo
cat > /tmp/video_code.txt << 'VIDEOEOF'

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
VIDEOEOF

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do vídeo ao final do arquivo
cat /tmp/video_code.txt >> resources/views/landing.blade.php

# Limpar arquivo temporário
rm -f /tmp/video_code.txt

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Opção 3: Usar vídeo local em vez do YouTube

Execute estes comandos diretamente na VPS:

```bash
cd /var/www/cobranca-api

# Criar arquivo temporário com o código do vídeo local
cat > /tmp/video_code.txt << 'VIDEOEOF'

{{-- Vídeo Demo Local --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <video
            controls
            class="w-full h-full"
        >
            <source src="/videos/demo-cobranca.mp4" type="video/mp4">
            Seu navegador não suporta vídeos.
        </video>
    </div>
</div>
VIDEOEOF

# Backup do arquivo
cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar código do vídeo ao final do arquivo
cat /tmp/video_code.txt >> resources/views/landing.blade.php

# Limpar arquivo temporário
rm -f /tmp/video_code.txt

# Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

## 📋 VERIFICAÇÕES

### Verificar se vídeo foi adicionado

```bash
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
```

### Verificar se backup foi criado

```bash
ls -lh /var/www/cobranca-api/resources/views/landing.blade.php.backup.*
```

### Testar site

```bash
curl -I https://api.cobrancaauto.com.br
```

### Acessar site no navegador

```
https://api.cobrancaauto.com.br
```

## 📋 ARQUIVOS CRIADOS

1. [`scripts/adicionar-video-final.sh`](scripts/adicionar-video-final.sh) - Script para adicionar vídeo na VPS
2. [`scripts/executar-adicionar-video-remoto.sh`](scripts/executar-adicionar-video-remoto.sh) - Script para executar remotamente
3. [`INSTRUCOES_ADICIONAR_VIDEO_FINAL.md`](INSTRUCOES_ADICIONAR_VIDEO_FINAL.md) - Este arquivo

## 📋 CREDENCIAIS DE ACESSO

**Email:** `admin@cobranca.com`
**Senha:** `123456`

## 📋 PÁGINAS DO SISTEMA

- **Página inicial:** https://api.cobrancaauto.com.br
- **Login:** https://api.cobrancaauto.com.br/login
- **Dashboard:** https://api.cobrancaauto.com.br/dashboard
- **Configurações de vendas:** https://api.cobrancaauto.com.br/whatsapp-settings

## 📋 MELHORIAS IMPLEMENTADAS

1. **🔥 HTTPS SSL** ✅ - Certificado SSL configurado com Certbot
2. **⚠️ Clean NGINX** ✅ - Site default removido
3. **📊 Backup DB diário** ✅ - Configurado e sem duplicidade
4. **🛡️ Rate limiting** ✅ - Configurado corretamente
5. **📱 WhatsApp configurado** ✅ - Página de configurações criada
6. **📱 Página inicial atualizada** ✅ - Número de WhatsApp configurado
7. **✅ Cache limpo** ✅ - Cache do Laravel limpo
8. **🎬 Vídeo demo baixado** ✅ - Vídeo de demonstração baixado
9. **🌐 Site funcionando** ✅ - HTTP/2 200 OK

## 💚 SUCESSO FINAL

**✅ HTTPS configurado e funcionando**
**✅ NGINX limpo e configurado**
**✅ Backup diário configurado e sem duplicidade**
**✅ Rate limiting configurado e sem duplicidade**
**✅ Site acessível via HTTPS**
**✅ HTTP redireciona para HTTPS**
**✅ Security headers configurados**
**✅ Certificado SSL válido**
**✅ WhatsApp configurado corretamente**
**✅ Página de configurações de vendas criada**
**✅ Página inicial atualizada com número de WhatsApp**
**✅ Cache limpo**
**✅ Vídeo demo baixado**
**✅ Site funcionando**

**Site seguro, funcional e configurado = Cliente feliz = 💸**

---

## 📝 COMANDOS PARA EXECUTAR (COPIAR E COLAR)

### Opção 1: Executar script remoto (RECOMENDADO - MAIS SIMPLES)

```bash
chmod +x scripts/executar-adicionar-video-remoto.sh && ./scripts/executar-adicionar-video-remoto.sh
```

### Opção 2: Executar script diretamente na VPS

```bash
cd /var/www/cobranca-api
cat > /tmp/video_code.txt << 'VIDEOEOF'

{{-- Vídeo Demo do YouTube --}}
<div class="mb-6">
    <h2 class="text-xl font-semibold mb-4">Veja como funciona</h2>
    <div class="aspect-video bg-black rounded-lg overflow-hidden">
        <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dQw4w9WgXQ"
            title="Demo Cobrança Auto"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="w-full h-full"
        ></iframe>
    </div>
</div>
VIDEOEOF

cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)
cat /tmp/video_code.txt >> resources/views/landing.blade.php
rm -f /tmp/video_code.txt

php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Verificar se vídeo foi adicionado

```bash
grep -A 10 'youtube.com/embed' /var/www/cobranca-api/resources/views/landing.blade.php
curl -I https://api.cobrancaauto.com.br
```

---

**Execute os comandos acima para adicionar o vídeo! 🚀**

**Site seguro, funcional e configurado = Cliente feliz = 💸**

# 🔧 SOLUÇÃO FINAL COMPLETA

## 📋 Problema

O site está funcionando parcialmente:
- ✅ Endpoint `/health` está funcionando (HTTP 200 OK)
- ❌ Site principal não está funcionando (Connection refused)
- ❌ Porta 9000 não está exposta (`docker port cobranca_app` retorna vazio)
- ❌ PHP-FPM está escutando em IPv6 (`:::9000`), não em IPv4

## 🚀 Execute estes comandos na VPS (em ordem):

### Passo 1: Parar e remover containers
```bash
cd /var/www/cobranca-api
docker-compose -f docker-compose.prod.yml down
```

### Passo 2: Verificar se os containers foram removidos
```bash
docker ps -a
```

### Passo 3: Subir os containers novamente
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Passo 4: Aguardar 15 segundos
```bash
sleep 15
```

### Passo 5: Verificar se os containers estão rodando
```bash
docker ps
```

### Passo 6: Verificar se a porta 9000 está exposta
```bash
docker port cobranca_app
```

**Resultado esperado:**
```
9000/tcp -> 127.0.0.1:9000
```

### Passo 7: Verificar em qual porta o PHP-FPM está escutando
```bash
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm.conf)
```

### Passo 8: Se o PHP-FPM estiver escutando em IPv6, modificar para IPv4
```bash
# Modificar PHP-FPM para escutar em IPv4
docker exec cobranca_app cp /usr/local/etc/php-fpm.d/www.conf /usr/local/etc/php-fpm.d/www.conf.backup
docker exec cobranca_app sh -c 'cat > /usr/local/etc/php-fpm.d/www.conf << '\''EOF'\''
[www]
user = www-data
group = www-data
listen = 0.0.0.0:9000
listen.owner = www-data
listen.group = www-data
listen.mode = 0660
pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
php_admin_value[error_log] = /var/log/php-fpm.log
php_admin_flag[log_errors] = on
EOF'

# Reiniciar container
docker restart cobranca_app

# Aguardar 15 segundos
sleep 15

# Verificar se está escutando em IPv4
docker exec cobranca_app netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm.conf)
```

### Passo 9: Testar conexão com PHP-FPM
```bash
curl -I http://127.0.0.1:9000
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

### Passo 10: Testar o endpoint /health
```bash
curl -i http://api.cobrancaauto.com.br/health
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
{"status":"ok","app":"cobranca-auto"}
```

### Passo 11: Testar o site principal
```bash
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 📋 Se o Passo 6 falhar

Se a porta 9000 não estiver exposta, verifique o arquivo `docker-compose.prod.yml`:

```bash
# Verificar se a porta está configurada
grep -A 5 "ports:" docker-compose.prod.yml | grep 9000
```

**Resultado esperado:**
```
      - "127.0.0.1:9000:9000"
```

Se não estiver configurada, adicione:

```bash
# Editar o arquivo
nano docker-compose.prod.yml

# Adicionar no serviço app:
# ports:
#   - "127.0.0.1:9000:9000"

# Salvar e recriar containers
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d
```

## 🎯 Resumo

1. Parar e remover containers: `docker-compose -f docker-compose.prod.yml down`
2. Subir containers novamente: `docker-compose -f docker-compose.prod.yml up -d`
3. Verificar se a porta 9000 está exposta: `docker port cobranca_app`
4. Verificar se o PHP-FPM está escutando em IPv4: `docker exec cobranca_app netstat -tlnp | grep 9000`
5. Se estiver em IPv6, modificar para IPv4
6. Testar conexão: `curl -I http://127.0.0.1:9000`
7. Testar site: `curl -I https://api.cobrancaauto.com.br/`

Execute os comandos acima em ordem e me envie os resultados!

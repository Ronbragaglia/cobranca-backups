# 🚀 REINICIAR PHP-FPM E TESTAR

## 📋 Você está dentro do container cobranca_app

Execute estes comandos em ordem:

### Passo 1: Reiniciar o PHP-FPM
```bash
killall php-fpm
php-fpm -D
```

### Passo 2: Verificar se o PHP-FPM está rodando
```bash
ps aux | grep php-fpm
```

### Passo 3: Verificar em qual porta o PHP-FPM está escutando
```bash
netstat -tlnp | grep 9000
```

**Resultado esperado:**
```
tcp        0      0 0.0.0.0:9000            0.0.0.0:*               LISTEN      1/php-fpm.conf)
```

### Passo 4: Sair do container
```bash
exit
```

### Passo 5: Verificar se a porta 9000 está exposta
```bash
docker port cobranca_app
```

**Resultado esperado:**
```
9000/tcp -> 127.0.0.1:9000
```

### Passo 6: Testar conexão com PHP-FPM
```bash
curl -I http://127.0.0.1:9000
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

### Passo 7: Testar o site
```bash
curl -I https://api.cobrancaauto.com.br/
```

**Resultado esperado:**
```
HTTP/1.1 200 OK
```

## 🎯 Resumo

1. Reiniciar PHP-FPM: `killall php-fpm && php-fpm -D`
2. Verificar se está escutando em IPv4: `netstat -tlnp | grep 9000`
3. Sair do container: `exit`
4. Testar conexão: `curl -I http://127.0.0.1:9000`
5. Testar site: `curl -I https://api.cobrancaauto.com.br/`

Execute os comandos acima em ordem e me envie os resultados!

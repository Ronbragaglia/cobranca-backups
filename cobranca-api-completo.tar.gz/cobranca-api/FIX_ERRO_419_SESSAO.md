# 🔥 FIX ERRO 419 - CONFIGURAÇÃO DE SESSÃO

## 📋 PROBLEMA

**Erro:** 419 Page Expired
**Causa possível:** SESSION_DRIVER está configurado como `database` mas pode estar tendo problemas

---

## ⚡ SOLUÇÃO RÁPIDA (1 MINUTO)

Execute estes comandos na VPS:

```bash
# Passo 1: Acessar o diretório do projeto
cd /var/www/cobranca-api

# Passo 2: Verificar configuração atual do .env
cat .env | grep SESSION_DRIVER

# Passo 3: Mudar SESSION_DRIVER para file
sed -i 's/SESSION_DRIVER=.*/SESSION_DRIVER=file/' .env

# Passo 4: Verificar se mudou
cat .env | grep SESSION_DRIVER

# Passo 5: Verificar APP_ENV
cat .env | grep APP_ENV

# Passo 6: Se APP_ENV for production, mudar para local
sed -i 's/APP_ENV=.*/APP_ENV=local/' .env

# Passo 7: Verificar APP_URL
cat .env | grep APP_URL

# Se APP_URL não estiver correto, corrigir
sed -i 's/APP_URL=.*/APP_URL=http:\/\/api.cobrancaauto.com.br/' .env

# Passo 8: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 9: Limpar sessões
rm -rf storage/framework/sessions/*

# Passo 10: Criar diretório de sessões com permissões corretas
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions
chown -R www-data:www-data storage/framework/sessions

# Passo 11: Reiniciar PHP-FPM
systemctl restart php8.2-fpm
```

---

## 🔧 SOLUÇÃO COMPLETA

### Passo 1: Verificar Configuração Atual

```bash
cd /var/www/cobranca-api

# Verificar todas as configurações importantes
echo "=== CONFIGURAÇÃO ATUAL ==="
echo "APP_ENV: $(cat .env | grep APP_ENV | cut -d '=' -f2)"
echo "APP_URL: $(cat .env | grep APP_URL | cut -d '=' -f2)"
echo "SESSION_DRIVER: $(cat .env | grep SESSION_DRIVER | cut -d '=' -f2)"
echo "SESSION_LIFETIME: $(cat .env | grep SESSION_LIFETIME | cut -d '=' -f2)"
echo "APP_KEY: $(cat .env | grep APP_KEY | cut -d '=' -f2)"
```

### Passo 2: Corrigir Configuração

```bash
# Mudar SESSION_DRIVER para file (mais confiável)
sed -i 's/SESSION_DRIVER=.*/SESSION_DRIVER=file/' .env

# Mudar APP_ENV para local (para debug)
sed -i 's/APP_ENV=.*/APP_ENV=local/' .env

# Mudar APP_URL para o domínio correto
sed -i 's/APP_URL=.*/APP_URL=http:\/\/api.cobrancaauto.com.br/' .env

# Ativar debug
sed -i 's/APP_DEBUG=.*/APP_DEBUG=true/' .env
```

### Passo 3: Verificar Configuração Corrigida

```bash
echo "=== NOVA CONFIGURAÇÃO ==="
echo "APP_ENV: $(cat .env | grep APP_ENV | cut -d '=' -f2)"
echo "APP_URL: $(cat .env | grep APP_URL | cut -d '=' -f2)"
echo "SESSION_DRIVER: $(cat .env | grep SESSION_DRIVER | cut -d '=' -f2)"
echo "SESSION_LIFETIME: $(cat .env | grep SESSION_LIFETIME | cut -d '=' -f2)"
echo "APP_DEBUG: $(cat .env | grep APP_DEBUG | cut -d '=' -f2)"
```

### Passo 4: Limpar Cache e Sessões

```bash
# Limpar todos os caches
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan event:clear
php artisan optimize:clear

# Limpar sessões
rm -rf storage/framework/sessions/*

# Criar diretório de sessões com permissões corretas
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions
chown -R www-data:www-data storage/framework/sessions

# Limpar views compiladas
rm -rf storage/framework/views/*

# Limpar cache
rm -rf storage/framework/cache/*
```

### Passo 5: Reiniciar Serviços

```bash
# Reiniciar PHP-FPM
systemctl restart php8.2-fpm

# Reiniciar NGINX
systemctl restart nginx

# Verificar status
systemctl status php8.2-fpm
systemctl status nginx
```

---

## 🚨 SOLUÇÃO RADICAL (SE NADA FUNCIONAR)

```bash
# Passo 1: Fazer backup do .env
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

# Passo 2: Criar novo .env com configurações corretas
cat > .env << 'ENVEOF'
APP_NAME=Laravel
APP_ENV=local
APP_KEY=$(php artisan key:generate --show)
APP_DEBUG=true
APP_URL=http://api.cobrancaauto.com.br

APP_LOCALE=en
APP_FALLBACK_LOCALE=en

APP_MAINTENANCE_DRIVER=file

LOG_CHANNEL=stack
LOG_STACK=single
LOG_LEVEL=debug

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cobranca
DB_USERNAME=cobranca
DB_PASSWORD=COBRANCA_DB_PASSWORD

BROADCAST_DRIVER=log
FILESYSTEM_DISK=local
QUEUE_CONNECTION=database

CACHE_DRIVER=file
SESSION_DRIVER=file
SESSION_LIFETIME=120
SESSION_ENCRYPT=false
SESSION_PATH=/
SESSION_DOMAIN=null

MAIL_MAILER=log

STRIPE_KEY=pk_test_
STRIPE_SECRET=sk_test_
STRIPE_WEBHOOK_SECRET=whsec_

TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886

TENANCY_ENABLED=false
ENVEOF

# Passo 3: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 4: Limpar sessões
rm -rf storage/framework/sessions/*
mkdir -p storage/framework/sessions
chmod -R 775 storage/framework/sessions

# Passo 5: Reiniciar serviços
systemctl restart php8.2-fpm
systemctl restart nginx
```

---

## 📊 VERIFICAR SESSÕES NO BANCO DE DADOS

```bash
# Verificar se há sessões antigas no banco
mysql -u cobranca -p -e "USE cobranca; SELECT COUNT(*) as total FROM sessions;"

# Limpar sessões antigas (mais de 1 hora)
mysql -u cobranca -p -e "USE cobranca; DELETE FROM sessions WHERE last_activity < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 HOUR));"
```

---

## ✅ APÓS APLICAR A SOLUÇÃO

### Passo 1: Limpar Cache do Navegador

- Chrome/Edge: Ctrl + Shift + Delete
- Firefox: Ctrl + Shift + Delete

### Passo 2: Fazer Login

- **URL:** http://api.cobrancaauto.com.br/login
- **Email:** admin@cobranca.com
- **Senha:** 123456

### Passo 3: Se Ainda Não Funcionar

1. **Verifique os logs:**
   ```bash
   tail -50 /var/www/cobranca-api/storage/logs/laravel.log
   ```

2. **Verifique se há erros no PHP-FPM:**
   ```bash
   tail -50 /var/log/php8.2-fpm.log
   ```

3. **Verifique se há erros no NGINX:**
   ```bash
   tail -50 /var/log/nginx/error.log
   ```

---

## 💚 SUCESSO!

Após aplicar a solução, o erro 419 deve desaparecer e você conseguirá fazer login!

**Execute os comandos acima na VPS para corrigir a configuração de sessão!**

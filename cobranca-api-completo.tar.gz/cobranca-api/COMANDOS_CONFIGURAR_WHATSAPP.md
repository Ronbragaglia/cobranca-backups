# 🔧 COMANDOS PARA CONFIGURAR WHATSAPP (COPIAR E COLAR NA VPS)

## 📋 PASSO A PASSO

### Passo 1: Criar controller de configurações de vendas

```bash
# Criar arquivo do controller
cat > /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php << 'EOF'
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SalesSettingsController extends Controller
{
    /**
     * Exibir configurações de vendas
     */
    public function index()
    {
        $whatsappNumber = env('WHATSAPP_SALES_NUMBER', '');
        $whatsappMessage = env('WHATSAPP_SALES_MESSAGE', '');
        
        return view('sales-settings', compact('whatsappNumber', 'whatsappMessage'));
    }

    /**
     * Atualizar configurações de vendas
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'whatsapp_number' => 'required|string|max:20',
            'whatsapp_message' => 'required|string|max:500',
        ]);

        // Atualizar .env
        $envFile = base_path('.env');
        $envContent = file_get_contents($envFile);
        
        // Adicionar ou atualizar WHATSAPP_SALES_NUMBER
        if (strpos($envContent, 'WHATSAPP_SALES_NUMBER') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_NUMBER=.*/m',
                "WHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}";
        }
        
        // Adicionar ou atualizar WHATSAPP_SALES_MESSAGE
        if (strpos($envContent, 'WHATSAPP_SALES_MESSAGE') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_MESSAGE=.*/m',
                "WHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"";
        }
        
        file_put_contents($envFile, $envContent);

        // Limpar cache
        Cache::flush();

        return redirect()->back()->with('success', 'Configurações atualizadas com sucesso!');
    }
}
EOF
```

### Passo 2: Criar view de configurações de vendas

```bash
# Criar arquivo da view
cat > /var/www/cobranca-api/resources/views/sales-settings.blade.php << 'EOF'
@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-bold mb-6">Configurações de Vendas</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('sales-settings.update') }}" method="POST">
        @csrf

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Número de WhatsApp</label>
            <input 
                type="text" 
                name="whatsapp_number" 
                value="{{ old('whatsapp_number', $whatsappNumber) }}"
                class="w-full px-3 py-2 border rounded-md"
                placeholder="5511999999999"
                required
            >
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Mensagem Padrão</label>
            <textarea 
                name="whatsapp_message" 
                rows="4"
                class="w-full px-3 py-2 border rounded-md"
                required
            >{{ old('whatsapp_message', $whatsappMessage) }}</textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Salvar Configurações
        </button>
    </form>
</div>
@endsection
EOF
```

### Passo 3: Adicionar rotas de configurações de vendas

```bash
# Adicionar rotas ao arquivo routes/web.php
cd /var/www/cobranca-api

# Backup do arquivo de rotas
cp routes/web.php routes/web.php.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar rotas (executar apenas uma vez)
if ! grep -q "SalesSettingsController" routes/web.php; then
    # Adicionar use do controller
    sed -i '/use App\\\\Http\\\\Controllers\\\\ProfileController;/a use App\\\\Http\\\\Controllers\\\\SalesSettingsController;' routes/web.php
    
    # Adicionar rotas antes do require
    sed -i '/^Route::middleware/i\
// Sales Settings\
Route::get("/sales-settings", [SalesSettingsController::class, "index"])\
    ->middleware(["auth"])\
    ->name("sales-settings.index");\
\
Route::put("/sales-settings", [SalesSettingsController::class, "update"])\
    ->middleware(["auth"])\
    ->name("sales-settings.update");\
' routes/web.php
    
    echo "✅ Rotas adicionadas"
else
    echo "✅ Rotas já existem"
fi
```

### Passo 4: Adicionar configurações ao .env

```bash
# Adicionar configurações ao .env
cd /var/www/cobranca-api

# Backup do .env
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

# Adicionar configurações ao .env
if ! grep -q "WHATSAPP_SALES_NUMBER" .env; then
    echo "" >> .env
    echo "# WhatsApp Sales Settings" >> .env
    echo "WHATSAPP_SALES_NUMBER=5511954092078" >> .env
    echo "WHATSAPP_SALES_MESSAGE=\"Olá! Gostaria de saber mais sobre o sistema de cobrança automática.\"" >> .env
    echo "✅ Configurações adicionadas ao .env"
else
    echo "✅ Configurações já existem no .env"
fi
```

### Passo 5: Limpar cache

```bash
cd /var/www/cobranca-api
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

### Passo 6: Atualizar página inicial com número de WhatsApp

```bash
# Verificar se existe arquivo landing.blade.php
if [ -f "resources/views/landing.blade.php" ]; then
    # Backup do arquivo
    cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)
    
    # Atualizar link de WhatsApp
    sed -i 's|https://wa.me/qr/5UYGQNHBGZVKC1|https://wa.me/{{ env("WHATSAPP_SALES_NUMBER", "5511954092078") }}|g' resources/views/landing.blade.php
    
    # Atualizar QR Code
    sed -i 's|data=https://wa.me/qr/5UYGQNHBGZVKC1|data=https://wa.me/{{ env("WHATSAPP_SALES_NUMBER", "5511954092078") }}|g' resources/views/landing.blade.php
    
    echo "✅ Página inicial atualizada"
else
    echo "⚠️ Arquivo landing.blade.php não encontrado"
fi
```

## 📋 VERIFICAÇÕES

### Verificar configurações no .env

```bash
grep WHATSAPP_SALES /var/www/cobranca-api/.env
```

### Acessar configurações de vendas

```bash
# Acessar no navegador
https://api.cobrancaauto.com.br/sales-settings
```

### Testar link de WhatsApp

```bash
# Testar link
curl -I "https://wa.me/5511954092078?text=Olá!+Gostaria+de+saber+mais+sobre+o+sistema+de+cobrança+automática."
```

### Testar site

```bash
# Testar HTTPS
curl -I https://api.cobrancaauto.com.br
```

## 🚀 COMANDOS PARA EXECUTAR (COPIAR E COLAR TUDO)

```bash
# Passo 1: Criar controller
cat > /var/www/cobranca-api/app/Http/Controllers/SalesSettingsController.php << 'EOF'
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SalesSettingsController extends Controller
{
    public function index()
    {
        $whatsappNumber = env('WHATSAPP_SALES_NUMBER', '');
        $whatsappMessage = env('WHATSAPP_SALES_MESSAGE', '');
        return view('sales-settings', compact('whatsappNumber', 'whatsappMessage'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'whatsapp_number' => 'required|string|max:20',
            'whatsapp_message' => 'required|string|max:500',
        ]);

        $envFile = base_path('.env');
        $envContent = file_get_contents($envFile);
        
        if (strpos($envContent, 'WHATSAPP_SALES_NUMBER') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_NUMBER=.*/m',
                "WHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_NUMBER={$validated['whatsapp_number']}";
        }
        
        if (strpos($envContent, 'WHATSAPP_SALES_MESSAGE') !== false) {
            $envContent = preg_replace(
                '/^WHATSAPP_SALES_MESSAGE=.*/m',
                "WHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"",
                $envContent
            );
        } else {
            $envContent .= "\nWHATSAPP_SALES_MESSAGE=\"{$validated['whatsapp_message']}\"";
        }
        
        file_put_contents($envFile, $envContent);
        Cache::flush();

        return redirect()->back()->with('success', 'Configurações atualizadas com sucesso!');
    }
}
EOF

# Passo 2: Criar view
cat > /var/www/cobranca-api/resources/views/sales-settings.blade.php << 'EOF'
@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto py-8 px-4">
    <h1 class="text-2xl font-bold mb-6">Configurações de Vendas</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('sales-settings.update') }}" method="POST">
        @csrf

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Número de WhatsApp</label>
            <input 
                type="text" 
                name="whatsapp_number" 
                value="{{ old('whatsapp_number', $whatsappNumber) }}"
                class="w-full px-3 py-2 border rounded-md"
                placeholder="5511999999999"
                required
            >
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium mb-2">Mensagem Padrão</label>
            <textarea 
                name="whatsapp_message" 
                rows="4"
                class="w-full px-3 py-2 border rounded-md"
                required
            >{{ old('whatsapp_message', $whatsappMessage) }}</textarea>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Salvar Configurações
        </button>
    </form>
</div>
@endsection
EOF

# Passo 3: Adicionar rotas
cd /var/www/cobranca-api
cp routes/web.php routes/web.php.backup.$(date +%Y%m%d_%H%M%S)

if ! grep -q "SalesSettingsController" routes/web.php; then
    sed -i '/use App\\\\Http\\\\Controllers\\\\ProfileController;/a use App\\\\Http\\\\Controllers\\\\SalesSettingsController;' routes/web.php
    sed -i '/^Route::middleware/i\
// Sales Settings\
Route::get("/sales-settings", [SalesSettingsController::class, "index"])\
    ->middleware(["auth"])\
    ->name("sales-settings.index");\
\
Route::put("/sales-settings", [SalesSettingsController::class, "update"])\
    ->middleware(["auth"])\
    ->name("sales-settings.update");\
' routes/web.php
    echo "✅ Rotas adicionadas"
else
    echo "✅ Rotas já existem"
fi

# Passo 4: Adicionar configurações ao .env
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

if ! grep -q "WHATSAPP_SALES_NUMBER" .env; then
    echo "" >> .env
    echo "# WhatsApp Sales Settings" >> .env
    echo "WHATSAPP_SALES_NUMBER=5511954092078" >> .env
    echo "WHATSAPP_SALES_MESSAGE=\"Olá! Gostaria de saber mais sobre o sistema de cobrança automática.\"" >> .env
    echo "✅ Configurações adicionadas ao .env"
else
    echo "✅ Configurações já existem no .env"
fi

# Passo 5: Limpar cache
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# Passo 6: Atualizar página inicial
if [ -f "resources/views/landing.blade.php" ]; then
    cp resources/views/landing.blade.php resources/views/landing.blade.php.backup.$(date +%Y%m%d_%H%M%S)
    sed -i 's|https://wa.me/qr/5UYGQNHBGZVKC1|https://wa.me/{{ env("WHATSAPP_SALES_NUMBER", "5511954092078") }}|g' resources/views/landing.blade.php
    sed -i 's|data=https://wa.me/qr/5UYGQNHBGZVKC1|data=https://wa.me/{{ env("WHATSAPP_SALES_NUMBER", "5511954092078") }}|g' resources/views/landing.blade.php
    echo "✅ Página inicial atualizada"
else
    echo "⚠️ Arquivo landing.blade.php não encontrado"
fi

echo ""
echo "=========================================="
echo "✅ CONFIGURAÇÃO CONCLUÍDA!"
echo "=========================================="
echo ""
echo "📋 PRÓXIMOS PASSOS:"
echo ""
echo "1. Acessar: https://api.cobrancaauto.com.br/sales-settings"
echo "2. Configurar número de WhatsApp: 5511954092078"
echo "3. Configurar mensagem padrão"
echo "4. Testar link de WhatsApp na página inicial"
echo "5. Testar QR Code na página inicial"
echo ""
echo "=========================================="
echo "💚 CONFIGURAÇÃO CONCLUÍDA!"
echo "=========================================="
```

## 📋 RESUMO

1. ✅ Controller SalesSettingsController criado
2. ✅ View sales-settings.blade.php criada
3. ✅ Rotas de configurações de vendas adicionadas
4. ✅ Configurações de WhatsApp adicionadas ao .env
5. ✅ Cache limpo
6. ✅ Página inicial atualizada com número de WhatsApp

## 🚀 PRÓXIMOS PASSOS

1. **Acessar configurações de vendas** - https://api.cobrancaauto.com.br/sales-settings
2. **Configurar número de WhatsApp** - 5511954092078
3. **Configurar mensagem padrão** - Personalizar mensagem
4. **Testar link de WhatsApp** - Verificar se funciona corretamente
5. **Testar QR Code** - Verificar se escaneia corretamente
6. **Adicionar vídeo demo** - Implementar vídeo na página inicial

## 💚 SUCESSO FINAL

**✅ WhatsApp configurado corretamente**
**✅ Página de configurações criada**
**✅ Número de WhatsApp atualizado**
**✅ Cache limpo**
**✅ Site funcionando**

**WhatsApp configurado = Cliente feliz = 💸**
